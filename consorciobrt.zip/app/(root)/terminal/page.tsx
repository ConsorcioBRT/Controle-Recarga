import Terminal from "@/components/Terminal";
import React from "react";

const TerminalPage = () => {
  return (
    <div>
      <Terminal />
    </div>
  );
};

export default TerminalPage;
