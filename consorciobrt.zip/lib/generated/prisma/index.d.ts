
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model cbt
 * 
 */
export type cbt = $Result.DefaultSelection<Prisma.$cbtPayload>
/**
 * Model emp
 * 
 */
export type emp = $Result.DefaultSelection<Prisma.$empPayload>
/**
 * Model emp_und
 * 
 */
export type emp_und = $Result.DefaultSelection<Prisma.$emp_undPayload>
/**
 * Model eqp_fbr
 * 
 */
export type eqp_fbr = $Result.DefaultSelection<Prisma.$eqp_fbrPayload>
/**
 * Model eqp_itm
 * 
 */
export type eqp_itm = $Result.DefaultSelection<Prisma.$eqp_itmPayload>
/**
 * Model eqp_loc
 * 
 */
export type eqp_loc = $Result.DefaultSelection<Prisma.$eqp_locPayload>
/**
 * Model eqp_mdl
 * 
 */
export type eqp_mdl = $Result.DefaultSelection<Prisma.$eqp_mdlPayload>
/**
 * Model eqp_tpo
 * 
 */
export type eqp_tpo = $Result.DefaultSelection<Prisma.$eqp_tpoPayload>
/**
 * Model frn
 * 
 */
export type frn = $Result.DefaultSelection<Prisma.$frnPayload>
/**
 * Model rcg
 * 
 */
export type rcg = $Result.DefaultSelection<Prisma.$rcgPayload>
/**
 * Model stt
 * 
 */
export type stt = $Result.DefaultSelection<Prisma.$sttPayload>
/**
 * Model usr
 * 
 */
export type usr = $Result.DefaultSelection<Prisma.$usrPayload>
/**
 * Model usr_tpo
 * 
 */
export type usr_tpo = $Result.DefaultSelection<Prisma.$usr_tpoPayload>
/**
 * Model VwCarregador
 * View: vw_carregador
 */
export type VwCarregador = $Result.DefaultSelection<Prisma.$VwCarregadorPayload>
/**
 * Model VwOnibus
 * View: vw_onibus
 */
export type VwOnibus = $Result.DefaultSelection<Prisma.$VwOnibusPayload>
/**
 * Model VwPostoRecarga
 * View: vw_posto_recarga
 */
export type VwPostoRecarga = $Result.DefaultSelection<Prisma.$VwPostoRecargaPayload>

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Cbts
 * const cbts = await prisma.cbt.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Cbts
   * const cbts = await prisma.cbt.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.cbt`: Exposes CRUD operations for the **cbt** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Cbts
    * const cbts = await prisma.cbt.findMany()
    * ```
    */
  get cbt(): Prisma.cbtDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.emp`: Exposes CRUD operations for the **emp** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Emps
    * const emps = await prisma.emp.findMany()
    * ```
    */
  get emp(): Prisma.empDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.emp_und`: Exposes CRUD operations for the **emp_und** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Emp_unds
    * const emp_unds = await prisma.emp_und.findMany()
    * ```
    */
  get emp_und(): Prisma.emp_undDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.eqp_fbr`: Exposes CRUD operations for the **eqp_fbr** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Eqp_fbrs
    * const eqp_fbrs = await prisma.eqp_fbr.findMany()
    * ```
    */
  get eqp_fbr(): Prisma.eqp_fbrDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.eqp_itm`: Exposes CRUD operations for the **eqp_itm** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Eqp_itms
    * const eqp_itms = await prisma.eqp_itm.findMany()
    * ```
    */
  get eqp_itm(): Prisma.eqp_itmDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.eqp_loc`: Exposes CRUD operations for the **eqp_loc** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Eqp_locs
    * const eqp_locs = await prisma.eqp_loc.findMany()
    * ```
    */
  get eqp_loc(): Prisma.eqp_locDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.eqp_mdl`: Exposes CRUD operations for the **eqp_mdl** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Eqp_mdls
    * const eqp_mdls = await prisma.eqp_mdl.findMany()
    * ```
    */
  get eqp_mdl(): Prisma.eqp_mdlDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.eqp_tpo`: Exposes CRUD operations for the **eqp_tpo** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Eqp_tpos
    * const eqp_tpos = await prisma.eqp_tpo.findMany()
    * ```
    */
  get eqp_tpo(): Prisma.eqp_tpoDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.frn`: Exposes CRUD operations for the **frn** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Frns
    * const frns = await prisma.frn.findMany()
    * ```
    */
  get frn(): Prisma.frnDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.rcg`: Exposes CRUD operations for the **rcg** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Rcgs
    * const rcgs = await prisma.rcg.findMany()
    * ```
    */
  get rcg(): Prisma.rcgDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.stt`: Exposes CRUD operations for the **stt** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Stts
    * const stts = await prisma.stt.findMany()
    * ```
    */
  get stt(): Prisma.sttDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.usr`: Exposes CRUD operations for the **usr** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Usrs
    * const usrs = await prisma.usr.findMany()
    * ```
    */
  get usr(): Prisma.usrDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.usr_tpo`: Exposes CRUD operations for the **usr_tpo** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Usr_tpos
    * const usr_tpos = await prisma.usr_tpo.findMany()
    * ```
    */
  get usr_tpo(): Prisma.usr_tpoDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.vwCarregador`: Exposes CRUD operations for the **VwCarregador** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more VwCarregadors
    * const vwCarregadors = await prisma.vwCarregador.findMany()
    * ```
    */
  get vwCarregador(): Prisma.VwCarregadorDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.vwOnibus`: Exposes CRUD operations for the **VwOnibus** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more VwOnibuses
    * const vwOnibuses = await prisma.vwOnibus.findMany()
    * ```
    */
  get vwOnibus(): Prisma.VwOnibusDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.vwPostoRecarga`: Exposes CRUD operations for the **VwPostoRecarga** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more VwPostoRecargas
    * const vwPostoRecargas = await prisma.vwPostoRecarga.findMany()
    * ```
    */
  get vwPostoRecarga(): Prisma.VwPostoRecargaDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.13.0
   * Query Engine version: 361e86d0ea4987e9f53a565309b3eed797a6bcbd
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    cbt: 'cbt',
    emp: 'emp',
    emp_und: 'emp_und',
    eqp_fbr: 'eqp_fbr',
    eqp_itm: 'eqp_itm',
    eqp_loc: 'eqp_loc',
    eqp_mdl: 'eqp_mdl',
    eqp_tpo: 'eqp_tpo',
    frn: 'frn',
    rcg: 'rcg',
    stt: 'stt',
    usr: 'usr',
    usr_tpo: 'usr_tpo',
    VwCarregador: 'VwCarregador',
    VwOnibus: 'VwOnibus',
    VwPostoRecarga: 'VwPostoRecarga'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "cbt" | "emp" | "emp_und" | "eqp_fbr" | "eqp_itm" | "eqp_loc" | "eqp_mdl" | "eqp_tpo" | "frn" | "rcg" | "stt" | "usr" | "usr_tpo" | "vwCarregador" | "vwOnibus" | "vwPostoRecarga"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      cbt: {
        payload: Prisma.$cbtPayload<ExtArgs>
        fields: Prisma.cbtFieldRefs
        operations: {
          findUnique: {
            args: Prisma.cbtFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$cbtPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.cbtFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$cbtPayload>
          }
          findFirst: {
            args: Prisma.cbtFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$cbtPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.cbtFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$cbtPayload>
          }
          findMany: {
            args: Prisma.cbtFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$cbtPayload>[]
          }
          create: {
            args: Prisma.cbtCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$cbtPayload>
          }
          createMany: {
            args: Prisma.cbtCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.cbtDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$cbtPayload>
          }
          update: {
            args: Prisma.cbtUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$cbtPayload>
          }
          deleteMany: {
            args: Prisma.cbtDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.cbtUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.cbtUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$cbtPayload>
          }
          aggregate: {
            args: Prisma.CbtAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCbt>
          }
          groupBy: {
            args: Prisma.cbtGroupByArgs<ExtArgs>
            result: $Utils.Optional<CbtGroupByOutputType>[]
          }
          count: {
            args: Prisma.cbtCountArgs<ExtArgs>
            result: $Utils.Optional<CbtCountAggregateOutputType> | number
          }
        }
      }
      emp: {
        payload: Prisma.$empPayload<ExtArgs>
        fields: Prisma.empFieldRefs
        operations: {
          findUnique: {
            args: Prisma.empFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$empPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.empFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$empPayload>
          }
          findFirst: {
            args: Prisma.empFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$empPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.empFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$empPayload>
          }
          findMany: {
            args: Prisma.empFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$empPayload>[]
          }
          create: {
            args: Prisma.empCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$empPayload>
          }
          createMany: {
            args: Prisma.empCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.empDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$empPayload>
          }
          update: {
            args: Prisma.empUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$empPayload>
          }
          deleteMany: {
            args: Prisma.empDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.empUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.empUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$empPayload>
          }
          aggregate: {
            args: Prisma.EmpAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEmp>
          }
          groupBy: {
            args: Prisma.empGroupByArgs<ExtArgs>
            result: $Utils.Optional<EmpGroupByOutputType>[]
          }
          count: {
            args: Prisma.empCountArgs<ExtArgs>
            result: $Utils.Optional<EmpCountAggregateOutputType> | number
          }
        }
      }
      emp_und: {
        payload: Prisma.$emp_undPayload<ExtArgs>
        fields: Prisma.emp_undFieldRefs
        operations: {
          findUnique: {
            args: Prisma.emp_undFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$emp_undPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.emp_undFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$emp_undPayload>
          }
          findFirst: {
            args: Prisma.emp_undFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$emp_undPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.emp_undFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$emp_undPayload>
          }
          findMany: {
            args: Prisma.emp_undFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$emp_undPayload>[]
          }
          create: {
            args: Prisma.emp_undCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$emp_undPayload>
          }
          createMany: {
            args: Prisma.emp_undCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.emp_undDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$emp_undPayload>
          }
          update: {
            args: Prisma.emp_undUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$emp_undPayload>
          }
          deleteMany: {
            args: Prisma.emp_undDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.emp_undUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.emp_undUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$emp_undPayload>
          }
          aggregate: {
            args: Prisma.Emp_undAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEmp_und>
          }
          groupBy: {
            args: Prisma.emp_undGroupByArgs<ExtArgs>
            result: $Utils.Optional<Emp_undGroupByOutputType>[]
          }
          count: {
            args: Prisma.emp_undCountArgs<ExtArgs>
            result: $Utils.Optional<Emp_undCountAggregateOutputType> | number
          }
        }
      }
      eqp_fbr: {
        payload: Prisma.$eqp_fbrPayload<ExtArgs>
        fields: Prisma.eqp_fbrFieldRefs
        operations: {
          findUnique: {
            args: Prisma.eqp_fbrFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_fbrPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.eqp_fbrFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_fbrPayload>
          }
          findFirst: {
            args: Prisma.eqp_fbrFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_fbrPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.eqp_fbrFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_fbrPayload>
          }
          findMany: {
            args: Prisma.eqp_fbrFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_fbrPayload>[]
          }
          create: {
            args: Prisma.eqp_fbrCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_fbrPayload>
          }
          createMany: {
            args: Prisma.eqp_fbrCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.eqp_fbrDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_fbrPayload>
          }
          update: {
            args: Prisma.eqp_fbrUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_fbrPayload>
          }
          deleteMany: {
            args: Prisma.eqp_fbrDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.eqp_fbrUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.eqp_fbrUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_fbrPayload>
          }
          aggregate: {
            args: Prisma.Eqp_fbrAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEqp_fbr>
          }
          groupBy: {
            args: Prisma.eqp_fbrGroupByArgs<ExtArgs>
            result: $Utils.Optional<Eqp_fbrGroupByOutputType>[]
          }
          count: {
            args: Prisma.eqp_fbrCountArgs<ExtArgs>
            result: $Utils.Optional<Eqp_fbrCountAggregateOutputType> | number
          }
        }
      }
      eqp_itm: {
        payload: Prisma.$eqp_itmPayload<ExtArgs>
        fields: Prisma.eqp_itmFieldRefs
        operations: {
          findUnique: {
            args: Prisma.eqp_itmFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_itmPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.eqp_itmFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_itmPayload>
          }
          findFirst: {
            args: Prisma.eqp_itmFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_itmPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.eqp_itmFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_itmPayload>
          }
          findMany: {
            args: Prisma.eqp_itmFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_itmPayload>[]
          }
          create: {
            args: Prisma.eqp_itmCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_itmPayload>
          }
          createMany: {
            args: Prisma.eqp_itmCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.eqp_itmDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_itmPayload>
          }
          update: {
            args: Prisma.eqp_itmUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_itmPayload>
          }
          deleteMany: {
            args: Prisma.eqp_itmDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.eqp_itmUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.eqp_itmUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_itmPayload>
          }
          aggregate: {
            args: Prisma.Eqp_itmAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEqp_itm>
          }
          groupBy: {
            args: Prisma.eqp_itmGroupByArgs<ExtArgs>
            result: $Utils.Optional<Eqp_itmGroupByOutputType>[]
          }
          count: {
            args: Prisma.eqp_itmCountArgs<ExtArgs>
            result: $Utils.Optional<Eqp_itmCountAggregateOutputType> | number
          }
        }
      }
      eqp_loc: {
        payload: Prisma.$eqp_locPayload<ExtArgs>
        fields: Prisma.eqp_locFieldRefs
        operations: {
          findUnique: {
            args: Prisma.eqp_locFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_locPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.eqp_locFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_locPayload>
          }
          findFirst: {
            args: Prisma.eqp_locFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_locPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.eqp_locFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_locPayload>
          }
          findMany: {
            args: Prisma.eqp_locFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_locPayload>[]
          }
          create: {
            args: Prisma.eqp_locCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_locPayload>
          }
          createMany: {
            args: Prisma.eqp_locCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.eqp_locDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_locPayload>
          }
          update: {
            args: Prisma.eqp_locUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_locPayload>
          }
          deleteMany: {
            args: Prisma.eqp_locDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.eqp_locUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.eqp_locUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_locPayload>
          }
          aggregate: {
            args: Prisma.Eqp_locAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEqp_loc>
          }
          groupBy: {
            args: Prisma.eqp_locGroupByArgs<ExtArgs>
            result: $Utils.Optional<Eqp_locGroupByOutputType>[]
          }
          count: {
            args: Prisma.eqp_locCountArgs<ExtArgs>
            result: $Utils.Optional<Eqp_locCountAggregateOutputType> | number
          }
        }
      }
      eqp_mdl: {
        payload: Prisma.$eqp_mdlPayload<ExtArgs>
        fields: Prisma.eqp_mdlFieldRefs
        operations: {
          findUnique: {
            args: Prisma.eqp_mdlFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_mdlPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.eqp_mdlFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_mdlPayload>
          }
          findFirst: {
            args: Prisma.eqp_mdlFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_mdlPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.eqp_mdlFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_mdlPayload>
          }
          findMany: {
            args: Prisma.eqp_mdlFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_mdlPayload>[]
          }
          create: {
            args: Prisma.eqp_mdlCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_mdlPayload>
          }
          createMany: {
            args: Prisma.eqp_mdlCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.eqp_mdlDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_mdlPayload>
          }
          update: {
            args: Prisma.eqp_mdlUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_mdlPayload>
          }
          deleteMany: {
            args: Prisma.eqp_mdlDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.eqp_mdlUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.eqp_mdlUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_mdlPayload>
          }
          aggregate: {
            args: Prisma.Eqp_mdlAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEqp_mdl>
          }
          groupBy: {
            args: Prisma.eqp_mdlGroupByArgs<ExtArgs>
            result: $Utils.Optional<Eqp_mdlGroupByOutputType>[]
          }
          count: {
            args: Prisma.eqp_mdlCountArgs<ExtArgs>
            result: $Utils.Optional<Eqp_mdlCountAggregateOutputType> | number
          }
        }
      }
      eqp_tpo: {
        payload: Prisma.$eqp_tpoPayload<ExtArgs>
        fields: Prisma.eqp_tpoFieldRefs
        operations: {
          findUnique: {
            args: Prisma.eqp_tpoFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_tpoPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.eqp_tpoFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_tpoPayload>
          }
          findFirst: {
            args: Prisma.eqp_tpoFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_tpoPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.eqp_tpoFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_tpoPayload>
          }
          findMany: {
            args: Prisma.eqp_tpoFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_tpoPayload>[]
          }
          create: {
            args: Prisma.eqp_tpoCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_tpoPayload>
          }
          createMany: {
            args: Prisma.eqp_tpoCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.eqp_tpoDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_tpoPayload>
          }
          update: {
            args: Prisma.eqp_tpoUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_tpoPayload>
          }
          deleteMany: {
            args: Prisma.eqp_tpoDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.eqp_tpoUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.eqp_tpoUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$eqp_tpoPayload>
          }
          aggregate: {
            args: Prisma.Eqp_tpoAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEqp_tpo>
          }
          groupBy: {
            args: Prisma.eqp_tpoGroupByArgs<ExtArgs>
            result: $Utils.Optional<Eqp_tpoGroupByOutputType>[]
          }
          count: {
            args: Prisma.eqp_tpoCountArgs<ExtArgs>
            result: $Utils.Optional<Eqp_tpoCountAggregateOutputType> | number
          }
        }
      }
      frn: {
        payload: Prisma.$frnPayload<ExtArgs>
        fields: Prisma.frnFieldRefs
        operations: {
          findUnique: {
            args: Prisma.frnFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$frnPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.frnFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$frnPayload>
          }
          findFirst: {
            args: Prisma.frnFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$frnPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.frnFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$frnPayload>
          }
          findMany: {
            args: Prisma.frnFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$frnPayload>[]
          }
          create: {
            args: Prisma.frnCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$frnPayload>
          }
          createMany: {
            args: Prisma.frnCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.frnDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$frnPayload>
          }
          update: {
            args: Prisma.frnUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$frnPayload>
          }
          deleteMany: {
            args: Prisma.frnDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.frnUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.frnUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$frnPayload>
          }
          aggregate: {
            args: Prisma.FrnAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateFrn>
          }
          groupBy: {
            args: Prisma.frnGroupByArgs<ExtArgs>
            result: $Utils.Optional<FrnGroupByOutputType>[]
          }
          count: {
            args: Prisma.frnCountArgs<ExtArgs>
            result: $Utils.Optional<FrnCountAggregateOutputType> | number
          }
        }
      }
      rcg: {
        payload: Prisma.$rcgPayload<ExtArgs>
        fields: Prisma.rcgFieldRefs
        operations: {
          findUnique: {
            args: Prisma.rcgFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rcgPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.rcgFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rcgPayload>
          }
          findFirst: {
            args: Prisma.rcgFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rcgPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.rcgFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rcgPayload>
          }
          findMany: {
            args: Prisma.rcgFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rcgPayload>[]
          }
          create: {
            args: Prisma.rcgCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rcgPayload>
          }
          createMany: {
            args: Prisma.rcgCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.rcgDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rcgPayload>
          }
          update: {
            args: Prisma.rcgUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rcgPayload>
          }
          deleteMany: {
            args: Prisma.rcgDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.rcgUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.rcgUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$rcgPayload>
          }
          aggregate: {
            args: Prisma.RcgAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateRcg>
          }
          groupBy: {
            args: Prisma.rcgGroupByArgs<ExtArgs>
            result: $Utils.Optional<RcgGroupByOutputType>[]
          }
          count: {
            args: Prisma.rcgCountArgs<ExtArgs>
            result: $Utils.Optional<RcgCountAggregateOutputType> | number
          }
        }
      }
      stt: {
        payload: Prisma.$sttPayload<ExtArgs>
        fields: Prisma.sttFieldRefs
        operations: {
          findUnique: {
            args: Prisma.sttFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$sttPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.sttFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$sttPayload>
          }
          findFirst: {
            args: Prisma.sttFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$sttPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.sttFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$sttPayload>
          }
          findMany: {
            args: Prisma.sttFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$sttPayload>[]
          }
          create: {
            args: Prisma.sttCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$sttPayload>
          }
          createMany: {
            args: Prisma.sttCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.sttDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$sttPayload>
          }
          update: {
            args: Prisma.sttUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$sttPayload>
          }
          deleteMany: {
            args: Prisma.sttDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.sttUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.sttUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$sttPayload>
          }
          aggregate: {
            args: Prisma.SttAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateStt>
          }
          groupBy: {
            args: Prisma.sttGroupByArgs<ExtArgs>
            result: $Utils.Optional<SttGroupByOutputType>[]
          }
          count: {
            args: Prisma.sttCountArgs<ExtArgs>
            result: $Utils.Optional<SttCountAggregateOutputType> | number
          }
        }
      }
      usr: {
        payload: Prisma.$usrPayload<ExtArgs>
        fields: Prisma.usrFieldRefs
        operations: {
          findUnique: {
            args: Prisma.usrFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usrPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.usrFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usrPayload>
          }
          findFirst: {
            args: Prisma.usrFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usrPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.usrFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usrPayload>
          }
          findMany: {
            args: Prisma.usrFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usrPayload>[]
          }
          create: {
            args: Prisma.usrCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usrPayload>
          }
          createMany: {
            args: Prisma.usrCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.usrDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usrPayload>
          }
          update: {
            args: Prisma.usrUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usrPayload>
          }
          deleteMany: {
            args: Prisma.usrDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.usrUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.usrUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usrPayload>
          }
          aggregate: {
            args: Prisma.UsrAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUsr>
          }
          groupBy: {
            args: Prisma.usrGroupByArgs<ExtArgs>
            result: $Utils.Optional<UsrGroupByOutputType>[]
          }
          count: {
            args: Prisma.usrCountArgs<ExtArgs>
            result: $Utils.Optional<UsrCountAggregateOutputType> | number
          }
        }
      }
      usr_tpo: {
        payload: Prisma.$usr_tpoPayload<ExtArgs>
        fields: Prisma.usr_tpoFieldRefs
        operations: {
          findUnique: {
            args: Prisma.usr_tpoFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usr_tpoPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.usr_tpoFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usr_tpoPayload>
          }
          findFirst: {
            args: Prisma.usr_tpoFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usr_tpoPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.usr_tpoFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usr_tpoPayload>
          }
          findMany: {
            args: Prisma.usr_tpoFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usr_tpoPayload>[]
          }
          create: {
            args: Prisma.usr_tpoCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usr_tpoPayload>
          }
          createMany: {
            args: Prisma.usr_tpoCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.usr_tpoDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usr_tpoPayload>
          }
          update: {
            args: Prisma.usr_tpoUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usr_tpoPayload>
          }
          deleteMany: {
            args: Prisma.usr_tpoDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.usr_tpoUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.usr_tpoUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$usr_tpoPayload>
          }
          aggregate: {
            args: Prisma.Usr_tpoAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUsr_tpo>
          }
          groupBy: {
            args: Prisma.usr_tpoGroupByArgs<ExtArgs>
            result: $Utils.Optional<Usr_tpoGroupByOutputType>[]
          }
          count: {
            args: Prisma.usr_tpoCountArgs<ExtArgs>
            result: $Utils.Optional<Usr_tpoCountAggregateOutputType> | number
          }
        }
      }
      VwCarregador: {
        payload: Prisma.$VwCarregadorPayload<ExtArgs>
        fields: Prisma.VwCarregadorFieldRefs
        operations: {
          findUnique: {
            args: Prisma.VwCarregadorFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwCarregadorPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.VwCarregadorFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwCarregadorPayload>
          }
          findFirst: {
            args: Prisma.VwCarregadorFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwCarregadorPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.VwCarregadorFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwCarregadorPayload>
          }
          findMany: {
            args: Prisma.VwCarregadorFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwCarregadorPayload>[]
          }
          create: {
            args: Prisma.VwCarregadorCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwCarregadorPayload>
          }
          createMany: {
            args: Prisma.VwCarregadorCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.VwCarregadorDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwCarregadorPayload>
          }
          update: {
            args: Prisma.VwCarregadorUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwCarregadorPayload>
          }
          deleteMany: {
            args: Prisma.VwCarregadorDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.VwCarregadorUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.VwCarregadorUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwCarregadorPayload>
          }
          aggregate: {
            args: Prisma.VwCarregadorAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateVwCarregador>
          }
          groupBy: {
            args: Prisma.VwCarregadorGroupByArgs<ExtArgs>
            result: $Utils.Optional<VwCarregadorGroupByOutputType>[]
          }
          count: {
            args: Prisma.VwCarregadorCountArgs<ExtArgs>
            result: $Utils.Optional<VwCarregadorCountAggregateOutputType> | number
          }
        }
      }
      VwOnibus: {
        payload: Prisma.$VwOnibusPayload<ExtArgs>
        fields: Prisma.VwOnibusFieldRefs
        operations: {
          findUnique: {
            args: Prisma.VwOnibusFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwOnibusPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.VwOnibusFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwOnibusPayload>
          }
          findFirst: {
            args: Prisma.VwOnibusFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwOnibusPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.VwOnibusFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwOnibusPayload>
          }
          findMany: {
            args: Prisma.VwOnibusFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwOnibusPayload>[]
          }
          create: {
            args: Prisma.VwOnibusCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwOnibusPayload>
          }
          createMany: {
            args: Prisma.VwOnibusCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.VwOnibusDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwOnibusPayload>
          }
          update: {
            args: Prisma.VwOnibusUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwOnibusPayload>
          }
          deleteMany: {
            args: Prisma.VwOnibusDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.VwOnibusUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.VwOnibusUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwOnibusPayload>
          }
          aggregate: {
            args: Prisma.VwOnibusAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateVwOnibus>
          }
          groupBy: {
            args: Prisma.VwOnibusGroupByArgs<ExtArgs>
            result: $Utils.Optional<VwOnibusGroupByOutputType>[]
          }
          count: {
            args: Prisma.VwOnibusCountArgs<ExtArgs>
            result: $Utils.Optional<VwOnibusCountAggregateOutputType> | number
          }
        }
      }
      VwPostoRecarga: {
        payload: Prisma.$VwPostoRecargaPayload<ExtArgs>
        fields: Prisma.VwPostoRecargaFieldRefs
        operations: {
          findUnique: {
            args: Prisma.VwPostoRecargaFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwPostoRecargaPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.VwPostoRecargaFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwPostoRecargaPayload>
          }
          findFirst: {
            args: Prisma.VwPostoRecargaFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwPostoRecargaPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.VwPostoRecargaFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwPostoRecargaPayload>
          }
          findMany: {
            args: Prisma.VwPostoRecargaFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwPostoRecargaPayload>[]
          }
          create: {
            args: Prisma.VwPostoRecargaCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwPostoRecargaPayload>
          }
          createMany: {
            args: Prisma.VwPostoRecargaCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          delete: {
            args: Prisma.VwPostoRecargaDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwPostoRecargaPayload>
          }
          update: {
            args: Prisma.VwPostoRecargaUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwPostoRecargaPayload>
          }
          deleteMany: {
            args: Prisma.VwPostoRecargaDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.VwPostoRecargaUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          upsert: {
            args: Prisma.VwPostoRecargaUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VwPostoRecargaPayload>
          }
          aggregate: {
            args: Prisma.VwPostoRecargaAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateVwPostoRecarga>
          }
          groupBy: {
            args: Prisma.VwPostoRecargaGroupByArgs<ExtArgs>
            result: $Utils.Optional<VwPostoRecargaGroupByOutputType>[]
          }
          count: {
            args: Prisma.VwPostoRecargaCountArgs<ExtArgs>
            result: $Utils.Optional<VwPostoRecargaCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    cbt?: cbtOmit
    emp?: empOmit
    emp_und?: emp_undOmit
    eqp_fbr?: eqp_fbrOmit
    eqp_itm?: eqp_itmOmit
    eqp_loc?: eqp_locOmit
    eqp_mdl?: eqp_mdlOmit
    eqp_tpo?: eqp_tpoOmit
    frn?: frnOmit
    rcg?: rcgOmit
    stt?: sttOmit
    usr?: usrOmit
    usr_tpo?: usr_tpoOmit
    vwCarregador?: VwCarregadorOmit
    vwOnibus?: VwOnibusOmit
    vwPostoRecarga?: VwPostoRecargaOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */



  /**
   * Models
   */

  /**
   * Model cbt
   */

  export type AggregateCbt = {
    _count: CbtCountAggregateOutputType | null
    _avg: CbtAvgAggregateOutputType | null
    _sum: CbtSumAggregateOutputType | null
    _min: CbtMinAggregateOutputType | null
    _max: CbtMaxAggregateOutputType | null
  }

  export type CbtAvgAggregateOutputType = {
    CbtId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type CbtSumAggregateOutputType = {
    CbtId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type CbtMinAggregateOutputType = {
    CbtId: number | null
    CbtNme: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type CbtMaxAggregateOutputType = {
    CbtId: number | null
    CbtNme: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type CbtCountAggregateOutputType = {
    CbtId: number
    CbtNme: number
    SttId: number
    UsrIdAlt: number
    DtaAlt: number
    MtvDel: number
    _all: number
  }


  export type CbtAvgAggregateInputType = {
    CbtId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type CbtSumAggregateInputType = {
    CbtId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type CbtMinAggregateInputType = {
    CbtId?: true
    CbtNme?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type CbtMaxAggregateInputType = {
    CbtId?: true
    CbtNme?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type CbtCountAggregateInputType = {
    CbtId?: true
    CbtNme?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
    _all?: true
  }

  export type CbtAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which cbt to aggregate.
     */
    where?: cbtWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of cbts to fetch.
     */
    orderBy?: cbtOrderByWithRelationInput | cbtOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: cbtWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` cbts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` cbts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned cbts
    **/
    _count?: true | CbtCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: CbtAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: CbtSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CbtMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CbtMaxAggregateInputType
  }

  export type GetCbtAggregateType<T extends CbtAggregateArgs> = {
        [P in keyof T & keyof AggregateCbt]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCbt[P]>
      : GetScalarType<T[P], AggregateCbt[P]>
  }




  export type cbtGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: cbtWhereInput
    orderBy?: cbtOrderByWithAggregationInput | cbtOrderByWithAggregationInput[]
    by: CbtScalarFieldEnum[] | CbtScalarFieldEnum
    having?: cbtScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CbtCountAggregateInputType | true
    _avg?: CbtAvgAggregateInputType
    _sum?: CbtSumAggregateInputType
    _min?: CbtMinAggregateInputType
    _max?: CbtMaxAggregateInputType
  }

  export type CbtGroupByOutputType = {
    CbtId: number
    CbtNme: string
    SttId: number
    UsrIdAlt: number
    DtaAlt: Date
    MtvDel: string | null
    _count: CbtCountAggregateOutputType | null
    _avg: CbtAvgAggregateOutputType | null
    _sum: CbtSumAggregateOutputType | null
    _min: CbtMinAggregateOutputType | null
    _max: CbtMaxAggregateOutputType | null
  }

  type GetCbtGroupByPayload<T extends cbtGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CbtGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CbtGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CbtGroupByOutputType[P]>
            : GetScalarType<T[P], CbtGroupByOutputType[P]>
        }
      >
    >


  export type cbtSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    CbtId?: boolean
    CbtNme?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }, ExtArgs["result"]["cbt"]>



  export type cbtSelectScalar = {
    CbtId?: boolean
    CbtNme?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }

  export type cbtOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"CbtId" | "CbtNme" | "SttId" | "UsrIdAlt" | "DtaAlt" | "MtvDel", ExtArgs["result"]["cbt"]>

  export type $cbtPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "cbt"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      CbtId: number
      CbtNme: string
      SttId: number
      UsrIdAlt: number
      DtaAlt: Date
      MtvDel: string | null
    }, ExtArgs["result"]["cbt"]>
    composites: {}
  }

  type cbtGetPayload<S extends boolean | null | undefined | cbtDefaultArgs> = $Result.GetResult<Prisma.$cbtPayload, S>

  type cbtCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<cbtFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: CbtCountAggregateInputType | true
    }

  export interface cbtDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['cbt'], meta: { name: 'cbt' } }
    /**
     * Find zero or one Cbt that matches the filter.
     * @param {cbtFindUniqueArgs} args - Arguments to find a Cbt
     * @example
     * // Get one Cbt
     * const cbt = await prisma.cbt.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends cbtFindUniqueArgs>(args: SelectSubset<T, cbtFindUniqueArgs<ExtArgs>>): Prisma__cbtClient<$Result.GetResult<Prisma.$cbtPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Cbt that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {cbtFindUniqueOrThrowArgs} args - Arguments to find a Cbt
     * @example
     * // Get one Cbt
     * const cbt = await prisma.cbt.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends cbtFindUniqueOrThrowArgs>(args: SelectSubset<T, cbtFindUniqueOrThrowArgs<ExtArgs>>): Prisma__cbtClient<$Result.GetResult<Prisma.$cbtPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Cbt that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {cbtFindFirstArgs} args - Arguments to find a Cbt
     * @example
     * // Get one Cbt
     * const cbt = await prisma.cbt.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends cbtFindFirstArgs>(args?: SelectSubset<T, cbtFindFirstArgs<ExtArgs>>): Prisma__cbtClient<$Result.GetResult<Prisma.$cbtPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Cbt that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {cbtFindFirstOrThrowArgs} args - Arguments to find a Cbt
     * @example
     * // Get one Cbt
     * const cbt = await prisma.cbt.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends cbtFindFirstOrThrowArgs>(args?: SelectSubset<T, cbtFindFirstOrThrowArgs<ExtArgs>>): Prisma__cbtClient<$Result.GetResult<Prisma.$cbtPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Cbts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {cbtFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Cbts
     * const cbts = await prisma.cbt.findMany()
     * 
     * // Get first 10 Cbts
     * const cbts = await prisma.cbt.findMany({ take: 10 })
     * 
     * // Only select the `CbtId`
     * const cbtWithCbtIdOnly = await prisma.cbt.findMany({ select: { CbtId: true } })
     * 
     */
    findMany<T extends cbtFindManyArgs>(args?: SelectSubset<T, cbtFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$cbtPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Cbt.
     * @param {cbtCreateArgs} args - Arguments to create a Cbt.
     * @example
     * // Create one Cbt
     * const Cbt = await prisma.cbt.create({
     *   data: {
     *     // ... data to create a Cbt
     *   }
     * })
     * 
     */
    create<T extends cbtCreateArgs>(args: SelectSubset<T, cbtCreateArgs<ExtArgs>>): Prisma__cbtClient<$Result.GetResult<Prisma.$cbtPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Cbts.
     * @param {cbtCreateManyArgs} args - Arguments to create many Cbts.
     * @example
     * // Create many Cbts
     * const cbt = await prisma.cbt.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends cbtCreateManyArgs>(args?: SelectSubset<T, cbtCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Cbt.
     * @param {cbtDeleteArgs} args - Arguments to delete one Cbt.
     * @example
     * // Delete one Cbt
     * const Cbt = await prisma.cbt.delete({
     *   where: {
     *     // ... filter to delete one Cbt
     *   }
     * })
     * 
     */
    delete<T extends cbtDeleteArgs>(args: SelectSubset<T, cbtDeleteArgs<ExtArgs>>): Prisma__cbtClient<$Result.GetResult<Prisma.$cbtPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Cbt.
     * @param {cbtUpdateArgs} args - Arguments to update one Cbt.
     * @example
     * // Update one Cbt
     * const cbt = await prisma.cbt.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends cbtUpdateArgs>(args: SelectSubset<T, cbtUpdateArgs<ExtArgs>>): Prisma__cbtClient<$Result.GetResult<Prisma.$cbtPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Cbts.
     * @param {cbtDeleteManyArgs} args - Arguments to filter Cbts to delete.
     * @example
     * // Delete a few Cbts
     * const { count } = await prisma.cbt.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends cbtDeleteManyArgs>(args?: SelectSubset<T, cbtDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Cbts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {cbtUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Cbts
     * const cbt = await prisma.cbt.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends cbtUpdateManyArgs>(args: SelectSubset<T, cbtUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Cbt.
     * @param {cbtUpsertArgs} args - Arguments to update or create a Cbt.
     * @example
     * // Update or create a Cbt
     * const cbt = await prisma.cbt.upsert({
     *   create: {
     *     // ... data to create a Cbt
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Cbt we want to update
     *   }
     * })
     */
    upsert<T extends cbtUpsertArgs>(args: SelectSubset<T, cbtUpsertArgs<ExtArgs>>): Prisma__cbtClient<$Result.GetResult<Prisma.$cbtPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Cbts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {cbtCountArgs} args - Arguments to filter Cbts to count.
     * @example
     * // Count the number of Cbts
     * const count = await prisma.cbt.count({
     *   where: {
     *     // ... the filter for the Cbts we want to count
     *   }
     * })
    **/
    count<T extends cbtCountArgs>(
      args?: Subset<T, cbtCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CbtCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Cbt.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CbtAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CbtAggregateArgs>(args: Subset<T, CbtAggregateArgs>): Prisma.PrismaPromise<GetCbtAggregateType<T>>

    /**
     * Group by Cbt.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {cbtGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends cbtGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: cbtGroupByArgs['orderBy'] }
        : { orderBy?: cbtGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, cbtGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCbtGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the cbt model
   */
  readonly fields: cbtFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for cbt.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__cbtClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the cbt model
   */
  interface cbtFieldRefs {
    readonly CbtId: FieldRef<"cbt", 'Int'>
    readonly CbtNme: FieldRef<"cbt", 'String'>
    readonly SttId: FieldRef<"cbt", 'Int'>
    readonly UsrIdAlt: FieldRef<"cbt", 'Int'>
    readonly DtaAlt: FieldRef<"cbt", 'DateTime'>
    readonly MtvDel: FieldRef<"cbt", 'String'>
  }
    

  // Custom InputTypes
  /**
   * cbt findUnique
   */
  export type cbtFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the cbt
     */
    select?: cbtSelect<ExtArgs> | null
    /**
     * Omit specific fields from the cbt
     */
    omit?: cbtOmit<ExtArgs> | null
    /**
     * Filter, which cbt to fetch.
     */
    where: cbtWhereUniqueInput
  }

  /**
   * cbt findUniqueOrThrow
   */
  export type cbtFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the cbt
     */
    select?: cbtSelect<ExtArgs> | null
    /**
     * Omit specific fields from the cbt
     */
    omit?: cbtOmit<ExtArgs> | null
    /**
     * Filter, which cbt to fetch.
     */
    where: cbtWhereUniqueInput
  }

  /**
   * cbt findFirst
   */
  export type cbtFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the cbt
     */
    select?: cbtSelect<ExtArgs> | null
    /**
     * Omit specific fields from the cbt
     */
    omit?: cbtOmit<ExtArgs> | null
    /**
     * Filter, which cbt to fetch.
     */
    where?: cbtWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of cbts to fetch.
     */
    orderBy?: cbtOrderByWithRelationInput | cbtOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for cbts.
     */
    cursor?: cbtWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` cbts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` cbts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of cbts.
     */
    distinct?: CbtScalarFieldEnum | CbtScalarFieldEnum[]
  }

  /**
   * cbt findFirstOrThrow
   */
  export type cbtFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the cbt
     */
    select?: cbtSelect<ExtArgs> | null
    /**
     * Omit specific fields from the cbt
     */
    omit?: cbtOmit<ExtArgs> | null
    /**
     * Filter, which cbt to fetch.
     */
    where?: cbtWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of cbts to fetch.
     */
    orderBy?: cbtOrderByWithRelationInput | cbtOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for cbts.
     */
    cursor?: cbtWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` cbts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` cbts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of cbts.
     */
    distinct?: CbtScalarFieldEnum | CbtScalarFieldEnum[]
  }

  /**
   * cbt findMany
   */
  export type cbtFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the cbt
     */
    select?: cbtSelect<ExtArgs> | null
    /**
     * Omit specific fields from the cbt
     */
    omit?: cbtOmit<ExtArgs> | null
    /**
     * Filter, which cbts to fetch.
     */
    where?: cbtWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of cbts to fetch.
     */
    orderBy?: cbtOrderByWithRelationInput | cbtOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing cbts.
     */
    cursor?: cbtWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` cbts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` cbts.
     */
    skip?: number
    distinct?: CbtScalarFieldEnum | CbtScalarFieldEnum[]
  }

  /**
   * cbt create
   */
  export type cbtCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the cbt
     */
    select?: cbtSelect<ExtArgs> | null
    /**
     * Omit specific fields from the cbt
     */
    omit?: cbtOmit<ExtArgs> | null
    /**
     * The data needed to create a cbt.
     */
    data: XOR<cbtCreateInput, cbtUncheckedCreateInput>
  }

  /**
   * cbt createMany
   */
  export type cbtCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many cbts.
     */
    data: cbtCreateManyInput | cbtCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * cbt update
   */
  export type cbtUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the cbt
     */
    select?: cbtSelect<ExtArgs> | null
    /**
     * Omit specific fields from the cbt
     */
    omit?: cbtOmit<ExtArgs> | null
    /**
     * The data needed to update a cbt.
     */
    data: XOR<cbtUpdateInput, cbtUncheckedUpdateInput>
    /**
     * Choose, which cbt to update.
     */
    where: cbtWhereUniqueInput
  }

  /**
   * cbt updateMany
   */
  export type cbtUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update cbts.
     */
    data: XOR<cbtUpdateManyMutationInput, cbtUncheckedUpdateManyInput>
    /**
     * Filter which cbts to update
     */
    where?: cbtWhereInput
    /**
     * Limit how many cbts to update.
     */
    limit?: number
  }

  /**
   * cbt upsert
   */
  export type cbtUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the cbt
     */
    select?: cbtSelect<ExtArgs> | null
    /**
     * Omit specific fields from the cbt
     */
    omit?: cbtOmit<ExtArgs> | null
    /**
     * The filter to search for the cbt to update in case it exists.
     */
    where: cbtWhereUniqueInput
    /**
     * In case the cbt found by the `where` argument doesn't exist, create a new cbt with this data.
     */
    create: XOR<cbtCreateInput, cbtUncheckedCreateInput>
    /**
     * In case the cbt was found with the provided `where` argument, update it with this data.
     */
    update: XOR<cbtUpdateInput, cbtUncheckedUpdateInput>
  }

  /**
   * cbt delete
   */
  export type cbtDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the cbt
     */
    select?: cbtSelect<ExtArgs> | null
    /**
     * Omit specific fields from the cbt
     */
    omit?: cbtOmit<ExtArgs> | null
    /**
     * Filter which cbt to delete.
     */
    where: cbtWhereUniqueInput
  }

  /**
   * cbt deleteMany
   */
  export type cbtDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which cbts to delete
     */
    where?: cbtWhereInput
    /**
     * Limit how many cbts to delete.
     */
    limit?: number
  }

  /**
   * cbt without action
   */
  export type cbtDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the cbt
     */
    select?: cbtSelect<ExtArgs> | null
    /**
     * Omit specific fields from the cbt
     */
    omit?: cbtOmit<ExtArgs> | null
  }


  /**
   * Model emp
   */

  export type AggregateEmp = {
    _count: EmpCountAggregateOutputType | null
    _avg: EmpAvgAggregateOutputType | null
    _sum: EmpSumAggregateOutputType | null
    _min: EmpMinAggregateOutputType | null
    _max: EmpMaxAggregateOutputType | null
  }

  export type EmpAvgAggregateOutputType = {
    EmpId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type EmpSumAggregateOutputType = {
    EmpId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type EmpMinAggregateOutputType = {
    EmpId: number | null
    EmpNme: string | null
    EmpRaz: string | null
    EmpRdz: string | null
    EmpAtv: string | null
    EmpCnpj: string | null
    Enduf: string | null
    EndCdd: string | null
    EndLtt: string | null
    EndLgt: string | null
    EndCep: string | null
    EndEmp: string | null
    EndCpl: string | null
    EmpLgo: string | null
    EmpUrl: string | null
    EmlCtt: string | null
    EmlFrm: string | null
    EmlFrmPwd: string | null
    FneCtt: string | null
    FneWha: string | null
    RssIns: string | null
    RssFac: string | null
    RssTwi: string | null
    RssYou: string | null
    TpoPix: string | null
    ChvPix: string | null
    QRPixImg: string | null
    QRPixCpy: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type EmpMaxAggregateOutputType = {
    EmpId: number | null
    EmpNme: string | null
    EmpRaz: string | null
    EmpRdz: string | null
    EmpAtv: string | null
    EmpCnpj: string | null
    Enduf: string | null
    EndCdd: string | null
    EndLtt: string | null
    EndLgt: string | null
    EndCep: string | null
    EndEmp: string | null
    EndCpl: string | null
    EmpLgo: string | null
    EmpUrl: string | null
    EmlCtt: string | null
    EmlFrm: string | null
    EmlFrmPwd: string | null
    FneCtt: string | null
    FneWha: string | null
    RssIns: string | null
    RssFac: string | null
    RssTwi: string | null
    RssYou: string | null
    TpoPix: string | null
    ChvPix: string | null
    QRPixImg: string | null
    QRPixCpy: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type EmpCountAggregateOutputType = {
    EmpId: number
    EmpNme: number
    EmpRaz: number
    EmpRdz: number
    EmpAtv: number
    EmpCnpj: number
    Enduf: number
    EndCdd: number
    EndLtt: number
    EndLgt: number
    EndCep: number
    EndEmp: number
    EndCpl: number
    EmpLgo: number
    EmpUrl: number
    EmlCtt: number
    EmlFrm: number
    EmlFrmPwd: number
    FneCtt: number
    FneWha: number
    RssIns: number
    RssFac: number
    RssTwi: number
    RssYou: number
    TpoPix: number
    ChvPix: number
    QRPixImg: number
    QRPixCpy: number
    SttId: number
    UsrIdAlt: number
    DtaAlt: number
    MtvDel: number
    _all: number
  }


  export type EmpAvgAggregateInputType = {
    EmpId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type EmpSumAggregateInputType = {
    EmpId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type EmpMinAggregateInputType = {
    EmpId?: true
    EmpNme?: true
    EmpRaz?: true
    EmpRdz?: true
    EmpAtv?: true
    EmpCnpj?: true
    Enduf?: true
    EndCdd?: true
    EndLtt?: true
    EndLgt?: true
    EndCep?: true
    EndEmp?: true
    EndCpl?: true
    EmpLgo?: true
    EmpUrl?: true
    EmlCtt?: true
    EmlFrm?: true
    EmlFrmPwd?: true
    FneCtt?: true
    FneWha?: true
    RssIns?: true
    RssFac?: true
    RssTwi?: true
    RssYou?: true
    TpoPix?: true
    ChvPix?: true
    QRPixImg?: true
    QRPixCpy?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type EmpMaxAggregateInputType = {
    EmpId?: true
    EmpNme?: true
    EmpRaz?: true
    EmpRdz?: true
    EmpAtv?: true
    EmpCnpj?: true
    Enduf?: true
    EndCdd?: true
    EndLtt?: true
    EndLgt?: true
    EndCep?: true
    EndEmp?: true
    EndCpl?: true
    EmpLgo?: true
    EmpUrl?: true
    EmlCtt?: true
    EmlFrm?: true
    EmlFrmPwd?: true
    FneCtt?: true
    FneWha?: true
    RssIns?: true
    RssFac?: true
    RssTwi?: true
    RssYou?: true
    TpoPix?: true
    ChvPix?: true
    QRPixImg?: true
    QRPixCpy?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type EmpCountAggregateInputType = {
    EmpId?: true
    EmpNme?: true
    EmpRaz?: true
    EmpRdz?: true
    EmpAtv?: true
    EmpCnpj?: true
    Enduf?: true
    EndCdd?: true
    EndLtt?: true
    EndLgt?: true
    EndCep?: true
    EndEmp?: true
    EndCpl?: true
    EmpLgo?: true
    EmpUrl?: true
    EmlCtt?: true
    EmlFrm?: true
    EmlFrmPwd?: true
    FneCtt?: true
    FneWha?: true
    RssIns?: true
    RssFac?: true
    RssTwi?: true
    RssYou?: true
    TpoPix?: true
    ChvPix?: true
    QRPixImg?: true
    QRPixCpy?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
    _all?: true
  }

  export type EmpAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which emp to aggregate.
     */
    where?: empWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of emps to fetch.
     */
    orderBy?: empOrderByWithRelationInput | empOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: empWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` emps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` emps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned emps
    **/
    _count?: true | EmpCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: EmpAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: EmpSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: EmpMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: EmpMaxAggregateInputType
  }

  export type GetEmpAggregateType<T extends EmpAggregateArgs> = {
        [P in keyof T & keyof AggregateEmp]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEmp[P]>
      : GetScalarType<T[P], AggregateEmp[P]>
  }




  export type empGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: empWhereInput
    orderBy?: empOrderByWithAggregationInput | empOrderByWithAggregationInput[]
    by: EmpScalarFieldEnum[] | EmpScalarFieldEnum
    having?: empScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: EmpCountAggregateInputType | true
    _avg?: EmpAvgAggregateInputType
    _sum?: EmpSumAggregateInputType
    _min?: EmpMinAggregateInputType
    _max?: EmpMaxAggregateInputType
  }

  export type EmpGroupByOutputType = {
    EmpId: number
    EmpNme: string
    EmpRaz: string | null
    EmpRdz: string | null
    EmpAtv: string | null
    EmpCnpj: string | null
    Enduf: string | null
    EndCdd: string | null
    EndLtt: string | null
    EndLgt: string | null
    EndCep: string | null
    EndEmp: string | null
    EndCpl: string | null
    EmpLgo: string | null
    EmpUrl: string | null
    EmlCtt: string | null
    EmlFrm: string | null
    EmlFrmPwd: string | null
    FneCtt: string | null
    FneWha: string | null
    RssIns: string | null
    RssFac: string | null
    RssTwi: string | null
    RssYou: string | null
    TpoPix: string | null
    ChvPix: string | null
    QRPixImg: string | null
    QRPixCpy: string | null
    SttId: number
    UsrIdAlt: number
    DtaAlt: Date
    MtvDel: string | null
    _count: EmpCountAggregateOutputType | null
    _avg: EmpAvgAggregateOutputType | null
    _sum: EmpSumAggregateOutputType | null
    _min: EmpMinAggregateOutputType | null
    _max: EmpMaxAggregateOutputType | null
  }

  type GetEmpGroupByPayload<T extends empGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<EmpGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof EmpGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], EmpGroupByOutputType[P]>
            : GetScalarType<T[P], EmpGroupByOutputType[P]>
        }
      >
    >


  export type empSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    EmpId?: boolean
    EmpNme?: boolean
    EmpRaz?: boolean
    EmpRdz?: boolean
    EmpAtv?: boolean
    EmpCnpj?: boolean
    Enduf?: boolean
    EndCdd?: boolean
    EndLtt?: boolean
    EndLgt?: boolean
    EndCep?: boolean
    EndEmp?: boolean
    EndCpl?: boolean
    EmpLgo?: boolean
    EmpUrl?: boolean
    EmlCtt?: boolean
    EmlFrm?: boolean
    EmlFrmPwd?: boolean
    FneCtt?: boolean
    FneWha?: boolean
    RssIns?: boolean
    RssFac?: boolean
    RssTwi?: boolean
    RssYou?: boolean
    TpoPix?: boolean
    ChvPix?: boolean
    QRPixImg?: boolean
    QRPixCpy?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }, ExtArgs["result"]["emp"]>



  export type empSelectScalar = {
    EmpId?: boolean
    EmpNme?: boolean
    EmpRaz?: boolean
    EmpRdz?: boolean
    EmpAtv?: boolean
    EmpCnpj?: boolean
    Enduf?: boolean
    EndCdd?: boolean
    EndLtt?: boolean
    EndLgt?: boolean
    EndCep?: boolean
    EndEmp?: boolean
    EndCpl?: boolean
    EmpLgo?: boolean
    EmpUrl?: boolean
    EmlCtt?: boolean
    EmlFrm?: boolean
    EmlFrmPwd?: boolean
    FneCtt?: boolean
    FneWha?: boolean
    RssIns?: boolean
    RssFac?: boolean
    RssTwi?: boolean
    RssYou?: boolean
    TpoPix?: boolean
    ChvPix?: boolean
    QRPixImg?: boolean
    QRPixCpy?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }

  export type empOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"EmpId" | "EmpNme" | "EmpRaz" | "EmpRdz" | "EmpAtv" | "EmpCnpj" | "Enduf" | "EndCdd" | "EndLtt" | "EndLgt" | "EndCep" | "EndEmp" | "EndCpl" | "EmpLgo" | "EmpUrl" | "EmlCtt" | "EmlFrm" | "EmlFrmPwd" | "FneCtt" | "FneWha" | "RssIns" | "RssFac" | "RssTwi" | "RssYou" | "TpoPix" | "ChvPix" | "QRPixImg" | "QRPixCpy" | "SttId" | "UsrIdAlt" | "DtaAlt" | "MtvDel", ExtArgs["result"]["emp"]>

  export type $empPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "emp"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      EmpId: number
      EmpNme: string
      EmpRaz: string | null
      EmpRdz: string | null
      EmpAtv: string | null
      EmpCnpj: string | null
      Enduf: string | null
      EndCdd: string | null
      EndLtt: string | null
      EndLgt: string | null
      EndCep: string | null
      EndEmp: string | null
      EndCpl: string | null
      EmpLgo: string | null
      EmpUrl: string | null
      EmlCtt: string | null
      EmlFrm: string | null
      EmlFrmPwd: string | null
      FneCtt: string | null
      FneWha: string | null
      RssIns: string | null
      RssFac: string | null
      RssTwi: string | null
      RssYou: string | null
      TpoPix: string | null
      ChvPix: string | null
      QRPixImg: string | null
      QRPixCpy: string | null
      SttId: number
      UsrIdAlt: number
      DtaAlt: Date
      MtvDel: string | null
    }, ExtArgs["result"]["emp"]>
    composites: {}
  }

  type empGetPayload<S extends boolean | null | undefined | empDefaultArgs> = $Result.GetResult<Prisma.$empPayload, S>

  type empCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<empFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: EmpCountAggregateInputType | true
    }

  export interface empDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['emp'], meta: { name: 'emp' } }
    /**
     * Find zero or one Emp that matches the filter.
     * @param {empFindUniqueArgs} args - Arguments to find a Emp
     * @example
     * // Get one Emp
     * const emp = await prisma.emp.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends empFindUniqueArgs>(args: SelectSubset<T, empFindUniqueArgs<ExtArgs>>): Prisma__empClient<$Result.GetResult<Prisma.$empPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Emp that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {empFindUniqueOrThrowArgs} args - Arguments to find a Emp
     * @example
     * // Get one Emp
     * const emp = await prisma.emp.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends empFindUniqueOrThrowArgs>(args: SelectSubset<T, empFindUniqueOrThrowArgs<ExtArgs>>): Prisma__empClient<$Result.GetResult<Prisma.$empPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Emp that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {empFindFirstArgs} args - Arguments to find a Emp
     * @example
     * // Get one Emp
     * const emp = await prisma.emp.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends empFindFirstArgs>(args?: SelectSubset<T, empFindFirstArgs<ExtArgs>>): Prisma__empClient<$Result.GetResult<Prisma.$empPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Emp that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {empFindFirstOrThrowArgs} args - Arguments to find a Emp
     * @example
     * // Get one Emp
     * const emp = await prisma.emp.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends empFindFirstOrThrowArgs>(args?: SelectSubset<T, empFindFirstOrThrowArgs<ExtArgs>>): Prisma__empClient<$Result.GetResult<Prisma.$empPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Emps that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {empFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Emps
     * const emps = await prisma.emp.findMany()
     * 
     * // Get first 10 Emps
     * const emps = await prisma.emp.findMany({ take: 10 })
     * 
     * // Only select the `EmpId`
     * const empWithEmpIdOnly = await prisma.emp.findMany({ select: { EmpId: true } })
     * 
     */
    findMany<T extends empFindManyArgs>(args?: SelectSubset<T, empFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$empPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Emp.
     * @param {empCreateArgs} args - Arguments to create a Emp.
     * @example
     * // Create one Emp
     * const Emp = await prisma.emp.create({
     *   data: {
     *     // ... data to create a Emp
     *   }
     * })
     * 
     */
    create<T extends empCreateArgs>(args: SelectSubset<T, empCreateArgs<ExtArgs>>): Prisma__empClient<$Result.GetResult<Prisma.$empPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Emps.
     * @param {empCreateManyArgs} args - Arguments to create many Emps.
     * @example
     * // Create many Emps
     * const emp = await prisma.emp.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends empCreateManyArgs>(args?: SelectSubset<T, empCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Emp.
     * @param {empDeleteArgs} args - Arguments to delete one Emp.
     * @example
     * // Delete one Emp
     * const Emp = await prisma.emp.delete({
     *   where: {
     *     // ... filter to delete one Emp
     *   }
     * })
     * 
     */
    delete<T extends empDeleteArgs>(args: SelectSubset<T, empDeleteArgs<ExtArgs>>): Prisma__empClient<$Result.GetResult<Prisma.$empPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Emp.
     * @param {empUpdateArgs} args - Arguments to update one Emp.
     * @example
     * // Update one Emp
     * const emp = await prisma.emp.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends empUpdateArgs>(args: SelectSubset<T, empUpdateArgs<ExtArgs>>): Prisma__empClient<$Result.GetResult<Prisma.$empPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Emps.
     * @param {empDeleteManyArgs} args - Arguments to filter Emps to delete.
     * @example
     * // Delete a few Emps
     * const { count } = await prisma.emp.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends empDeleteManyArgs>(args?: SelectSubset<T, empDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Emps.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {empUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Emps
     * const emp = await prisma.emp.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends empUpdateManyArgs>(args: SelectSubset<T, empUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Emp.
     * @param {empUpsertArgs} args - Arguments to update or create a Emp.
     * @example
     * // Update or create a Emp
     * const emp = await prisma.emp.upsert({
     *   create: {
     *     // ... data to create a Emp
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Emp we want to update
     *   }
     * })
     */
    upsert<T extends empUpsertArgs>(args: SelectSubset<T, empUpsertArgs<ExtArgs>>): Prisma__empClient<$Result.GetResult<Prisma.$empPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Emps.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {empCountArgs} args - Arguments to filter Emps to count.
     * @example
     * // Count the number of Emps
     * const count = await prisma.emp.count({
     *   where: {
     *     // ... the filter for the Emps we want to count
     *   }
     * })
    **/
    count<T extends empCountArgs>(
      args?: Subset<T, empCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], EmpCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Emp.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmpAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends EmpAggregateArgs>(args: Subset<T, EmpAggregateArgs>): Prisma.PrismaPromise<GetEmpAggregateType<T>>

    /**
     * Group by Emp.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {empGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends empGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: empGroupByArgs['orderBy'] }
        : { orderBy?: empGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, empGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEmpGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the emp model
   */
  readonly fields: empFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for emp.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__empClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the emp model
   */
  interface empFieldRefs {
    readonly EmpId: FieldRef<"emp", 'Int'>
    readonly EmpNme: FieldRef<"emp", 'String'>
    readonly EmpRaz: FieldRef<"emp", 'String'>
    readonly EmpRdz: FieldRef<"emp", 'String'>
    readonly EmpAtv: FieldRef<"emp", 'String'>
    readonly EmpCnpj: FieldRef<"emp", 'String'>
    readonly Enduf: FieldRef<"emp", 'String'>
    readonly EndCdd: FieldRef<"emp", 'String'>
    readonly EndLtt: FieldRef<"emp", 'String'>
    readonly EndLgt: FieldRef<"emp", 'String'>
    readonly EndCep: FieldRef<"emp", 'String'>
    readonly EndEmp: FieldRef<"emp", 'String'>
    readonly EndCpl: FieldRef<"emp", 'String'>
    readonly EmpLgo: FieldRef<"emp", 'String'>
    readonly EmpUrl: FieldRef<"emp", 'String'>
    readonly EmlCtt: FieldRef<"emp", 'String'>
    readonly EmlFrm: FieldRef<"emp", 'String'>
    readonly EmlFrmPwd: FieldRef<"emp", 'String'>
    readonly FneCtt: FieldRef<"emp", 'String'>
    readonly FneWha: FieldRef<"emp", 'String'>
    readonly RssIns: FieldRef<"emp", 'String'>
    readonly RssFac: FieldRef<"emp", 'String'>
    readonly RssTwi: FieldRef<"emp", 'String'>
    readonly RssYou: FieldRef<"emp", 'String'>
    readonly TpoPix: FieldRef<"emp", 'String'>
    readonly ChvPix: FieldRef<"emp", 'String'>
    readonly QRPixImg: FieldRef<"emp", 'String'>
    readonly QRPixCpy: FieldRef<"emp", 'String'>
    readonly SttId: FieldRef<"emp", 'Int'>
    readonly UsrIdAlt: FieldRef<"emp", 'Int'>
    readonly DtaAlt: FieldRef<"emp", 'DateTime'>
    readonly MtvDel: FieldRef<"emp", 'String'>
  }
    

  // Custom InputTypes
  /**
   * emp findUnique
   */
  export type empFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp
     */
    select?: empSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp
     */
    omit?: empOmit<ExtArgs> | null
    /**
     * Filter, which emp to fetch.
     */
    where: empWhereUniqueInput
  }

  /**
   * emp findUniqueOrThrow
   */
  export type empFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp
     */
    select?: empSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp
     */
    omit?: empOmit<ExtArgs> | null
    /**
     * Filter, which emp to fetch.
     */
    where: empWhereUniqueInput
  }

  /**
   * emp findFirst
   */
  export type empFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp
     */
    select?: empSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp
     */
    omit?: empOmit<ExtArgs> | null
    /**
     * Filter, which emp to fetch.
     */
    where?: empWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of emps to fetch.
     */
    orderBy?: empOrderByWithRelationInput | empOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for emps.
     */
    cursor?: empWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` emps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` emps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of emps.
     */
    distinct?: EmpScalarFieldEnum | EmpScalarFieldEnum[]
  }

  /**
   * emp findFirstOrThrow
   */
  export type empFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp
     */
    select?: empSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp
     */
    omit?: empOmit<ExtArgs> | null
    /**
     * Filter, which emp to fetch.
     */
    where?: empWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of emps to fetch.
     */
    orderBy?: empOrderByWithRelationInput | empOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for emps.
     */
    cursor?: empWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` emps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` emps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of emps.
     */
    distinct?: EmpScalarFieldEnum | EmpScalarFieldEnum[]
  }

  /**
   * emp findMany
   */
  export type empFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp
     */
    select?: empSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp
     */
    omit?: empOmit<ExtArgs> | null
    /**
     * Filter, which emps to fetch.
     */
    where?: empWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of emps to fetch.
     */
    orderBy?: empOrderByWithRelationInput | empOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing emps.
     */
    cursor?: empWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` emps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` emps.
     */
    skip?: number
    distinct?: EmpScalarFieldEnum | EmpScalarFieldEnum[]
  }

  /**
   * emp create
   */
  export type empCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp
     */
    select?: empSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp
     */
    omit?: empOmit<ExtArgs> | null
    /**
     * The data needed to create a emp.
     */
    data: XOR<empCreateInput, empUncheckedCreateInput>
  }

  /**
   * emp createMany
   */
  export type empCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many emps.
     */
    data: empCreateManyInput | empCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * emp update
   */
  export type empUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp
     */
    select?: empSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp
     */
    omit?: empOmit<ExtArgs> | null
    /**
     * The data needed to update a emp.
     */
    data: XOR<empUpdateInput, empUncheckedUpdateInput>
    /**
     * Choose, which emp to update.
     */
    where: empWhereUniqueInput
  }

  /**
   * emp updateMany
   */
  export type empUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update emps.
     */
    data: XOR<empUpdateManyMutationInput, empUncheckedUpdateManyInput>
    /**
     * Filter which emps to update
     */
    where?: empWhereInput
    /**
     * Limit how many emps to update.
     */
    limit?: number
  }

  /**
   * emp upsert
   */
  export type empUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp
     */
    select?: empSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp
     */
    omit?: empOmit<ExtArgs> | null
    /**
     * The filter to search for the emp to update in case it exists.
     */
    where: empWhereUniqueInput
    /**
     * In case the emp found by the `where` argument doesn't exist, create a new emp with this data.
     */
    create: XOR<empCreateInput, empUncheckedCreateInput>
    /**
     * In case the emp was found with the provided `where` argument, update it with this data.
     */
    update: XOR<empUpdateInput, empUncheckedUpdateInput>
  }

  /**
   * emp delete
   */
  export type empDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp
     */
    select?: empSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp
     */
    omit?: empOmit<ExtArgs> | null
    /**
     * Filter which emp to delete.
     */
    where: empWhereUniqueInput
  }

  /**
   * emp deleteMany
   */
  export type empDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which emps to delete
     */
    where?: empWhereInput
    /**
     * Limit how many emps to delete.
     */
    limit?: number
  }

  /**
   * emp without action
   */
  export type empDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp
     */
    select?: empSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp
     */
    omit?: empOmit<ExtArgs> | null
  }


  /**
   * Model emp_und
   */

  export type AggregateEmp_und = {
    _count: Emp_undCountAggregateOutputType | null
    _avg: Emp_undAvgAggregateOutputType | null
    _sum: Emp_undSumAggregateOutputType | null
    _min: Emp_undMinAggregateOutputType | null
    _max: Emp_undMaxAggregateOutputType | null
  }

  export type Emp_undAvgAggregateOutputType = {
    EmpId: number | null
    UndId: number | null
    PstRcg: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type Emp_undSumAggregateOutputType = {
    EmpId: number | null
    UndId: number | null
    PstRcg: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type Emp_undMinAggregateOutputType = {
    EmpId: number | null
    UndId: number | null
    UndNme: string | null
    UndRdz: string | null
    UndReg: string | null
    GpsLtd: string | null
    GpsLgt: string | null
    PstRcg: number | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type Emp_undMaxAggregateOutputType = {
    EmpId: number | null
    UndId: number | null
    UndNme: string | null
    UndRdz: string | null
    UndReg: string | null
    GpsLtd: string | null
    GpsLgt: string | null
    PstRcg: number | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type Emp_undCountAggregateOutputType = {
    EmpId: number
    UndId: number
    UndNme: number
    UndRdz: number
    UndReg: number
    GpsLtd: number
    GpsLgt: number
    PstRcg: number
    SttId: number
    UsrIdAlt: number
    DtaAlt: number
    MtvDel: number
    _all: number
  }


  export type Emp_undAvgAggregateInputType = {
    EmpId?: true
    UndId?: true
    PstRcg?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type Emp_undSumAggregateInputType = {
    EmpId?: true
    UndId?: true
    PstRcg?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type Emp_undMinAggregateInputType = {
    EmpId?: true
    UndId?: true
    UndNme?: true
    UndRdz?: true
    UndReg?: true
    GpsLtd?: true
    GpsLgt?: true
    PstRcg?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type Emp_undMaxAggregateInputType = {
    EmpId?: true
    UndId?: true
    UndNme?: true
    UndRdz?: true
    UndReg?: true
    GpsLtd?: true
    GpsLgt?: true
    PstRcg?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type Emp_undCountAggregateInputType = {
    EmpId?: true
    UndId?: true
    UndNme?: true
    UndRdz?: true
    UndReg?: true
    GpsLtd?: true
    GpsLgt?: true
    PstRcg?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
    _all?: true
  }

  export type Emp_undAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which emp_und to aggregate.
     */
    where?: emp_undWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of emp_unds to fetch.
     */
    orderBy?: emp_undOrderByWithRelationInput | emp_undOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: emp_undWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` emp_unds from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` emp_unds.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned emp_unds
    **/
    _count?: true | Emp_undCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Emp_undAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Emp_undSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Emp_undMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Emp_undMaxAggregateInputType
  }

  export type GetEmp_undAggregateType<T extends Emp_undAggregateArgs> = {
        [P in keyof T & keyof AggregateEmp_und]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEmp_und[P]>
      : GetScalarType<T[P], AggregateEmp_und[P]>
  }




  export type emp_undGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: emp_undWhereInput
    orderBy?: emp_undOrderByWithAggregationInput | emp_undOrderByWithAggregationInput[]
    by: Emp_undScalarFieldEnum[] | Emp_undScalarFieldEnum
    having?: emp_undScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Emp_undCountAggregateInputType | true
    _avg?: Emp_undAvgAggregateInputType
    _sum?: Emp_undSumAggregateInputType
    _min?: Emp_undMinAggregateInputType
    _max?: Emp_undMaxAggregateInputType
  }

  export type Emp_undGroupByOutputType = {
    EmpId: number
    UndId: number
    UndNme: string
    UndRdz: string | null
    UndReg: string | null
    GpsLtd: string | null
    GpsLgt: string | null
    PstRcg: number | null
    SttId: number
    UsrIdAlt: number
    DtaAlt: Date
    MtvDel: string | null
    _count: Emp_undCountAggregateOutputType | null
    _avg: Emp_undAvgAggregateOutputType | null
    _sum: Emp_undSumAggregateOutputType | null
    _min: Emp_undMinAggregateOutputType | null
    _max: Emp_undMaxAggregateOutputType | null
  }

  type GetEmp_undGroupByPayload<T extends emp_undGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Emp_undGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Emp_undGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Emp_undGroupByOutputType[P]>
            : GetScalarType<T[P], Emp_undGroupByOutputType[P]>
        }
      >
    >


  export type emp_undSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    EmpId?: boolean
    UndId?: boolean
    UndNme?: boolean
    UndRdz?: boolean
    UndReg?: boolean
    GpsLtd?: boolean
    GpsLgt?: boolean
    PstRcg?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }, ExtArgs["result"]["emp_und"]>



  export type emp_undSelectScalar = {
    EmpId?: boolean
    UndId?: boolean
    UndNme?: boolean
    UndRdz?: boolean
    UndReg?: boolean
    GpsLtd?: boolean
    GpsLgt?: boolean
    PstRcg?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }

  export type emp_undOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"EmpId" | "UndId" | "UndNme" | "UndRdz" | "UndReg" | "GpsLtd" | "GpsLgt" | "PstRcg" | "SttId" | "UsrIdAlt" | "DtaAlt" | "MtvDel", ExtArgs["result"]["emp_und"]>

  export type $emp_undPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "emp_und"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      EmpId: number
      UndId: number
      UndNme: string
      UndRdz: string | null
      UndReg: string | null
      GpsLtd: string | null
      GpsLgt: string | null
      PstRcg: number | null
      SttId: number
      UsrIdAlt: number
      DtaAlt: Date
      MtvDel: string | null
    }, ExtArgs["result"]["emp_und"]>
    composites: {}
  }

  type emp_undGetPayload<S extends boolean | null | undefined | emp_undDefaultArgs> = $Result.GetResult<Prisma.$emp_undPayload, S>

  type emp_undCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<emp_undFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Emp_undCountAggregateInputType | true
    }

  export interface emp_undDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['emp_und'], meta: { name: 'emp_und' } }
    /**
     * Find zero or one Emp_und that matches the filter.
     * @param {emp_undFindUniqueArgs} args - Arguments to find a Emp_und
     * @example
     * // Get one Emp_und
     * const emp_und = await prisma.emp_und.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends emp_undFindUniqueArgs>(args: SelectSubset<T, emp_undFindUniqueArgs<ExtArgs>>): Prisma__emp_undClient<$Result.GetResult<Prisma.$emp_undPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Emp_und that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {emp_undFindUniqueOrThrowArgs} args - Arguments to find a Emp_und
     * @example
     * // Get one Emp_und
     * const emp_und = await prisma.emp_und.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends emp_undFindUniqueOrThrowArgs>(args: SelectSubset<T, emp_undFindUniqueOrThrowArgs<ExtArgs>>): Prisma__emp_undClient<$Result.GetResult<Prisma.$emp_undPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Emp_und that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {emp_undFindFirstArgs} args - Arguments to find a Emp_und
     * @example
     * // Get one Emp_und
     * const emp_und = await prisma.emp_und.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends emp_undFindFirstArgs>(args?: SelectSubset<T, emp_undFindFirstArgs<ExtArgs>>): Prisma__emp_undClient<$Result.GetResult<Prisma.$emp_undPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Emp_und that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {emp_undFindFirstOrThrowArgs} args - Arguments to find a Emp_und
     * @example
     * // Get one Emp_und
     * const emp_und = await prisma.emp_und.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends emp_undFindFirstOrThrowArgs>(args?: SelectSubset<T, emp_undFindFirstOrThrowArgs<ExtArgs>>): Prisma__emp_undClient<$Result.GetResult<Prisma.$emp_undPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Emp_unds that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {emp_undFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Emp_unds
     * const emp_unds = await prisma.emp_und.findMany()
     * 
     * // Get first 10 Emp_unds
     * const emp_unds = await prisma.emp_und.findMany({ take: 10 })
     * 
     * // Only select the `EmpId`
     * const emp_undWithEmpIdOnly = await prisma.emp_und.findMany({ select: { EmpId: true } })
     * 
     */
    findMany<T extends emp_undFindManyArgs>(args?: SelectSubset<T, emp_undFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$emp_undPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Emp_und.
     * @param {emp_undCreateArgs} args - Arguments to create a Emp_und.
     * @example
     * // Create one Emp_und
     * const Emp_und = await prisma.emp_und.create({
     *   data: {
     *     // ... data to create a Emp_und
     *   }
     * })
     * 
     */
    create<T extends emp_undCreateArgs>(args: SelectSubset<T, emp_undCreateArgs<ExtArgs>>): Prisma__emp_undClient<$Result.GetResult<Prisma.$emp_undPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Emp_unds.
     * @param {emp_undCreateManyArgs} args - Arguments to create many Emp_unds.
     * @example
     * // Create many Emp_unds
     * const emp_und = await prisma.emp_und.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends emp_undCreateManyArgs>(args?: SelectSubset<T, emp_undCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Emp_und.
     * @param {emp_undDeleteArgs} args - Arguments to delete one Emp_und.
     * @example
     * // Delete one Emp_und
     * const Emp_und = await prisma.emp_und.delete({
     *   where: {
     *     // ... filter to delete one Emp_und
     *   }
     * })
     * 
     */
    delete<T extends emp_undDeleteArgs>(args: SelectSubset<T, emp_undDeleteArgs<ExtArgs>>): Prisma__emp_undClient<$Result.GetResult<Prisma.$emp_undPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Emp_und.
     * @param {emp_undUpdateArgs} args - Arguments to update one Emp_und.
     * @example
     * // Update one Emp_und
     * const emp_und = await prisma.emp_und.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends emp_undUpdateArgs>(args: SelectSubset<T, emp_undUpdateArgs<ExtArgs>>): Prisma__emp_undClient<$Result.GetResult<Prisma.$emp_undPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Emp_unds.
     * @param {emp_undDeleteManyArgs} args - Arguments to filter Emp_unds to delete.
     * @example
     * // Delete a few Emp_unds
     * const { count } = await prisma.emp_und.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends emp_undDeleteManyArgs>(args?: SelectSubset<T, emp_undDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Emp_unds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {emp_undUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Emp_unds
     * const emp_und = await prisma.emp_und.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends emp_undUpdateManyArgs>(args: SelectSubset<T, emp_undUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Emp_und.
     * @param {emp_undUpsertArgs} args - Arguments to update or create a Emp_und.
     * @example
     * // Update or create a Emp_und
     * const emp_und = await prisma.emp_und.upsert({
     *   create: {
     *     // ... data to create a Emp_und
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Emp_und we want to update
     *   }
     * })
     */
    upsert<T extends emp_undUpsertArgs>(args: SelectSubset<T, emp_undUpsertArgs<ExtArgs>>): Prisma__emp_undClient<$Result.GetResult<Prisma.$emp_undPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Emp_unds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {emp_undCountArgs} args - Arguments to filter Emp_unds to count.
     * @example
     * // Count the number of Emp_unds
     * const count = await prisma.emp_und.count({
     *   where: {
     *     // ... the filter for the Emp_unds we want to count
     *   }
     * })
    **/
    count<T extends emp_undCountArgs>(
      args?: Subset<T, emp_undCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Emp_undCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Emp_und.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Emp_undAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Emp_undAggregateArgs>(args: Subset<T, Emp_undAggregateArgs>): Prisma.PrismaPromise<GetEmp_undAggregateType<T>>

    /**
     * Group by Emp_und.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {emp_undGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends emp_undGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: emp_undGroupByArgs['orderBy'] }
        : { orderBy?: emp_undGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, emp_undGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEmp_undGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the emp_und model
   */
  readonly fields: emp_undFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for emp_und.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__emp_undClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the emp_und model
   */
  interface emp_undFieldRefs {
    readonly EmpId: FieldRef<"emp_und", 'Int'>
    readonly UndId: FieldRef<"emp_und", 'Int'>
    readonly UndNme: FieldRef<"emp_und", 'String'>
    readonly UndRdz: FieldRef<"emp_und", 'String'>
    readonly UndReg: FieldRef<"emp_und", 'String'>
    readonly GpsLtd: FieldRef<"emp_und", 'String'>
    readonly GpsLgt: FieldRef<"emp_und", 'String'>
    readonly PstRcg: FieldRef<"emp_und", 'Int'>
    readonly SttId: FieldRef<"emp_und", 'Int'>
    readonly UsrIdAlt: FieldRef<"emp_und", 'Int'>
    readonly DtaAlt: FieldRef<"emp_und", 'DateTime'>
    readonly MtvDel: FieldRef<"emp_und", 'String'>
  }
    

  // Custom InputTypes
  /**
   * emp_und findUnique
   */
  export type emp_undFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp_und
     */
    select?: emp_undSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp_und
     */
    omit?: emp_undOmit<ExtArgs> | null
    /**
     * Filter, which emp_und to fetch.
     */
    where: emp_undWhereUniqueInput
  }

  /**
   * emp_und findUniqueOrThrow
   */
  export type emp_undFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp_und
     */
    select?: emp_undSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp_und
     */
    omit?: emp_undOmit<ExtArgs> | null
    /**
     * Filter, which emp_und to fetch.
     */
    where: emp_undWhereUniqueInput
  }

  /**
   * emp_und findFirst
   */
  export type emp_undFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp_und
     */
    select?: emp_undSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp_und
     */
    omit?: emp_undOmit<ExtArgs> | null
    /**
     * Filter, which emp_und to fetch.
     */
    where?: emp_undWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of emp_unds to fetch.
     */
    orderBy?: emp_undOrderByWithRelationInput | emp_undOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for emp_unds.
     */
    cursor?: emp_undWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` emp_unds from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` emp_unds.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of emp_unds.
     */
    distinct?: Emp_undScalarFieldEnum | Emp_undScalarFieldEnum[]
  }

  /**
   * emp_und findFirstOrThrow
   */
  export type emp_undFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp_und
     */
    select?: emp_undSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp_und
     */
    omit?: emp_undOmit<ExtArgs> | null
    /**
     * Filter, which emp_und to fetch.
     */
    where?: emp_undWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of emp_unds to fetch.
     */
    orderBy?: emp_undOrderByWithRelationInput | emp_undOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for emp_unds.
     */
    cursor?: emp_undWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` emp_unds from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` emp_unds.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of emp_unds.
     */
    distinct?: Emp_undScalarFieldEnum | Emp_undScalarFieldEnum[]
  }

  /**
   * emp_und findMany
   */
  export type emp_undFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp_und
     */
    select?: emp_undSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp_und
     */
    omit?: emp_undOmit<ExtArgs> | null
    /**
     * Filter, which emp_unds to fetch.
     */
    where?: emp_undWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of emp_unds to fetch.
     */
    orderBy?: emp_undOrderByWithRelationInput | emp_undOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing emp_unds.
     */
    cursor?: emp_undWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` emp_unds from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` emp_unds.
     */
    skip?: number
    distinct?: Emp_undScalarFieldEnum | Emp_undScalarFieldEnum[]
  }

  /**
   * emp_und create
   */
  export type emp_undCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp_und
     */
    select?: emp_undSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp_und
     */
    omit?: emp_undOmit<ExtArgs> | null
    /**
     * The data needed to create a emp_und.
     */
    data: XOR<emp_undCreateInput, emp_undUncheckedCreateInput>
  }

  /**
   * emp_und createMany
   */
  export type emp_undCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many emp_unds.
     */
    data: emp_undCreateManyInput | emp_undCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * emp_und update
   */
  export type emp_undUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp_und
     */
    select?: emp_undSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp_und
     */
    omit?: emp_undOmit<ExtArgs> | null
    /**
     * The data needed to update a emp_und.
     */
    data: XOR<emp_undUpdateInput, emp_undUncheckedUpdateInput>
    /**
     * Choose, which emp_und to update.
     */
    where: emp_undWhereUniqueInput
  }

  /**
   * emp_und updateMany
   */
  export type emp_undUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update emp_unds.
     */
    data: XOR<emp_undUpdateManyMutationInput, emp_undUncheckedUpdateManyInput>
    /**
     * Filter which emp_unds to update
     */
    where?: emp_undWhereInput
    /**
     * Limit how many emp_unds to update.
     */
    limit?: number
  }

  /**
   * emp_und upsert
   */
  export type emp_undUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp_und
     */
    select?: emp_undSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp_und
     */
    omit?: emp_undOmit<ExtArgs> | null
    /**
     * The filter to search for the emp_und to update in case it exists.
     */
    where: emp_undWhereUniqueInput
    /**
     * In case the emp_und found by the `where` argument doesn't exist, create a new emp_und with this data.
     */
    create: XOR<emp_undCreateInput, emp_undUncheckedCreateInput>
    /**
     * In case the emp_und was found with the provided `where` argument, update it with this data.
     */
    update: XOR<emp_undUpdateInput, emp_undUncheckedUpdateInput>
  }

  /**
   * emp_und delete
   */
  export type emp_undDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp_und
     */
    select?: emp_undSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp_und
     */
    omit?: emp_undOmit<ExtArgs> | null
    /**
     * Filter which emp_und to delete.
     */
    where: emp_undWhereUniqueInput
  }

  /**
   * emp_und deleteMany
   */
  export type emp_undDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which emp_unds to delete
     */
    where?: emp_undWhereInput
    /**
     * Limit how many emp_unds to delete.
     */
    limit?: number
  }

  /**
   * emp_und without action
   */
  export type emp_undDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the emp_und
     */
    select?: emp_undSelect<ExtArgs> | null
    /**
     * Omit specific fields from the emp_und
     */
    omit?: emp_undOmit<ExtArgs> | null
  }


  /**
   * Model eqp_fbr
   */

  export type AggregateEqp_fbr = {
    _count: Eqp_fbrCountAggregateOutputType | null
    _avg: Eqp_fbrAvgAggregateOutputType | null
    _sum: Eqp_fbrSumAggregateOutputType | null
    _min: Eqp_fbrMinAggregateOutputType | null
    _max: Eqp_fbrMaxAggregateOutputType | null
  }

  export type Eqp_fbrAvgAggregateOutputType = {
    EqpFbrId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type Eqp_fbrSumAggregateOutputType = {
    EqpFbrId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type Eqp_fbrMinAggregateOutputType = {
    EqpFbrId: number | null
    EqpFbrNme: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type Eqp_fbrMaxAggregateOutputType = {
    EqpFbrId: number | null
    EqpFbrNme: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type Eqp_fbrCountAggregateOutputType = {
    EqpFbrId: number
    EqpFbrNme: number
    SttId: number
    UsrIdAlt: number
    DtaAlt: number
    MtvDel: number
    _all: number
  }


  export type Eqp_fbrAvgAggregateInputType = {
    EqpFbrId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type Eqp_fbrSumAggregateInputType = {
    EqpFbrId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type Eqp_fbrMinAggregateInputType = {
    EqpFbrId?: true
    EqpFbrNme?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type Eqp_fbrMaxAggregateInputType = {
    EqpFbrId?: true
    EqpFbrNme?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type Eqp_fbrCountAggregateInputType = {
    EqpFbrId?: true
    EqpFbrNme?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
    _all?: true
  }

  export type Eqp_fbrAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which eqp_fbr to aggregate.
     */
    where?: eqp_fbrWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_fbrs to fetch.
     */
    orderBy?: eqp_fbrOrderByWithRelationInput | eqp_fbrOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: eqp_fbrWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_fbrs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_fbrs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned eqp_fbrs
    **/
    _count?: true | Eqp_fbrCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Eqp_fbrAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Eqp_fbrSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Eqp_fbrMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Eqp_fbrMaxAggregateInputType
  }

  export type GetEqp_fbrAggregateType<T extends Eqp_fbrAggregateArgs> = {
        [P in keyof T & keyof AggregateEqp_fbr]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEqp_fbr[P]>
      : GetScalarType<T[P], AggregateEqp_fbr[P]>
  }




  export type eqp_fbrGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: eqp_fbrWhereInput
    orderBy?: eqp_fbrOrderByWithAggregationInput | eqp_fbrOrderByWithAggregationInput[]
    by: Eqp_fbrScalarFieldEnum[] | Eqp_fbrScalarFieldEnum
    having?: eqp_fbrScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Eqp_fbrCountAggregateInputType | true
    _avg?: Eqp_fbrAvgAggregateInputType
    _sum?: Eqp_fbrSumAggregateInputType
    _min?: Eqp_fbrMinAggregateInputType
    _max?: Eqp_fbrMaxAggregateInputType
  }

  export type Eqp_fbrGroupByOutputType = {
    EqpFbrId: number
    EqpFbrNme: string
    SttId: number
    UsrIdAlt: number
    DtaAlt: Date
    MtvDel: string | null
    _count: Eqp_fbrCountAggregateOutputType | null
    _avg: Eqp_fbrAvgAggregateOutputType | null
    _sum: Eqp_fbrSumAggregateOutputType | null
    _min: Eqp_fbrMinAggregateOutputType | null
    _max: Eqp_fbrMaxAggregateOutputType | null
  }

  type GetEqp_fbrGroupByPayload<T extends eqp_fbrGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Eqp_fbrGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Eqp_fbrGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Eqp_fbrGroupByOutputType[P]>
            : GetScalarType<T[P], Eqp_fbrGroupByOutputType[P]>
        }
      >
    >


  export type eqp_fbrSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    EqpFbrId?: boolean
    EqpFbrNme?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }, ExtArgs["result"]["eqp_fbr"]>



  export type eqp_fbrSelectScalar = {
    EqpFbrId?: boolean
    EqpFbrNme?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }

  export type eqp_fbrOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"EqpFbrId" | "EqpFbrNme" | "SttId" | "UsrIdAlt" | "DtaAlt" | "MtvDel", ExtArgs["result"]["eqp_fbr"]>

  export type $eqp_fbrPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "eqp_fbr"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      EqpFbrId: number
      EqpFbrNme: string
      SttId: number
      UsrIdAlt: number
      DtaAlt: Date
      MtvDel: string | null
    }, ExtArgs["result"]["eqp_fbr"]>
    composites: {}
  }

  type eqp_fbrGetPayload<S extends boolean | null | undefined | eqp_fbrDefaultArgs> = $Result.GetResult<Prisma.$eqp_fbrPayload, S>

  type eqp_fbrCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<eqp_fbrFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Eqp_fbrCountAggregateInputType | true
    }

  export interface eqp_fbrDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['eqp_fbr'], meta: { name: 'eqp_fbr' } }
    /**
     * Find zero or one Eqp_fbr that matches the filter.
     * @param {eqp_fbrFindUniqueArgs} args - Arguments to find a Eqp_fbr
     * @example
     * // Get one Eqp_fbr
     * const eqp_fbr = await prisma.eqp_fbr.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends eqp_fbrFindUniqueArgs>(args: SelectSubset<T, eqp_fbrFindUniqueArgs<ExtArgs>>): Prisma__eqp_fbrClient<$Result.GetResult<Prisma.$eqp_fbrPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Eqp_fbr that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {eqp_fbrFindUniqueOrThrowArgs} args - Arguments to find a Eqp_fbr
     * @example
     * // Get one Eqp_fbr
     * const eqp_fbr = await prisma.eqp_fbr.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends eqp_fbrFindUniqueOrThrowArgs>(args: SelectSubset<T, eqp_fbrFindUniqueOrThrowArgs<ExtArgs>>): Prisma__eqp_fbrClient<$Result.GetResult<Prisma.$eqp_fbrPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Eqp_fbr that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_fbrFindFirstArgs} args - Arguments to find a Eqp_fbr
     * @example
     * // Get one Eqp_fbr
     * const eqp_fbr = await prisma.eqp_fbr.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends eqp_fbrFindFirstArgs>(args?: SelectSubset<T, eqp_fbrFindFirstArgs<ExtArgs>>): Prisma__eqp_fbrClient<$Result.GetResult<Prisma.$eqp_fbrPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Eqp_fbr that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_fbrFindFirstOrThrowArgs} args - Arguments to find a Eqp_fbr
     * @example
     * // Get one Eqp_fbr
     * const eqp_fbr = await prisma.eqp_fbr.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends eqp_fbrFindFirstOrThrowArgs>(args?: SelectSubset<T, eqp_fbrFindFirstOrThrowArgs<ExtArgs>>): Prisma__eqp_fbrClient<$Result.GetResult<Prisma.$eqp_fbrPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Eqp_fbrs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_fbrFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Eqp_fbrs
     * const eqp_fbrs = await prisma.eqp_fbr.findMany()
     * 
     * // Get first 10 Eqp_fbrs
     * const eqp_fbrs = await prisma.eqp_fbr.findMany({ take: 10 })
     * 
     * // Only select the `EqpFbrId`
     * const eqp_fbrWithEqpFbrIdOnly = await prisma.eqp_fbr.findMany({ select: { EqpFbrId: true } })
     * 
     */
    findMany<T extends eqp_fbrFindManyArgs>(args?: SelectSubset<T, eqp_fbrFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$eqp_fbrPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Eqp_fbr.
     * @param {eqp_fbrCreateArgs} args - Arguments to create a Eqp_fbr.
     * @example
     * // Create one Eqp_fbr
     * const Eqp_fbr = await prisma.eqp_fbr.create({
     *   data: {
     *     // ... data to create a Eqp_fbr
     *   }
     * })
     * 
     */
    create<T extends eqp_fbrCreateArgs>(args: SelectSubset<T, eqp_fbrCreateArgs<ExtArgs>>): Prisma__eqp_fbrClient<$Result.GetResult<Prisma.$eqp_fbrPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Eqp_fbrs.
     * @param {eqp_fbrCreateManyArgs} args - Arguments to create many Eqp_fbrs.
     * @example
     * // Create many Eqp_fbrs
     * const eqp_fbr = await prisma.eqp_fbr.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends eqp_fbrCreateManyArgs>(args?: SelectSubset<T, eqp_fbrCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Eqp_fbr.
     * @param {eqp_fbrDeleteArgs} args - Arguments to delete one Eqp_fbr.
     * @example
     * // Delete one Eqp_fbr
     * const Eqp_fbr = await prisma.eqp_fbr.delete({
     *   where: {
     *     // ... filter to delete one Eqp_fbr
     *   }
     * })
     * 
     */
    delete<T extends eqp_fbrDeleteArgs>(args: SelectSubset<T, eqp_fbrDeleteArgs<ExtArgs>>): Prisma__eqp_fbrClient<$Result.GetResult<Prisma.$eqp_fbrPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Eqp_fbr.
     * @param {eqp_fbrUpdateArgs} args - Arguments to update one Eqp_fbr.
     * @example
     * // Update one Eqp_fbr
     * const eqp_fbr = await prisma.eqp_fbr.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends eqp_fbrUpdateArgs>(args: SelectSubset<T, eqp_fbrUpdateArgs<ExtArgs>>): Prisma__eqp_fbrClient<$Result.GetResult<Prisma.$eqp_fbrPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Eqp_fbrs.
     * @param {eqp_fbrDeleteManyArgs} args - Arguments to filter Eqp_fbrs to delete.
     * @example
     * // Delete a few Eqp_fbrs
     * const { count } = await prisma.eqp_fbr.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends eqp_fbrDeleteManyArgs>(args?: SelectSubset<T, eqp_fbrDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Eqp_fbrs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_fbrUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Eqp_fbrs
     * const eqp_fbr = await prisma.eqp_fbr.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends eqp_fbrUpdateManyArgs>(args: SelectSubset<T, eqp_fbrUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Eqp_fbr.
     * @param {eqp_fbrUpsertArgs} args - Arguments to update or create a Eqp_fbr.
     * @example
     * // Update or create a Eqp_fbr
     * const eqp_fbr = await prisma.eqp_fbr.upsert({
     *   create: {
     *     // ... data to create a Eqp_fbr
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Eqp_fbr we want to update
     *   }
     * })
     */
    upsert<T extends eqp_fbrUpsertArgs>(args: SelectSubset<T, eqp_fbrUpsertArgs<ExtArgs>>): Prisma__eqp_fbrClient<$Result.GetResult<Prisma.$eqp_fbrPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Eqp_fbrs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_fbrCountArgs} args - Arguments to filter Eqp_fbrs to count.
     * @example
     * // Count the number of Eqp_fbrs
     * const count = await prisma.eqp_fbr.count({
     *   where: {
     *     // ... the filter for the Eqp_fbrs we want to count
     *   }
     * })
    **/
    count<T extends eqp_fbrCountArgs>(
      args?: Subset<T, eqp_fbrCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Eqp_fbrCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Eqp_fbr.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Eqp_fbrAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Eqp_fbrAggregateArgs>(args: Subset<T, Eqp_fbrAggregateArgs>): Prisma.PrismaPromise<GetEqp_fbrAggregateType<T>>

    /**
     * Group by Eqp_fbr.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_fbrGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends eqp_fbrGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: eqp_fbrGroupByArgs['orderBy'] }
        : { orderBy?: eqp_fbrGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, eqp_fbrGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEqp_fbrGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the eqp_fbr model
   */
  readonly fields: eqp_fbrFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for eqp_fbr.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__eqp_fbrClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the eqp_fbr model
   */
  interface eqp_fbrFieldRefs {
    readonly EqpFbrId: FieldRef<"eqp_fbr", 'Int'>
    readonly EqpFbrNme: FieldRef<"eqp_fbr", 'String'>
    readonly SttId: FieldRef<"eqp_fbr", 'Int'>
    readonly UsrIdAlt: FieldRef<"eqp_fbr", 'Int'>
    readonly DtaAlt: FieldRef<"eqp_fbr", 'DateTime'>
    readonly MtvDel: FieldRef<"eqp_fbr", 'String'>
  }
    

  // Custom InputTypes
  /**
   * eqp_fbr findUnique
   */
  export type eqp_fbrFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_fbr
     */
    select?: eqp_fbrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_fbr
     */
    omit?: eqp_fbrOmit<ExtArgs> | null
    /**
     * Filter, which eqp_fbr to fetch.
     */
    where: eqp_fbrWhereUniqueInput
  }

  /**
   * eqp_fbr findUniqueOrThrow
   */
  export type eqp_fbrFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_fbr
     */
    select?: eqp_fbrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_fbr
     */
    omit?: eqp_fbrOmit<ExtArgs> | null
    /**
     * Filter, which eqp_fbr to fetch.
     */
    where: eqp_fbrWhereUniqueInput
  }

  /**
   * eqp_fbr findFirst
   */
  export type eqp_fbrFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_fbr
     */
    select?: eqp_fbrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_fbr
     */
    omit?: eqp_fbrOmit<ExtArgs> | null
    /**
     * Filter, which eqp_fbr to fetch.
     */
    where?: eqp_fbrWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_fbrs to fetch.
     */
    orderBy?: eqp_fbrOrderByWithRelationInput | eqp_fbrOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for eqp_fbrs.
     */
    cursor?: eqp_fbrWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_fbrs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_fbrs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of eqp_fbrs.
     */
    distinct?: Eqp_fbrScalarFieldEnum | Eqp_fbrScalarFieldEnum[]
  }

  /**
   * eqp_fbr findFirstOrThrow
   */
  export type eqp_fbrFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_fbr
     */
    select?: eqp_fbrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_fbr
     */
    omit?: eqp_fbrOmit<ExtArgs> | null
    /**
     * Filter, which eqp_fbr to fetch.
     */
    where?: eqp_fbrWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_fbrs to fetch.
     */
    orderBy?: eqp_fbrOrderByWithRelationInput | eqp_fbrOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for eqp_fbrs.
     */
    cursor?: eqp_fbrWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_fbrs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_fbrs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of eqp_fbrs.
     */
    distinct?: Eqp_fbrScalarFieldEnum | Eqp_fbrScalarFieldEnum[]
  }

  /**
   * eqp_fbr findMany
   */
  export type eqp_fbrFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_fbr
     */
    select?: eqp_fbrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_fbr
     */
    omit?: eqp_fbrOmit<ExtArgs> | null
    /**
     * Filter, which eqp_fbrs to fetch.
     */
    where?: eqp_fbrWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_fbrs to fetch.
     */
    orderBy?: eqp_fbrOrderByWithRelationInput | eqp_fbrOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing eqp_fbrs.
     */
    cursor?: eqp_fbrWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_fbrs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_fbrs.
     */
    skip?: number
    distinct?: Eqp_fbrScalarFieldEnum | Eqp_fbrScalarFieldEnum[]
  }

  /**
   * eqp_fbr create
   */
  export type eqp_fbrCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_fbr
     */
    select?: eqp_fbrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_fbr
     */
    omit?: eqp_fbrOmit<ExtArgs> | null
    /**
     * The data needed to create a eqp_fbr.
     */
    data: XOR<eqp_fbrCreateInput, eqp_fbrUncheckedCreateInput>
  }

  /**
   * eqp_fbr createMany
   */
  export type eqp_fbrCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many eqp_fbrs.
     */
    data: eqp_fbrCreateManyInput | eqp_fbrCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * eqp_fbr update
   */
  export type eqp_fbrUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_fbr
     */
    select?: eqp_fbrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_fbr
     */
    omit?: eqp_fbrOmit<ExtArgs> | null
    /**
     * The data needed to update a eqp_fbr.
     */
    data: XOR<eqp_fbrUpdateInput, eqp_fbrUncheckedUpdateInput>
    /**
     * Choose, which eqp_fbr to update.
     */
    where: eqp_fbrWhereUniqueInput
  }

  /**
   * eqp_fbr updateMany
   */
  export type eqp_fbrUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update eqp_fbrs.
     */
    data: XOR<eqp_fbrUpdateManyMutationInput, eqp_fbrUncheckedUpdateManyInput>
    /**
     * Filter which eqp_fbrs to update
     */
    where?: eqp_fbrWhereInput
    /**
     * Limit how many eqp_fbrs to update.
     */
    limit?: number
  }

  /**
   * eqp_fbr upsert
   */
  export type eqp_fbrUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_fbr
     */
    select?: eqp_fbrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_fbr
     */
    omit?: eqp_fbrOmit<ExtArgs> | null
    /**
     * The filter to search for the eqp_fbr to update in case it exists.
     */
    where: eqp_fbrWhereUniqueInput
    /**
     * In case the eqp_fbr found by the `where` argument doesn't exist, create a new eqp_fbr with this data.
     */
    create: XOR<eqp_fbrCreateInput, eqp_fbrUncheckedCreateInput>
    /**
     * In case the eqp_fbr was found with the provided `where` argument, update it with this data.
     */
    update: XOR<eqp_fbrUpdateInput, eqp_fbrUncheckedUpdateInput>
  }

  /**
   * eqp_fbr delete
   */
  export type eqp_fbrDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_fbr
     */
    select?: eqp_fbrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_fbr
     */
    omit?: eqp_fbrOmit<ExtArgs> | null
    /**
     * Filter which eqp_fbr to delete.
     */
    where: eqp_fbrWhereUniqueInput
  }

  /**
   * eqp_fbr deleteMany
   */
  export type eqp_fbrDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which eqp_fbrs to delete
     */
    where?: eqp_fbrWhereInput
    /**
     * Limit how many eqp_fbrs to delete.
     */
    limit?: number
  }

  /**
   * eqp_fbr without action
   */
  export type eqp_fbrDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_fbr
     */
    select?: eqp_fbrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_fbr
     */
    omit?: eqp_fbrOmit<ExtArgs> | null
  }


  /**
   * Model eqp_itm
   */

  export type AggregateEqp_itm = {
    _count: Eqp_itmCountAggregateOutputType | null
    _avg: Eqp_itmAvgAggregateOutputType | null
    _sum: Eqp_itmSumAggregateOutputType | null
    _min: Eqp_itmMinAggregateOutputType | null
    _max: Eqp_itmMaxAggregateOutputType | null
  }

  export type Eqp_itmAvgAggregateOutputType = {
    FrnId: number | null
    EqpTpoId: number | null
    EqpFbrId: number | null
    EqpMdlId: number | null
    EqpItmId: number | null
    CbtId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type Eqp_itmSumAggregateOutputType = {
    FrnId: number | null
    EqpTpoId: number | null
    EqpFbrId: number | null
    EqpMdlId: number | null
    EqpItmId: number | null
    CbtId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type Eqp_itmMinAggregateOutputType = {
    FrnId: number | null
    EqpTpoId: number | null
    EqpFbrId: number | null
    EqpMdlId: number | null
    EqpItmId: number | null
    EqpItmCdg: string | null
    EqpItmPlc: string | null
    EqpItmAnoMdl: string | null
    CbtId: number | null
    EqpItmTmh: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type Eqp_itmMaxAggregateOutputType = {
    FrnId: number | null
    EqpTpoId: number | null
    EqpFbrId: number | null
    EqpMdlId: number | null
    EqpItmId: number | null
    EqpItmCdg: string | null
    EqpItmPlc: string | null
    EqpItmAnoMdl: string | null
    CbtId: number | null
    EqpItmTmh: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type Eqp_itmCountAggregateOutputType = {
    FrnId: number
    EqpTpoId: number
    EqpFbrId: number
    EqpMdlId: number
    EqpItmId: number
    EqpItmCdg: number
    EqpItmPlc: number
    EqpItmAnoMdl: number
    CbtId: number
    EqpItmTmh: number
    SttId: number
    UsrIdAlt: number
    DtaAlt: number
    MtvDel: number
    _all: number
  }


  export type Eqp_itmAvgAggregateInputType = {
    FrnId?: true
    EqpTpoId?: true
    EqpFbrId?: true
    EqpMdlId?: true
    EqpItmId?: true
    CbtId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type Eqp_itmSumAggregateInputType = {
    FrnId?: true
    EqpTpoId?: true
    EqpFbrId?: true
    EqpMdlId?: true
    EqpItmId?: true
    CbtId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type Eqp_itmMinAggregateInputType = {
    FrnId?: true
    EqpTpoId?: true
    EqpFbrId?: true
    EqpMdlId?: true
    EqpItmId?: true
    EqpItmCdg?: true
    EqpItmPlc?: true
    EqpItmAnoMdl?: true
    CbtId?: true
    EqpItmTmh?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type Eqp_itmMaxAggregateInputType = {
    FrnId?: true
    EqpTpoId?: true
    EqpFbrId?: true
    EqpMdlId?: true
    EqpItmId?: true
    EqpItmCdg?: true
    EqpItmPlc?: true
    EqpItmAnoMdl?: true
    CbtId?: true
    EqpItmTmh?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type Eqp_itmCountAggregateInputType = {
    FrnId?: true
    EqpTpoId?: true
    EqpFbrId?: true
    EqpMdlId?: true
    EqpItmId?: true
    EqpItmCdg?: true
    EqpItmPlc?: true
    EqpItmAnoMdl?: true
    CbtId?: true
    EqpItmTmh?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
    _all?: true
  }

  export type Eqp_itmAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which eqp_itm to aggregate.
     */
    where?: eqp_itmWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_itms to fetch.
     */
    orderBy?: eqp_itmOrderByWithRelationInput | eqp_itmOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: eqp_itmWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_itms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_itms.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned eqp_itms
    **/
    _count?: true | Eqp_itmCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Eqp_itmAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Eqp_itmSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Eqp_itmMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Eqp_itmMaxAggregateInputType
  }

  export type GetEqp_itmAggregateType<T extends Eqp_itmAggregateArgs> = {
        [P in keyof T & keyof AggregateEqp_itm]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEqp_itm[P]>
      : GetScalarType<T[P], AggregateEqp_itm[P]>
  }




  export type eqp_itmGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: eqp_itmWhereInput
    orderBy?: eqp_itmOrderByWithAggregationInput | eqp_itmOrderByWithAggregationInput[]
    by: Eqp_itmScalarFieldEnum[] | Eqp_itmScalarFieldEnum
    having?: eqp_itmScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Eqp_itmCountAggregateInputType | true
    _avg?: Eqp_itmAvgAggregateInputType
    _sum?: Eqp_itmSumAggregateInputType
    _min?: Eqp_itmMinAggregateInputType
    _max?: Eqp_itmMaxAggregateInputType
  }

  export type Eqp_itmGroupByOutputType = {
    FrnId: number
    EqpTpoId: number
    EqpFbrId: number
    EqpMdlId: number
    EqpItmId: number
    EqpItmCdg: string
    EqpItmPlc: string | null
    EqpItmAnoMdl: string | null
    CbtId: number
    EqpItmTmh: string
    SttId: number
    UsrIdAlt: number
    DtaAlt: Date
    MtvDel: string | null
    _count: Eqp_itmCountAggregateOutputType | null
    _avg: Eqp_itmAvgAggregateOutputType | null
    _sum: Eqp_itmSumAggregateOutputType | null
    _min: Eqp_itmMinAggregateOutputType | null
    _max: Eqp_itmMaxAggregateOutputType | null
  }

  type GetEqp_itmGroupByPayload<T extends eqp_itmGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Eqp_itmGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Eqp_itmGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Eqp_itmGroupByOutputType[P]>
            : GetScalarType<T[P], Eqp_itmGroupByOutputType[P]>
        }
      >
    >


  export type eqp_itmSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    FrnId?: boolean
    EqpTpoId?: boolean
    EqpFbrId?: boolean
    EqpMdlId?: boolean
    EqpItmId?: boolean
    EqpItmCdg?: boolean
    EqpItmPlc?: boolean
    EqpItmAnoMdl?: boolean
    CbtId?: boolean
    EqpItmTmh?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }, ExtArgs["result"]["eqp_itm"]>



  export type eqp_itmSelectScalar = {
    FrnId?: boolean
    EqpTpoId?: boolean
    EqpFbrId?: boolean
    EqpMdlId?: boolean
    EqpItmId?: boolean
    EqpItmCdg?: boolean
    EqpItmPlc?: boolean
    EqpItmAnoMdl?: boolean
    CbtId?: boolean
    EqpItmTmh?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }

  export type eqp_itmOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"FrnId" | "EqpTpoId" | "EqpFbrId" | "EqpMdlId" | "EqpItmId" | "EqpItmCdg" | "EqpItmPlc" | "EqpItmAnoMdl" | "CbtId" | "EqpItmTmh" | "SttId" | "UsrIdAlt" | "DtaAlt" | "MtvDel", ExtArgs["result"]["eqp_itm"]>

  export type $eqp_itmPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "eqp_itm"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      FrnId: number
      EqpTpoId: number
      EqpFbrId: number
      EqpMdlId: number
      EqpItmId: number
      EqpItmCdg: string
      EqpItmPlc: string | null
      EqpItmAnoMdl: string | null
      CbtId: number
      EqpItmTmh: string
      SttId: number
      UsrIdAlt: number
      DtaAlt: Date
      MtvDel: string | null
    }, ExtArgs["result"]["eqp_itm"]>
    composites: {}
  }

  type eqp_itmGetPayload<S extends boolean | null | undefined | eqp_itmDefaultArgs> = $Result.GetResult<Prisma.$eqp_itmPayload, S>

  type eqp_itmCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<eqp_itmFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Eqp_itmCountAggregateInputType | true
    }

  export interface eqp_itmDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['eqp_itm'], meta: { name: 'eqp_itm' } }
    /**
     * Find zero or one Eqp_itm that matches the filter.
     * @param {eqp_itmFindUniqueArgs} args - Arguments to find a Eqp_itm
     * @example
     * // Get one Eqp_itm
     * const eqp_itm = await prisma.eqp_itm.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends eqp_itmFindUniqueArgs>(args: SelectSubset<T, eqp_itmFindUniqueArgs<ExtArgs>>): Prisma__eqp_itmClient<$Result.GetResult<Prisma.$eqp_itmPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Eqp_itm that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {eqp_itmFindUniqueOrThrowArgs} args - Arguments to find a Eqp_itm
     * @example
     * // Get one Eqp_itm
     * const eqp_itm = await prisma.eqp_itm.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends eqp_itmFindUniqueOrThrowArgs>(args: SelectSubset<T, eqp_itmFindUniqueOrThrowArgs<ExtArgs>>): Prisma__eqp_itmClient<$Result.GetResult<Prisma.$eqp_itmPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Eqp_itm that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_itmFindFirstArgs} args - Arguments to find a Eqp_itm
     * @example
     * // Get one Eqp_itm
     * const eqp_itm = await prisma.eqp_itm.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends eqp_itmFindFirstArgs>(args?: SelectSubset<T, eqp_itmFindFirstArgs<ExtArgs>>): Prisma__eqp_itmClient<$Result.GetResult<Prisma.$eqp_itmPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Eqp_itm that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_itmFindFirstOrThrowArgs} args - Arguments to find a Eqp_itm
     * @example
     * // Get one Eqp_itm
     * const eqp_itm = await prisma.eqp_itm.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends eqp_itmFindFirstOrThrowArgs>(args?: SelectSubset<T, eqp_itmFindFirstOrThrowArgs<ExtArgs>>): Prisma__eqp_itmClient<$Result.GetResult<Prisma.$eqp_itmPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Eqp_itms that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_itmFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Eqp_itms
     * const eqp_itms = await prisma.eqp_itm.findMany()
     * 
     * // Get first 10 Eqp_itms
     * const eqp_itms = await prisma.eqp_itm.findMany({ take: 10 })
     * 
     * // Only select the `FrnId`
     * const eqp_itmWithFrnIdOnly = await prisma.eqp_itm.findMany({ select: { FrnId: true } })
     * 
     */
    findMany<T extends eqp_itmFindManyArgs>(args?: SelectSubset<T, eqp_itmFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$eqp_itmPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Eqp_itm.
     * @param {eqp_itmCreateArgs} args - Arguments to create a Eqp_itm.
     * @example
     * // Create one Eqp_itm
     * const Eqp_itm = await prisma.eqp_itm.create({
     *   data: {
     *     // ... data to create a Eqp_itm
     *   }
     * })
     * 
     */
    create<T extends eqp_itmCreateArgs>(args: SelectSubset<T, eqp_itmCreateArgs<ExtArgs>>): Prisma__eqp_itmClient<$Result.GetResult<Prisma.$eqp_itmPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Eqp_itms.
     * @param {eqp_itmCreateManyArgs} args - Arguments to create many Eqp_itms.
     * @example
     * // Create many Eqp_itms
     * const eqp_itm = await prisma.eqp_itm.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends eqp_itmCreateManyArgs>(args?: SelectSubset<T, eqp_itmCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Eqp_itm.
     * @param {eqp_itmDeleteArgs} args - Arguments to delete one Eqp_itm.
     * @example
     * // Delete one Eqp_itm
     * const Eqp_itm = await prisma.eqp_itm.delete({
     *   where: {
     *     // ... filter to delete one Eqp_itm
     *   }
     * })
     * 
     */
    delete<T extends eqp_itmDeleteArgs>(args: SelectSubset<T, eqp_itmDeleteArgs<ExtArgs>>): Prisma__eqp_itmClient<$Result.GetResult<Prisma.$eqp_itmPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Eqp_itm.
     * @param {eqp_itmUpdateArgs} args - Arguments to update one Eqp_itm.
     * @example
     * // Update one Eqp_itm
     * const eqp_itm = await prisma.eqp_itm.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends eqp_itmUpdateArgs>(args: SelectSubset<T, eqp_itmUpdateArgs<ExtArgs>>): Prisma__eqp_itmClient<$Result.GetResult<Prisma.$eqp_itmPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Eqp_itms.
     * @param {eqp_itmDeleteManyArgs} args - Arguments to filter Eqp_itms to delete.
     * @example
     * // Delete a few Eqp_itms
     * const { count } = await prisma.eqp_itm.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends eqp_itmDeleteManyArgs>(args?: SelectSubset<T, eqp_itmDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Eqp_itms.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_itmUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Eqp_itms
     * const eqp_itm = await prisma.eqp_itm.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends eqp_itmUpdateManyArgs>(args: SelectSubset<T, eqp_itmUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Eqp_itm.
     * @param {eqp_itmUpsertArgs} args - Arguments to update or create a Eqp_itm.
     * @example
     * // Update or create a Eqp_itm
     * const eqp_itm = await prisma.eqp_itm.upsert({
     *   create: {
     *     // ... data to create a Eqp_itm
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Eqp_itm we want to update
     *   }
     * })
     */
    upsert<T extends eqp_itmUpsertArgs>(args: SelectSubset<T, eqp_itmUpsertArgs<ExtArgs>>): Prisma__eqp_itmClient<$Result.GetResult<Prisma.$eqp_itmPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Eqp_itms.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_itmCountArgs} args - Arguments to filter Eqp_itms to count.
     * @example
     * // Count the number of Eqp_itms
     * const count = await prisma.eqp_itm.count({
     *   where: {
     *     // ... the filter for the Eqp_itms we want to count
     *   }
     * })
    **/
    count<T extends eqp_itmCountArgs>(
      args?: Subset<T, eqp_itmCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Eqp_itmCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Eqp_itm.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Eqp_itmAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Eqp_itmAggregateArgs>(args: Subset<T, Eqp_itmAggregateArgs>): Prisma.PrismaPromise<GetEqp_itmAggregateType<T>>

    /**
     * Group by Eqp_itm.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_itmGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends eqp_itmGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: eqp_itmGroupByArgs['orderBy'] }
        : { orderBy?: eqp_itmGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, eqp_itmGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEqp_itmGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the eqp_itm model
   */
  readonly fields: eqp_itmFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for eqp_itm.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__eqp_itmClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the eqp_itm model
   */
  interface eqp_itmFieldRefs {
    readonly FrnId: FieldRef<"eqp_itm", 'Int'>
    readonly EqpTpoId: FieldRef<"eqp_itm", 'Int'>
    readonly EqpFbrId: FieldRef<"eqp_itm", 'Int'>
    readonly EqpMdlId: FieldRef<"eqp_itm", 'Int'>
    readonly EqpItmId: FieldRef<"eqp_itm", 'Int'>
    readonly EqpItmCdg: FieldRef<"eqp_itm", 'String'>
    readonly EqpItmPlc: FieldRef<"eqp_itm", 'String'>
    readonly EqpItmAnoMdl: FieldRef<"eqp_itm", 'String'>
    readonly CbtId: FieldRef<"eqp_itm", 'Int'>
    readonly EqpItmTmh: FieldRef<"eqp_itm", 'String'>
    readonly SttId: FieldRef<"eqp_itm", 'Int'>
    readonly UsrIdAlt: FieldRef<"eqp_itm", 'Int'>
    readonly DtaAlt: FieldRef<"eqp_itm", 'DateTime'>
    readonly MtvDel: FieldRef<"eqp_itm", 'String'>
  }
    

  // Custom InputTypes
  /**
   * eqp_itm findUnique
   */
  export type eqp_itmFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_itm
     */
    select?: eqp_itmSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_itm
     */
    omit?: eqp_itmOmit<ExtArgs> | null
    /**
     * Filter, which eqp_itm to fetch.
     */
    where: eqp_itmWhereUniqueInput
  }

  /**
   * eqp_itm findUniqueOrThrow
   */
  export type eqp_itmFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_itm
     */
    select?: eqp_itmSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_itm
     */
    omit?: eqp_itmOmit<ExtArgs> | null
    /**
     * Filter, which eqp_itm to fetch.
     */
    where: eqp_itmWhereUniqueInput
  }

  /**
   * eqp_itm findFirst
   */
  export type eqp_itmFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_itm
     */
    select?: eqp_itmSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_itm
     */
    omit?: eqp_itmOmit<ExtArgs> | null
    /**
     * Filter, which eqp_itm to fetch.
     */
    where?: eqp_itmWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_itms to fetch.
     */
    orderBy?: eqp_itmOrderByWithRelationInput | eqp_itmOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for eqp_itms.
     */
    cursor?: eqp_itmWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_itms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_itms.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of eqp_itms.
     */
    distinct?: Eqp_itmScalarFieldEnum | Eqp_itmScalarFieldEnum[]
  }

  /**
   * eqp_itm findFirstOrThrow
   */
  export type eqp_itmFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_itm
     */
    select?: eqp_itmSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_itm
     */
    omit?: eqp_itmOmit<ExtArgs> | null
    /**
     * Filter, which eqp_itm to fetch.
     */
    where?: eqp_itmWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_itms to fetch.
     */
    orderBy?: eqp_itmOrderByWithRelationInput | eqp_itmOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for eqp_itms.
     */
    cursor?: eqp_itmWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_itms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_itms.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of eqp_itms.
     */
    distinct?: Eqp_itmScalarFieldEnum | Eqp_itmScalarFieldEnum[]
  }

  /**
   * eqp_itm findMany
   */
  export type eqp_itmFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_itm
     */
    select?: eqp_itmSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_itm
     */
    omit?: eqp_itmOmit<ExtArgs> | null
    /**
     * Filter, which eqp_itms to fetch.
     */
    where?: eqp_itmWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_itms to fetch.
     */
    orderBy?: eqp_itmOrderByWithRelationInput | eqp_itmOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing eqp_itms.
     */
    cursor?: eqp_itmWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_itms from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_itms.
     */
    skip?: number
    distinct?: Eqp_itmScalarFieldEnum | Eqp_itmScalarFieldEnum[]
  }

  /**
   * eqp_itm create
   */
  export type eqp_itmCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_itm
     */
    select?: eqp_itmSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_itm
     */
    omit?: eqp_itmOmit<ExtArgs> | null
    /**
     * The data needed to create a eqp_itm.
     */
    data: XOR<eqp_itmCreateInput, eqp_itmUncheckedCreateInput>
  }

  /**
   * eqp_itm createMany
   */
  export type eqp_itmCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many eqp_itms.
     */
    data: eqp_itmCreateManyInput | eqp_itmCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * eqp_itm update
   */
  export type eqp_itmUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_itm
     */
    select?: eqp_itmSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_itm
     */
    omit?: eqp_itmOmit<ExtArgs> | null
    /**
     * The data needed to update a eqp_itm.
     */
    data: XOR<eqp_itmUpdateInput, eqp_itmUncheckedUpdateInput>
    /**
     * Choose, which eqp_itm to update.
     */
    where: eqp_itmWhereUniqueInput
  }

  /**
   * eqp_itm updateMany
   */
  export type eqp_itmUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update eqp_itms.
     */
    data: XOR<eqp_itmUpdateManyMutationInput, eqp_itmUncheckedUpdateManyInput>
    /**
     * Filter which eqp_itms to update
     */
    where?: eqp_itmWhereInput
    /**
     * Limit how many eqp_itms to update.
     */
    limit?: number
  }

  /**
   * eqp_itm upsert
   */
  export type eqp_itmUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_itm
     */
    select?: eqp_itmSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_itm
     */
    omit?: eqp_itmOmit<ExtArgs> | null
    /**
     * The filter to search for the eqp_itm to update in case it exists.
     */
    where: eqp_itmWhereUniqueInput
    /**
     * In case the eqp_itm found by the `where` argument doesn't exist, create a new eqp_itm with this data.
     */
    create: XOR<eqp_itmCreateInput, eqp_itmUncheckedCreateInput>
    /**
     * In case the eqp_itm was found with the provided `where` argument, update it with this data.
     */
    update: XOR<eqp_itmUpdateInput, eqp_itmUncheckedUpdateInput>
  }

  /**
   * eqp_itm delete
   */
  export type eqp_itmDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_itm
     */
    select?: eqp_itmSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_itm
     */
    omit?: eqp_itmOmit<ExtArgs> | null
    /**
     * Filter which eqp_itm to delete.
     */
    where: eqp_itmWhereUniqueInput
  }

  /**
   * eqp_itm deleteMany
   */
  export type eqp_itmDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which eqp_itms to delete
     */
    where?: eqp_itmWhereInput
    /**
     * Limit how many eqp_itms to delete.
     */
    limit?: number
  }

  /**
   * eqp_itm without action
   */
  export type eqp_itmDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_itm
     */
    select?: eqp_itmSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_itm
     */
    omit?: eqp_itmOmit<ExtArgs> | null
  }


  /**
   * Model eqp_loc
   */

  export type AggregateEqp_loc = {
    _count: Eqp_locCountAggregateOutputType | null
    _avg: Eqp_locAvgAggregateOutputType | null
    _sum: Eqp_locSumAggregateOutputType | null
    _min: Eqp_locMinAggregateOutputType | null
    _max: Eqp_locMaxAggregateOutputType | null
  }

  export type Eqp_locAvgAggregateOutputType = {
    EqpTpoId: number | null
    EqpItmId: number | null
    UndId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type Eqp_locSumAggregateOutputType = {
    EqpTpoId: number | null
    EqpItmId: number | null
    UndId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type Eqp_locMinAggregateOutputType = {
    EqpTpoId: number | null
    EqpItmId: number | null
    UndId: number | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type Eqp_locMaxAggregateOutputType = {
    EqpTpoId: number | null
    EqpItmId: number | null
    UndId: number | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type Eqp_locCountAggregateOutputType = {
    EqpTpoId: number
    EqpItmId: number
    UndId: number
    SttId: number
    UsrIdAlt: number
    DtaAlt: number
    MtvDel: number
    _all: number
  }


  export type Eqp_locAvgAggregateInputType = {
    EqpTpoId?: true
    EqpItmId?: true
    UndId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type Eqp_locSumAggregateInputType = {
    EqpTpoId?: true
    EqpItmId?: true
    UndId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type Eqp_locMinAggregateInputType = {
    EqpTpoId?: true
    EqpItmId?: true
    UndId?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type Eqp_locMaxAggregateInputType = {
    EqpTpoId?: true
    EqpItmId?: true
    UndId?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type Eqp_locCountAggregateInputType = {
    EqpTpoId?: true
    EqpItmId?: true
    UndId?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
    _all?: true
  }

  export type Eqp_locAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which eqp_loc to aggregate.
     */
    where?: eqp_locWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_locs to fetch.
     */
    orderBy?: eqp_locOrderByWithRelationInput | eqp_locOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: eqp_locWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_locs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_locs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned eqp_locs
    **/
    _count?: true | Eqp_locCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Eqp_locAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Eqp_locSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Eqp_locMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Eqp_locMaxAggregateInputType
  }

  export type GetEqp_locAggregateType<T extends Eqp_locAggregateArgs> = {
        [P in keyof T & keyof AggregateEqp_loc]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEqp_loc[P]>
      : GetScalarType<T[P], AggregateEqp_loc[P]>
  }




  export type eqp_locGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: eqp_locWhereInput
    orderBy?: eqp_locOrderByWithAggregationInput | eqp_locOrderByWithAggregationInput[]
    by: Eqp_locScalarFieldEnum[] | Eqp_locScalarFieldEnum
    having?: eqp_locScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Eqp_locCountAggregateInputType | true
    _avg?: Eqp_locAvgAggregateInputType
    _sum?: Eqp_locSumAggregateInputType
    _min?: Eqp_locMinAggregateInputType
    _max?: Eqp_locMaxAggregateInputType
  }

  export type Eqp_locGroupByOutputType = {
    EqpTpoId: number
    EqpItmId: number
    UndId: number
    SttId: number
    UsrIdAlt: number
    DtaAlt: Date
    MtvDel: string | null
    _count: Eqp_locCountAggregateOutputType | null
    _avg: Eqp_locAvgAggregateOutputType | null
    _sum: Eqp_locSumAggregateOutputType | null
    _min: Eqp_locMinAggregateOutputType | null
    _max: Eqp_locMaxAggregateOutputType | null
  }

  type GetEqp_locGroupByPayload<T extends eqp_locGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Eqp_locGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Eqp_locGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Eqp_locGroupByOutputType[P]>
            : GetScalarType<T[P], Eqp_locGroupByOutputType[P]>
        }
      >
    >


  export type eqp_locSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    EqpTpoId?: boolean
    EqpItmId?: boolean
    UndId?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }, ExtArgs["result"]["eqp_loc"]>



  export type eqp_locSelectScalar = {
    EqpTpoId?: boolean
    EqpItmId?: boolean
    UndId?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }

  export type eqp_locOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"EqpTpoId" | "EqpItmId" | "UndId" | "SttId" | "UsrIdAlt" | "DtaAlt" | "MtvDel", ExtArgs["result"]["eqp_loc"]>

  export type $eqp_locPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "eqp_loc"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      EqpTpoId: number
      EqpItmId: number
      UndId: number
      SttId: number
      UsrIdAlt: number
      DtaAlt: Date
      MtvDel: string | null
    }, ExtArgs["result"]["eqp_loc"]>
    composites: {}
  }

  type eqp_locGetPayload<S extends boolean | null | undefined | eqp_locDefaultArgs> = $Result.GetResult<Prisma.$eqp_locPayload, S>

  type eqp_locCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<eqp_locFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Eqp_locCountAggregateInputType | true
    }

  export interface eqp_locDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['eqp_loc'], meta: { name: 'eqp_loc' } }
    /**
     * Find zero or one Eqp_loc that matches the filter.
     * @param {eqp_locFindUniqueArgs} args - Arguments to find a Eqp_loc
     * @example
     * // Get one Eqp_loc
     * const eqp_loc = await prisma.eqp_loc.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends eqp_locFindUniqueArgs>(args: SelectSubset<T, eqp_locFindUniqueArgs<ExtArgs>>): Prisma__eqp_locClient<$Result.GetResult<Prisma.$eqp_locPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Eqp_loc that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {eqp_locFindUniqueOrThrowArgs} args - Arguments to find a Eqp_loc
     * @example
     * // Get one Eqp_loc
     * const eqp_loc = await prisma.eqp_loc.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends eqp_locFindUniqueOrThrowArgs>(args: SelectSubset<T, eqp_locFindUniqueOrThrowArgs<ExtArgs>>): Prisma__eqp_locClient<$Result.GetResult<Prisma.$eqp_locPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Eqp_loc that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_locFindFirstArgs} args - Arguments to find a Eqp_loc
     * @example
     * // Get one Eqp_loc
     * const eqp_loc = await prisma.eqp_loc.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends eqp_locFindFirstArgs>(args?: SelectSubset<T, eqp_locFindFirstArgs<ExtArgs>>): Prisma__eqp_locClient<$Result.GetResult<Prisma.$eqp_locPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Eqp_loc that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_locFindFirstOrThrowArgs} args - Arguments to find a Eqp_loc
     * @example
     * // Get one Eqp_loc
     * const eqp_loc = await prisma.eqp_loc.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends eqp_locFindFirstOrThrowArgs>(args?: SelectSubset<T, eqp_locFindFirstOrThrowArgs<ExtArgs>>): Prisma__eqp_locClient<$Result.GetResult<Prisma.$eqp_locPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Eqp_locs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_locFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Eqp_locs
     * const eqp_locs = await prisma.eqp_loc.findMany()
     * 
     * // Get first 10 Eqp_locs
     * const eqp_locs = await prisma.eqp_loc.findMany({ take: 10 })
     * 
     * // Only select the `EqpTpoId`
     * const eqp_locWithEqpTpoIdOnly = await prisma.eqp_loc.findMany({ select: { EqpTpoId: true } })
     * 
     */
    findMany<T extends eqp_locFindManyArgs>(args?: SelectSubset<T, eqp_locFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$eqp_locPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Eqp_loc.
     * @param {eqp_locCreateArgs} args - Arguments to create a Eqp_loc.
     * @example
     * // Create one Eqp_loc
     * const Eqp_loc = await prisma.eqp_loc.create({
     *   data: {
     *     // ... data to create a Eqp_loc
     *   }
     * })
     * 
     */
    create<T extends eqp_locCreateArgs>(args: SelectSubset<T, eqp_locCreateArgs<ExtArgs>>): Prisma__eqp_locClient<$Result.GetResult<Prisma.$eqp_locPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Eqp_locs.
     * @param {eqp_locCreateManyArgs} args - Arguments to create many Eqp_locs.
     * @example
     * // Create many Eqp_locs
     * const eqp_loc = await prisma.eqp_loc.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends eqp_locCreateManyArgs>(args?: SelectSubset<T, eqp_locCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Eqp_loc.
     * @param {eqp_locDeleteArgs} args - Arguments to delete one Eqp_loc.
     * @example
     * // Delete one Eqp_loc
     * const Eqp_loc = await prisma.eqp_loc.delete({
     *   where: {
     *     // ... filter to delete one Eqp_loc
     *   }
     * })
     * 
     */
    delete<T extends eqp_locDeleteArgs>(args: SelectSubset<T, eqp_locDeleteArgs<ExtArgs>>): Prisma__eqp_locClient<$Result.GetResult<Prisma.$eqp_locPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Eqp_loc.
     * @param {eqp_locUpdateArgs} args - Arguments to update one Eqp_loc.
     * @example
     * // Update one Eqp_loc
     * const eqp_loc = await prisma.eqp_loc.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends eqp_locUpdateArgs>(args: SelectSubset<T, eqp_locUpdateArgs<ExtArgs>>): Prisma__eqp_locClient<$Result.GetResult<Prisma.$eqp_locPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Eqp_locs.
     * @param {eqp_locDeleteManyArgs} args - Arguments to filter Eqp_locs to delete.
     * @example
     * // Delete a few Eqp_locs
     * const { count } = await prisma.eqp_loc.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends eqp_locDeleteManyArgs>(args?: SelectSubset<T, eqp_locDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Eqp_locs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_locUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Eqp_locs
     * const eqp_loc = await prisma.eqp_loc.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends eqp_locUpdateManyArgs>(args: SelectSubset<T, eqp_locUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Eqp_loc.
     * @param {eqp_locUpsertArgs} args - Arguments to update or create a Eqp_loc.
     * @example
     * // Update or create a Eqp_loc
     * const eqp_loc = await prisma.eqp_loc.upsert({
     *   create: {
     *     // ... data to create a Eqp_loc
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Eqp_loc we want to update
     *   }
     * })
     */
    upsert<T extends eqp_locUpsertArgs>(args: SelectSubset<T, eqp_locUpsertArgs<ExtArgs>>): Prisma__eqp_locClient<$Result.GetResult<Prisma.$eqp_locPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Eqp_locs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_locCountArgs} args - Arguments to filter Eqp_locs to count.
     * @example
     * // Count the number of Eqp_locs
     * const count = await prisma.eqp_loc.count({
     *   where: {
     *     // ... the filter for the Eqp_locs we want to count
     *   }
     * })
    **/
    count<T extends eqp_locCountArgs>(
      args?: Subset<T, eqp_locCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Eqp_locCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Eqp_loc.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Eqp_locAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Eqp_locAggregateArgs>(args: Subset<T, Eqp_locAggregateArgs>): Prisma.PrismaPromise<GetEqp_locAggregateType<T>>

    /**
     * Group by Eqp_loc.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_locGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends eqp_locGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: eqp_locGroupByArgs['orderBy'] }
        : { orderBy?: eqp_locGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, eqp_locGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEqp_locGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the eqp_loc model
   */
  readonly fields: eqp_locFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for eqp_loc.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__eqp_locClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the eqp_loc model
   */
  interface eqp_locFieldRefs {
    readonly EqpTpoId: FieldRef<"eqp_loc", 'Int'>
    readonly EqpItmId: FieldRef<"eqp_loc", 'Int'>
    readonly UndId: FieldRef<"eqp_loc", 'Int'>
    readonly SttId: FieldRef<"eqp_loc", 'Int'>
    readonly UsrIdAlt: FieldRef<"eqp_loc", 'Int'>
    readonly DtaAlt: FieldRef<"eqp_loc", 'DateTime'>
    readonly MtvDel: FieldRef<"eqp_loc", 'String'>
  }
    

  // Custom InputTypes
  /**
   * eqp_loc findUnique
   */
  export type eqp_locFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_loc
     */
    select?: eqp_locSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_loc
     */
    omit?: eqp_locOmit<ExtArgs> | null
    /**
     * Filter, which eqp_loc to fetch.
     */
    where: eqp_locWhereUniqueInput
  }

  /**
   * eqp_loc findUniqueOrThrow
   */
  export type eqp_locFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_loc
     */
    select?: eqp_locSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_loc
     */
    omit?: eqp_locOmit<ExtArgs> | null
    /**
     * Filter, which eqp_loc to fetch.
     */
    where: eqp_locWhereUniqueInput
  }

  /**
   * eqp_loc findFirst
   */
  export type eqp_locFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_loc
     */
    select?: eqp_locSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_loc
     */
    omit?: eqp_locOmit<ExtArgs> | null
    /**
     * Filter, which eqp_loc to fetch.
     */
    where?: eqp_locWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_locs to fetch.
     */
    orderBy?: eqp_locOrderByWithRelationInput | eqp_locOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for eqp_locs.
     */
    cursor?: eqp_locWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_locs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_locs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of eqp_locs.
     */
    distinct?: Eqp_locScalarFieldEnum | Eqp_locScalarFieldEnum[]
  }

  /**
   * eqp_loc findFirstOrThrow
   */
  export type eqp_locFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_loc
     */
    select?: eqp_locSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_loc
     */
    omit?: eqp_locOmit<ExtArgs> | null
    /**
     * Filter, which eqp_loc to fetch.
     */
    where?: eqp_locWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_locs to fetch.
     */
    orderBy?: eqp_locOrderByWithRelationInput | eqp_locOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for eqp_locs.
     */
    cursor?: eqp_locWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_locs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_locs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of eqp_locs.
     */
    distinct?: Eqp_locScalarFieldEnum | Eqp_locScalarFieldEnum[]
  }

  /**
   * eqp_loc findMany
   */
  export type eqp_locFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_loc
     */
    select?: eqp_locSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_loc
     */
    omit?: eqp_locOmit<ExtArgs> | null
    /**
     * Filter, which eqp_locs to fetch.
     */
    where?: eqp_locWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_locs to fetch.
     */
    orderBy?: eqp_locOrderByWithRelationInput | eqp_locOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing eqp_locs.
     */
    cursor?: eqp_locWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_locs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_locs.
     */
    skip?: number
    distinct?: Eqp_locScalarFieldEnum | Eqp_locScalarFieldEnum[]
  }

  /**
   * eqp_loc create
   */
  export type eqp_locCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_loc
     */
    select?: eqp_locSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_loc
     */
    omit?: eqp_locOmit<ExtArgs> | null
    /**
     * The data needed to create a eqp_loc.
     */
    data: XOR<eqp_locCreateInput, eqp_locUncheckedCreateInput>
  }

  /**
   * eqp_loc createMany
   */
  export type eqp_locCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many eqp_locs.
     */
    data: eqp_locCreateManyInput | eqp_locCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * eqp_loc update
   */
  export type eqp_locUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_loc
     */
    select?: eqp_locSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_loc
     */
    omit?: eqp_locOmit<ExtArgs> | null
    /**
     * The data needed to update a eqp_loc.
     */
    data: XOR<eqp_locUpdateInput, eqp_locUncheckedUpdateInput>
    /**
     * Choose, which eqp_loc to update.
     */
    where: eqp_locWhereUniqueInput
  }

  /**
   * eqp_loc updateMany
   */
  export type eqp_locUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update eqp_locs.
     */
    data: XOR<eqp_locUpdateManyMutationInput, eqp_locUncheckedUpdateManyInput>
    /**
     * Filter which eqp_locs to update
     */
    where?: eqp_locWhereInput
    /**
     * Limit how many eqp_locs to update.
     */
    limit?: number
  }

  /**
   * eqp_loc upsert
   */
  export type eqp_locUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_loc
     */
    select?: eqp_locSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_loc
     */
    omit?: eqp_locOmit<ExtArgs> | null
    /**
     * The filter to search for the eqp_loc to update in case it exists.
     */
    where: eqp_locWhereUniqueInput
    /**
     * In case the eqp_loc found by the `where` argument doesn't exist, create a new eqp_loc with this data.
     */
    create: XOR<eqp_locCreateInput, eqp_locUncheckedCreateInput>
    /**
     * In case the eqp_loc was found with the provided `where` argument, update it with this data.
     */
    update: XOR<eqp_locUpdateInput, eqp_locUncheckedUpdateInput>
  }

  /**
   * eqp_loc delete
   */
  export type eqp_locDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_loc
     */
    select?: eqp_locSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_loc
     */
    omit?: eqp_locOmit<ExtArgs> | null
    /**
     * Filter which eqp_loc to delete.
     */
    where: eqp_locWhereUniqueInput
  }

  /**
   * eqp_loc deleteMany
   */
  export type eqp_locDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which eqp_locs to delete
     */
    where?: eqp_locWhereInput
    /**
     * Limit how many eqp_locs to delete.
     */
    limit?: number
  }

  /**
   * eqp_loc without action
   */
  export type eqp_locDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_loc
     */
    select?: eqp_locSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_loc
     */
    omit?: eqp_locOmit<ExtArgs> | null
  }


  /**
   * Model eqp_mdl
   */

  export type AggregateEqp_mdl = {
    _count: Eqp_mdlCountAggregateOutputType | null
    _avg: Eqp_mdlAvgAggregateOutputType | null
    _sum: Eqp_mdlSumAggregateOutputType | null
    _min: Eqp_mdlMinAggregateOutputType | null
    _max: Eqp_mdlMaxAggregateOutputType | null
  }

  export type Eqp_mdlAvgAggregateOutputType = {
    EqpTpoId: number | null
    EqpFbrId: number | null
    EqpMdlId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type Eqp_mdlSumAggregateOutputType = {
    EqpTpoId: number | null
    EqpFbrId: number | null
    EqpMdlId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type Eqp_mdlMinAggregateOutputType = {
    EqpTpoId: number | null
    EqpFbrId: number | null
    EqpMdlId: number | null
    EqpMdlNme: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type Eqp_mdlMaxAggregateOutputType = {
    EqpTpoId: number | null
    EqpFbrId: number | null
    EqpMdlId: number | null
    EqpMdlNme: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type Eqp_mdlCountAggregateOutputType = {
    EqpTpoId: number
    EqpFbrId: number
    EqpMdlId: number
    EqpMdlNme: number
    SttId: number
    UsrIdAlt: number
    DtaAlt: number
    MtvDel: number
    _all: number
  }


  export type Eqp_mdlAvgAggregateInputType = {
    EqpTpoId?: true
    EqpFbrId?: true
    EqpMdlId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type Eqp_mdlSumAggregateInputType = {
    EqpTpoId?: true
    EqpFbrId?: true
    EqpMdlId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type Eqp_mdlMinAggregateInputType = {
    EqpTpoId?: true
    EqpFbrId?: true
    EqpMdlId?: true
    EqpMdlNme?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type Eqp_mdlMaxAggregateInputType = {
    EqpTpoId?: true
    EqpFbrId?: true
    EqpMdlId?: true
    EqpMdlNme?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type Eqp_mdlCountAggregateInputType = {
    EqpTpoId?: true
    EqpFbrId?: true
    EqpMdlId?: true
    EqpMdlNme?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
    _all?: true
  }

  export type Eqp_mdlAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which eqp_mdl to aggregate.
     */
    where?: eqp_mdlWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_mdls to fetch.
     */
    orderBy?: eqp_mdlOrderByWithRelationInput | eqp_mdlOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: eqp_mdlWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_mdls from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_mdls.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned eqp_mdls
    **/
    _count?: true | Eqp_mdlCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Eqp_mdlAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Eqp_mdlSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Eqp_mdlMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Eqp_mdlMaxAggregateInputType
  }

  export type GetEqp_mdlAggregateType<T extends Eqp_mdlAggregateArgs> = {
        [P in keyof T & keyof AggregateEqp_mdl]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEqp_mdl[P]>
      : GetScalarType<T[P], AggregateEqp_mdl[P]>
  }




  export type eqp_mdlGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: eqp_mdlWhereInput
    orderBy?: eqp_mdlOrderByWithAggregationInput | eqp_mdlOrderByWithAggregationInput[]
    by: Eqp_mdlScalarFieldEnum[] | Eqp_mdlScalarFieldEnum
    having?: eqp_mdlScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Eqp_mdlCountAggregateInputType | true
    _avg?: Eqp_mdlAvgAggregateInputType
    _sum?: Eqp_mdlSumAggregateInputType
    _min?: Eqp_mdlMinAggregateInputType
    _max?: Eqp_mdlMaxAggregateInputType
  }

  export type Eqp_mdlGroupByOutputType = {
    EqpTpoId: number
    EqpFbrId: number
    EqpMdlId: number
    EqpMdlNme: string
    SttId: number
    UsrIdAlt: number
    DtaAlt: Date
    MtvDel: string | null
    _count: Eqp_mdlCountAggregateOutputType | null
    _avg: Eqp_mdlAvgAggregateOutputType | null
    _sum: Eqp_mdlSumAggregateOutputType | null
    _min: Eqp_mdlMinAggregateOutputType | null
    _max: Eqp_mdlMaxAggregateOutputType | null
  }

  type GetEqp_mdlGroupByPayload<T extends eqp_mdlGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Eqp_mdlGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Eqp_mdlGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Eqp_mdlGroupByOutputType[P]>
            : GetScalarType<T[P], Eqp_mdlGroupByOutputType[P]>
        }
      >
    >


  export type eqp_mdlSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    EqpTpoId?: boolean
    EqpFbrId?: boolean
    EqpMdlId?: boolean
    EqpMdlNme?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }, ExtArgs["result"]["eqp_mdl"]>



  export type eqp_mdlSelectScalar = {
    EqpTpoId?: boolean
    EqpFbrId?: boolean
    EqpMdlId?: boolean
    EqpMdlNme?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }

  export type eqp_mdlOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"EqpTpoId" | "EqpFbrId" | "EqpMdlId" | "EqpMdlNme" | "SttId" | "UsrIdAlt" | "DtaAlt" | "MtvDel", ExtArgs["result"]["eqp_mdl"]>

  export type $eqp_mdlPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "eqp_mdl"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      EqpTpoId: number
      EqpFbrId: number
      EqpMdlId: number
      EqpMdlNme: string
      SttId: number
      UsrIdAlt: number
      DtaAlt: Date
      MtvDel: string | null
    }, ExtArgs["result"]["eqp_mdl"]>
    composites: {}
  }

  type eqp_mdlGetPayload<S extends boolean | null | undefined | eqp_mdlDefaultArgs> = $Result.GetResult<Prisma.$eqp_mdlPayload, S>

  type eqp_mdlCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<eqp_mdlFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Eqp_mdlCountAggregateInputType | true
    }

  export interface eqp_mdlDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['eqp_mdl'], meta: { name: 'eqp_mdl' } }
    /**
     * Find zero or one Eqp_mdl that matches the filter.
     * @param {eqp_mdlFindUniqueArgs} args - Arguments to find a Eqp_mdl
     * @example
     * // Get one Eqp_mdl
     * const eqp_mdl = await prisma.eqp_mdl.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends eqp_mdlFindUniqueArgs>(args: SelectSubset<T, eqp_mdlFindUniqueArgs<ExtArgs>>): Prisma__eqp_mdlClient<$Result.GetResult<Prisma.$eqp_mdlPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Eqp_mdl that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {eqp_mdlFindUniqueOrThrowArgs} args - Arguments to find a Eqp_mdl
     * @example
     * // Get one Eqp_mdl
     * const eqp_mdl = await prisma.eqp_mdl.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends eqp_mdlFindUniqueOrThrowArgs>(args: SelectSubset<T, eqp_mdlFindUniqueOrThrowArgs<ExtArgs>>): Prisma__eqp_mdlClient<$Result.GetResult<Prisma.$eqp_mdlPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Eqp_mdl that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_mdlFindFirstArgs} args - Arguments to find a Eqp_mdl
     * @example
     * // Get one Eqp_mdl
     * const eqp_mdl = await prisma.eqp_mdl.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends eqp_mdlFindFirstArgs>(args?: SelectSubset<T, eqp_mdlFindFirstArgs<ExtArgs>>): Prisma__eqp_mdlClient<$Result.GetResult<Prisma.$eqp_mdlPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Eqp_mdl that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_mdlFindFirstOrThrowArgs} args - Arguments to find a Eqp_mdl
     * @example
     * // Get one Eqp_mdl
     * const eqp_mdl = await prisma.eqp_mdl.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends eqp_mdlFindFirstOrThrowArgs>(args?: SelectSubset<T, eqp_mdlFindFirstOrThrowArgs<ExtArgs>>): Prisma__eqp_mdlClient<$Result.GetResult<Prisma.$eqp_mdlPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Eqp_mdls that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_mdlFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Eqp_mdls
     * const eqp_mdls = await prisma.eqp_mdl.findMany()
     * 
     * // Get first 10 Eqp_mdls
     * const eqp_mdls = await prisma.eqp_mdl.findMany({ take: 10 })
     * 
     * // Only select the `EqpTpoId`
     * const eqp_mdlWithEqpTpoIdOnly = await prisma.eqp_mdl.findMany({ select: { EqpTpoId: true } })
     * 
     */
    findMany<T extends eqp_mdlFindManyArgs>(args?: SelectSubset<T, eqp_mdlFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$eqp_mdlPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Eqp_mdl.
     * @param {eqp_mdlCreateArgs} args - Arguments to create a Eqp_mdl.
     * @example
     * // Create one Eqp_mdl
     * const Eqp_mdl = await prisma.eqp_mdl.create({
     *   data: {
     *     // ... data to create a Eqp_mdl
     *   }
     * })
     * 
     */
    create<T extends eqp_mdlCreateArgs>(args: SelectSubset<T, eqp_mdlCreateArgs<ExtArgs>>): Prisma__eqp_mdlClient<$Result.GetResult<Prisma.$eqp_mdlPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Eqp_mdls.
     * @param {eqp_mdlCreateManyArgs} args - Arguments to create many Eqp_mdls.
     * @example
     * // Create many Eqp_mdls
     * const eqp_mdl = await prisma.eqp_mdl.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends eqp_mdlCreateManyArgs>(args?: SelectSubset<T, eqp_mdlCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Eqp_mdl.
     * @param {eqp_mdlDeleteArgs} args - Arguments to delete one Eqp_mdl.
     * @example
     * // Delete one Eqp_mdl
     * const Eqp_mdl = await prisma.eqp_mdl.delete({
     *   where: {
     *     // ... filter to delete one Eqp_mdl
     *   }
     * })
     * 
     */
    delete<T extends eqp_mdlDeleteArgs>(args: SelectSubset<T, eqp_mdlDeleteArgs<ExtArgs>>): Prisma__eqp_mdlClient<$Result.GetResult<Prisma.$eqp_mdlPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Eqp_mdl.
     * @param {eqp_mdlUpdateArgs} args - Arguments to update one Eqp_mdl.
     * @example
     * // Update one Eqp_mdl
     * const eqp_mdl = await prisma.eqp_mdl.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends eqp_mdlUpdateArgs>(args: SelectSubset<T, eqp_mdlUpdateArgs<ExtArgs>>): Prisma__eqp_mdlClient<$Result.GetResult<Prisma.$eqp_mdlPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Eqp_mdls.
     * @param {eqp_mdlDeleteManyArgs} args - Arguments to filter Eqp_mdls to delete.
     * @example
     * // Delete a few Eqp_mdls
     * const { count } = await prisma.eqp_mdl.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends eqp_mdlDeleteManyArgs>(args?: SelectSubset<T, eqp_mdlDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Eqp_mdls.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_mdlUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Eqp_mdls
     * const eqp_mdl = await prisma.eqp_mdl.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends eqp_mdlUpdateManyArgs>(args: SelectSubset<T, eqp_mdlUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Eqp_mdl.
     * @param {eqp_mdlUpsertArgs} args - Arguments to update or create a Eqp_mdl.
     * @example
     * // Update or create a Eqp_mdl
     * const eqp_mdl = await prisma.eqp_mdl.upsert({
     *   create: {
     *     // ... data to create a Eqp_mdl
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Eqp_mdl we want to update
     *   }
     * })
     */
    upsert<T extends eqp_mdlUpsertArgs>(args: SelectSubset<T, eqp_mdlUpsertArgs<ExtArgs>>): Prisma__eqp_mdlClient<$Result.GetResult<Prisma.$eqp_mdlPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Eqp_mdls.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_mdlCountArgs} args - Arguments to filter Eqp_mdls to count.
     * @example
     * // Count the number of Eqp_mdls
     * const count = await prisma.eqp_mdl.count({
     *   where: {
     *     // ... the filter for the Eqp_mdls we want to count
     *   }
     * })
    **/
    count<T extends eqp_mdlCountArgs>(
      args?: Subset<T, eqp_mdlCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Eqp_mdlCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Eqp_mdl.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Eqp_mdlAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Eqp_mdlAggregateArgs>(args: Subset<T, Eqp_mdlAggregateArgs>): Prisma.PrismaPromise<GetEqp_mdlAggregateType<T>>

    /**
     * Group by Eqp_mdl.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_mdlGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends eqp_mdlGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: eqp_mdlGroupByArgs['orderBy'] }
        : { orderBy?: eqp_mdlGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, eqp_mdlGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEqp_mdlGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the eqp_mdl model
   */
  readonly fields: eqp_mdlFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for eqp_mdl.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__eqp_mdlClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the eqp_mdl model
   */
  interface eqp_mdlFieldRefs {
    readonly EqpTpoId: FieldRef<"eqp_mdl", 'Int'>
    readonly EqpFbrId: FieldRef<"eqp_mdl", 'Int'>
    readonly EqpMdlId: FieldRef<"eqp_mdl", 'Int'>
    readonly EqpMdlNme: FieldRef<"eqp_mdl", 'String'>
    readonly SttId: FieldRef<"eqp_mdl", 'Int'>
    readonly UsrIdAlt: FieldRef<"eqp_mdl", 'Int'>
    readonly DtaAlt: FieldRef<"eqp_mdl", 'DateTime'>
    readonly MtvDel: FieldRef<"eqp_mdl", 'String'>
  }
    

  // Custom InputTypes
  /**
   * eqp_mdl findUnique
   */
  export type eqp_mdlFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_mdl
     */
    select?: eqp_mdlSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_mdl
     */
    omit?: eqp_mdlOmit<ExtArgs> | null
    /**
     * Filter, which eqp_mdl to fetch.
     */
    where: eqp_mdlWhereUniqueInput
  }

  /**
   * eqp_mdl findUniqueOrThrow
   */
  export type eqp_mdlFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_mdl
     */
    select?: eqp_mdlSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_mdl
     */
    omit?: eqp_mdlOmit<ExtArgs> | null
    /**
     * Filter, which eqp_mdl to fetch.
     */
    where: eqp_mdlWhereUniqueInput
  }

  /**
   * eqp_mdl findFirst
   */
  export type eqp_mdlFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_mdl
     */
    select?: eqp_mdlSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_mdl
     */
    omit?: eqp_mdlOmit<ExtArgs> | null
    /**
     * Filter, which eqp_mdl to fetch.
     */
    where?: eqp_mdlWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_mdls to fetch.
     */
    orderBy?: eqp_mdlOrderByWithRelationInput | eqp_mdlOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for eqp_mdls.
     */
    cursor?: eqp_mdlWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_mdls from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_mdls.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of eqp_mdls.
     */
    distinct?: Eqp_mdlScalarFieldEnum | Eqp_mdlScalarFieldEnum[]
  }

  /**
   * eqp_mdl findFirstOrThrow
   */
  export type eqp_mdlFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_mdl
     */
    select?: eqp_mdlSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_mdl
     */
    omit?: eqp_mdlOmit<ExtArgs> | null
    /**
     * Filter, which eqp_mdl to fetch.
     */
    where?: eqp_mdlWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_mdls to fetch.
     */
    orderBy?: eqp_mdlOrderByWithRelationInput | eqp_mdlOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for eqp_mdls.
     */
    cursor?: eqp_mdlWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_mdls from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_mdls.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of eqp_mdls.
     */
    distinct?: Eqp_mdlScalarFieldEnum | Eqp_mdlScalarFieldEnum[]
  }

  /**
   * eqp_mdl findMany
   */
  export type eqp_mdlFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_mdl
     */
    select?: eqp_mdlSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_mdl
     */
    omit?: eqp_mdlOmit<ExtArgs> | null
    /**
     * Filter, which eqp_mdls to fetch.
     */
    where?: eqp_mdlWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_mdls to fetch.
     */
    orderBy?: eqp_mdlOrderByWithRelationInput | eqp_mdlOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing eqp_mdls.
     */
    cursor?: eqp_mdlWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_mdls from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_mdls.
     */
    skip?: number
    distinct?: Eqp_mdlScalarFieldEnum | Eqp_mdlScalarFieldEnum[]
  }

  /**
   * eqp_mdl create
   */
  export type eqp_mdlCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_mdl
     */
    select?: eqp_mdlSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_mdl
     */
    omit?: eqp_mdlOmit<ExtArgs> | null
    /**
     * The data needed to create a eqp_mdl.
     */
    data: XOR<eqp_mdlCreateInput, eqp_mdlUncheckedCreateInput>
  }

  /**
   * eqp_mdl createMany
   */
  export type eqp_mdlCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many eqp_mdls.
     */
    data: eqp_mdlCreateManyInput | eqp_mdlCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * eqp_mdl update
   */
  export type eqp_mdlUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_mdl
     */
    select?: eqp_mdlSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_mdl
     */
    omit?: eqp_mdlOmit<ExtArgs> | null
    /**
     * The data needed to update a eqp_mdl.
     */
    data: XOR<eqp_mdlUpdateInput, eqp_mdlUncheckedUpdateInput>
    /**
     * Choose, which eqp_mdl to update.
     */
    where: eqp_mdlWhereUniqueInput
  }

  /**
   * eqp_mdl updateMany
   */
  export type eqp_mdlUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update eqp_mdls.
     */
    data: XOR<eqp_mdlUpdateManyMutationInput, eqp_mdlUncheckedUpdateManyInput>
    /**
     * Filter which eqp_mdls to update
     */
    where?: eqp_mdlWhereInput
    /**
     * Limit how many eqp_mdls to update.
     */
    limit?: number
  }

  /**
   * eqp_mdl upsert
   */
  export type eqp_mdlUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_mdl
     */
    select?: eqp_mdlSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_mdl
     */
    omit?: eqp_mdlOmit<ExtArgs> | null
    /**
     * The filter to search for the eqp_mdl to update in case it exists.
     */
    where: eqp_mdlWhereUniqueInput
    /**
     * In case the eqp_mdl found by the `where` argument doesn't exist, create a new eqp_mdl with this data.
     */
    create: XOR<eqp_mdlCreateInput, eqp_mdlUncheckedCreateInput>
    /**
     * In case the eqp_mdl was found with the provided `where` argument, update it with this data.
     */
    update: XOR<eqp_mdlUpdateInput, eqp_mdlUncheckedUpdateInput>
  }

  /**
   * eqp_mdl delete
   */
  export type eqp_mdlDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_mdl
     */
    select?: eqp_mdlSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_mdl
     */
    omit?: eqp_mdlOmit<ExtArgs> | null
    /**
     * Filter which eqp_mdl to delete.
     */
    where: eqp_mdlWhereUniqueInput
  }

  /**
   * eqp_mdl deleteMany
   */
  export type eqp_mdlDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which eqp_mdls to delete
     */
    where?: eqp_mdlWhereInput
    /**
     * Limit how many eqp_mdls to delete.
     */
    limit?: number
  }

  /**
   * eqp_mdl without action
   */
  export type eqp_mdlDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_mdl
     */
    select?: eqp_mdlSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_mdl
     */
    omit?: eqp_mdlOmit<ExtArgs> | null
  }


  /**
   * Model eqp_tpo
   */

  export type AggregateEqp_tpo = {
    _count: Eqp_tpoCountAggregateOutputType | null
    _avg: Eqp_tpoAvgAggregateOutputType | null
    _sum: Eqp_tpoSumAggregateOutputType | null
    _min: Eqp_tpoMinAggregateOutputType | null
    _max: Eqp_tpoMaxAggregateOutputType | null
  }

  export type Eqp_tpoAvgAggregateOutputType = {
    EqpTpoId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type Eqp_tpoSumAggregateOutputType = {
    EqpTpoId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type Eqp_tpoMinAggregateOutputType = {
    EqpTpoId: number | null
    EqpTpoNme: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type Eqp_tpoMaxAggregateOutputType = {
    EqpTpoId: number | null
    EqpTpoNme: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type Eqp_tpoCountAggregateOutputType = {
    EqpTpoId: number
    EqpTpoNme: number
    SttId: number
    UsrIdAlt: number
    DtaAlt: number
    MtvDel: number
    _all: number
  }


  export type Eqp_tpoAvgAggregateInputType = {
    EqpTpoId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type Eqp_tpoSumAggregateInputType = {
    EqpTpoId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type Eqp_tpoMinAggregateInputType = {
    EqpTpoId?: true
    EqpTpoNme?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type Eqp_tpoMaxAggregateInputType = {
    EqpTpoId?: true
    EqpTpoNme?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type Eqp_tpoCountAggregateInputType = {
    EqpTpoId?: true
    EqpTpoNme?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
    _all?: true
  }

  export type Eqp_tpoAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which eqp_tpo to aggregate.
     */
    where?: eqp_tpoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_tpos to fetch.
     */
    orderBy?: eqp_tpoOrderByWithRelationInput | eqp_tpoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: eqp_tpoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_tpos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_tpos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned eqp_tpos
    **/
    _count?: true | Eqp_tpoCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Eqp_tpoAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Eqp_tpoSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Eqp_tpoMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Eqp_tpoMaxAggregateInputType
  }

  export type GetEqp_tpoAggregateType<T extends Eqp_tpoAggregateArgs> = {
        [P in keyof T & keyof AggregateEqp_tpo]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEqp_tpo[P]>
      : GetScalarType<T[P], AggregateEqp_tpo[P]>
  }




  export type eqp_tpoGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: eqp_tpoWhereInput
    orderBy?: eqp_tpoOrderByWithAggregationInput | eqp_tpoOrderByWithAggregationInput[]
    by: Eqp_tpoScalarFieldEnum[] | Eqp_tpoScalarFieldEnum
    having?: eqp_tpoScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Eqp_tpoCountAggregateInputType | true
    _avg?: Eqp_tpoAvgAggregateInputType
    _sum?: Eqp_tpoSumAggregateInputType
    _min?: Eqp_tpoMinAggregateInputType
    _max?: Eqp_tpoMaxAggregateInputType
  }

  export type Eqp_tpoGroupByOutputType = {
    EqpTpoId: number
    EqpTpoNme: string
    SttId: number
    UsrIdAlt: number
    DtaAlt: Date
    MtvDel: string | null
    _count: Eqp_tpoCountAggregateOutputType | null
    _avg: Eqp_tpoAvgAggregateOutputType | null
    _sum: Eqp_tpoSumAggregateOutputType | null
    _min: Eqp_tpoMinAggregateOutputType | null
    _max: Eqp_tpoMaxAggregateOutputType | null
  }

  type GetEqp_tpoGroupByPayload<T extends eqp_tpoGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Eqp_tpoGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Eqp_tpoGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Eqp_tpoGroupByOutputType[P]>
            : GetScalarType<T[P], Eqp_tpoGroupByOutputType[P]>
        }
      >
    >


  export type eqp_tpoSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    EqpTpoId?: boolean
    EqpTpoNme?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }, ExtArgs["result"]["eqp_tpo"]>



  export type eqp_tpoSelectScalar = {
    EqpTpoId?: boolean
    EqpTpoNme?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }

  export type eqp_tpoOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"EqpTpoId" | "EqpTpoNme" | "SttId" | "UsrIdAlt" | "DtaAlt" | "MtvDel", ExtArgs["result"]["eqp_tpo"]>

  export type $eqp_tpoPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "eqp_tpo"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      EqpTpoId: number
      EqpTpoNme: string
      SttId: number
      UsrIdAlt: number
      DtaAlt: Date
      MtvDel: string | null
    }, ExtArgs["result"]["eqp_tpo"]>
    composites: {}
  }

  type eqp_tpoGetPayload<S extends boolean | null | undefined | eqp_tpoDefaultArgs> = $Result.GetResult<Prisma.$eqp_tpoPayload, S>

  type eqp_tpoCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<eqp_tpoFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Eqp_tpoCountAggregateInputType | true
    }

  export interface eqp_tpoDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['eqp_tpo'], meta: { name: 'eqp_tpo' } }
    /**
     * Find zero or one Eqp_tpo that matches the filter.
     * @param {eqp_tpoFindUniqueArgs} args - Arguments to find a Eqp_tpo
     * @example
     * // Get one Eqp_tpo
     * const eqp_tpo = await prisma.eqp_tpo.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends eqp_tpoFindUniqueArgs>(args: SelectSubset<T, eqp_tpoFindUniqueArgs<ExtArgs>>): Prisma__eqp_tpoClient<$Result.GetResult<Prisma.$eqp_tpoPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Eqp_tpo that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {eqp_tpoFindUniqueOrThrowArgs} args - Arguments to find a Eqp_tpo
     * @example
     * // Get one Eqp_tpo
     * const eqp_tpo = await prisma.eqp_tpo.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends eqp_tpoFindUniqueOrThrowArgs>(args: SelectSubset<T, eqp_tpoFindUniqueOrThrowArgs<ExtArgs>>): Prisma__eqp_tpoClient<$Result.GetResult<Prisma.$eqp_tpoPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Eqp_tpo that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_tpoFindFirstArgs} args - Arguments to find a Eqp_tpo
     * @example
     * // Get one Eqp_tpo
     * const eqp_tpo = await prisma.eqp_tpo.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends eqp_tpoFindFirstArgs>(args?: SelectSubset<T, eqp_tpoFindFirstArgs<ExtArgs>>): Prisma__eqp_tpoClient<$Result.GetResult<Prisma.$eqp_tpoPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Eqp_tpo that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_tpoFindFirstOrThrowArgs} args - Arguments to find a Eqp_tpo
     * @example
     * // Get one Eqp_tpo
     * const eqp_tpo = await prisma.eqp_tpo.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends eqp_tpoFindFirstOrThrowArgs>(args?: SelectSubset<T, eqp_tpoFindFirstOrThrowArgs<ExtArgs>>): Prisma__eqp_tpoClient<$Result.GetResult<Prisma.$eqp_tpoPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Eqp_tpos that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_tpoFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Eqp_tpos
     * const eqp_tpos = await prisma.eqp_tpo.findMany()
     * 
     * // Get first 10 Eqp_tpos
     * const eqp_tpos = await prisma.eqp_tpo.findMany({ take: 10 })
     * 
     * // Only select the `EqpTpoId`
     * const eqp_tpoWithEqpTpoIdOnly = await prisma.eqp_tpo.findMany({ select: { EqpTpoId: true } })
     * 
     */
    findMany<T extends eqp_tpoFindManyArgs>(args?: SelectSubset<T, eqp_tpoFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$eqp_tpoPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Eqp_tpo.
     * @param {eqp_tpoCreateArgs} args - Arguments to create a Eqp_tpo.
     * @example
     * // Create one Eqp_tpo
     * const Eqp_tpo = await prisma.eqp_tpo.create({
     *   data: {
     *     // ... data to create a Eqp_tpo
     *   }
     * })
     * 
     */
    create<T extends eqp_tpoCreateArgs>(args: SelectSubset<T, eqp_tpoCreateArgs<ExtArgs>>): Prisma__eqp_tpoClient<$Result.GetResult<Prisma.$eqp_tpoPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Eqp_tpos.
     * @param {eqp_tpoCreateManyArgs} args - Arguments to create many Eqp_tpos.
     * @example
     * // Create many Eqp_tpos
     * const eqp_tpo = await prisma.eqp_tpo.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends eqp_tpoCreateManyArgs>(args?: SelectSubset<T, eqp_tpoCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Eqp_tpo.
     * @param {eqp_tpoDeleteArgs} args - Arguments to delete one Eqp_tpo.
     * @example
     * // Delete one Eqp_tpo
     * const Eqp_tpo = await prisma.eqp_tpo.delete({
     *   where: {
     *     // ... filter to delete one Eqp_tpo
     *   }
     * })
     * 
     */
    delete<T extends eqp_tpoDeleteArgs>(args: SelectSubset<T, eqp_tpoDeleteArgs<ExtArgs>>): Prisma__eqp_tpoClient<$Result.GetResult<Prisma.$eqp_tpoPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Eqp_tpo.
     * @param {eqp_tpoUpdateArgs} args - Arguments to update one Eqp_tpo.
     * @example
     * // Update one Eqp_tpo
     * const eqp_tpo = await prisma.eqp_tpo.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends eqp_tpoUpdateArgs>(args: SelectSubset<T, eqp_tpoUpdateArgs<ExtArgs>>): Prisma__eqp_tpoClient<$Result.GetResult<Prisma.$eqp_tpoPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Eqp_tpos.
     * @param {eqp_tpoDeleteManyArgs} args - Arguments to filter Eqp_tpos to delete.
     * @example
     * // Delete a few Eqp_tpos
     * const { count } = await prisma.eqp_tpo.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends eqp_tpoDeleteManyArgs>(args?: SelectSubset<T, eqp_tpoDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Eqp_tpos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_tpoUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Eqp_tpos
     * const eqp_tpo = await prisma.eqp_tpo.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends eqp_tpoUpdateManyArgs>(args: SelectSubset<T, eqp_tpoUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Eqp_tpo.
     * @param {eqp_tpoUpsertArgs} args - Arguments to update or create a Eqp_tpo.
     * @example
     * // Update or create a Eqp_tpo
     * const eqp_tpo = await prisma.eqp_tpo.upsert({
     *   create: {
     *     // ... data to create a Eqp_tpo
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Eqp_tpo we want to update
     *   }
     * })
     */
    upsert<T extends eqp_tpoUpsertArgs>(args: SelectSubset<T, eqp_tpoUpsertArgs<ExtArgs>>): Prisma__eqp_tpoClient<$Result.GetResult<Prisma.$eqp_tpoPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Eqp_tpos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_tpoCountArgs} args - Arguments to filter Eqp_tpos to count.
     * @example
     * // Count the number of Eqp_tpos
     * const count = await prisma.eqp_tpo.count({
     *   where: {
     *     // ... the filter for the Eqp_tpos we want to count
     *   }
     * })
    **/
    count<T extends eqp_tpoCountArgs>(
      args?: Subset<T, eqp_tpoCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Eqp_tpoCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Eqp_tpo.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Eqp_tpoAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Eqp_tpoAggregateArgs>(args: Subset<T, Eqp_tpoAggregateArgs>): Prisma.PrismaPromise<GetEqp_tpoAggregateType<T>>

    /**
     * Group by Eqp_tpo.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {eqp_tpoGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends eqp_tpoGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: eqp_tpoGroupByArgs['orderBy'] }
        : { orderBy?: eqp_tpoGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, eqp_tpoGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEqp_tpoGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the eqp_tpo model
   */
  readonly fields: eqp_tpoFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for eqp_tpo.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__eqp_tpoClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the eqp_tpo model
   */
  interface eqp_tpoFieldRefs {
    readonly EqpTpoId: FieldRef<"eqp_tpo", 'Int'>
    readonly EqpTpoNme: FieldRef<"eqp_tpo", 'String'>
    readonly SttId: FieldRef<"eqp_tpo", 'Int'>
    readonly UsrIdAlt: FieldRef<"eqp_tpo", 'Int'>
    readonly DtaAlt: FieldRef<"eqp_tpo", 'DateTime'>
    readonly MtvDel: FieldRef<"eqp_tpo", 'String'>
  }
    

  // Custom InputTypes
  /**
   * eqp_tpo findUnique
   */
  export type eqp_tpoFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_tpo
     */
    select?: eqp_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_tpo
     */
    omit?: eqp_tpoOmit<ExtArgs> | null
    /**
     * Filter, which eqp_tpo to fetch.
     */
    where: eqp_tpoWhereUniqueInput
  }

  /**
   * eqp_tpo findUniqueOrThrow
   */
  export type eqp_tpoFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_tpo
     */
    select?: eqp_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_tpo
     */
    omit?: eqp_tpoOmit<ExtArgs> | null
    /**
     * Filter, which eqp_tpo to fetch.
     */
    where: eqp_tpoWhereUniqueInput
  }

  /**
   * eqp_tpo findFirst
   */
  export type eqp_tpoFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_tpo
     */
    select?: eqp_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_tpo
     */
    omit?: eqp_tpoOmit<ExtArgs> | null
    /**
     * Filter, which eqp_tpo to fetch.
     */
    where?: eqp_tpoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_tpos to fetch.
     */
    orderBy?: eqp_tpoOrderByWithRelationInput | eqp_tpoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for eqp_tpos.
     */
    cursor?: eqp_tpoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_tpos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_tpos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of eqp_tpos.
     */
    distinct?: Eqp_tpoScalarFieldEnum | Eqp_tpoScalarFieldEnum[]
  }

  /**
   * eqp_tpo findFirstOrThrow
   */
  export type eqp_tpoFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_tpo
     */
    select?: eqp_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_tpo
     */
    omit?: eqp_tpoOmit<ExtArgs> | null
    /**
     * Filter, which eqp_tpo to fetch.
     */
    where?: eqp_tpoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_tpos to fetch.
     */
    orderBy?: eqp_tpoOrderByWithRelationInput | eqp_tpoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for eqp_tpos.
     */
    cursor?: eqp_tpoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_tpos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_tpos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of eqp_tpos.
     */
    distinct?: Eqp_tpoScalarFieldEnum | Eqp_tpoScalarFieldEnum[]
  }

  /**
   * eqp_tpo findMany
   */
  export type eqp_tpoFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_tpo
     */
    select?: eqp_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_tpo
     */
    omit?: eqp_tpoOmit<ExtArgs> | null
    /**
     * Filter, which eqp_tpos to fetch.
     */
    where?: eqp_tpoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of eqp_tpos to fetch.
     */
    orderBy?: eqp_tpoOrderByWithRelationInput | eqp_tpoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing eqp_tpos.
     */
    cursor?: eqp_tpoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` eqp_tpos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` eqp_tpos.
     */
    skip?: number
    distinct?: Eqp_tpoScalarFieldEnum | Eqp_tpoScalarFieldEnum[]
  }

  /**
   * eqp_tpo create
   */
  export type eqp_tpoCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_tpo
     */
    select?: eqp_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_tpo
     */
    omit?: eqp_tpoOmit<ExtArgs> | null
    /**
     * The data needed to create a eqp_tpo.
     */
    data: XOR<eqp_tpoCreateInput, eqp_tpoUncheckedCreateInput>
  }

  /**
   * eqp_tpo createMany
   */
  export type eqp_tpoCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many eqp_tpos.
     */
    data: eqp_tpoCreateManyInput | eqp_tpoCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * eqp_tpo update
   */
  export type eqp_tpoUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_tpo
     */
    select?: eqp_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_tpo
     */
    omit?: eqp_tpoOmit<ExtArgs> | null
    /**
     * The data needed to update a eqp_tpo.
     */
    data: XOR<eqp_tpoUpdateInput, eqp_tpoUncheckedUpdateInput>
    /**
     * Choose, which eqp_tpo to update.
     */
    where: eqp_tpoWhereUniqueInput
  }

  /**
   * eqp_tpo updateMany
   */
  export type eqp_tpoUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update eqp_tpos.
     */
    data: XOR<eqp_tpoUpdateManyMutationInput, eqp_tpoUncheckedUpdateManyInput>
    /**
     * Filter which eqp_tpos to update
     */
    where?: eqp_tpoWhereInput
    /**
     * Limit how many eqp_tpos to update.
     */
    limit?: number
  }

  /**
   * eqp_tpo upsert
   */
  export type eqp_tpoUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_tpo
     */
    select?: eqp_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_tpo
     */
    omit?: eqp_tpoOmit<ExtArgs> | null
    /**
     * The filter to search for the eqp_tpo to update in case it exists.
     */
    where: eqp_tpoWhereUniqueInput
    /**
     * In case the eqp_tpo found by the `where` argument doesn't exist, create a new eqp_tpo with this data.
     */
    create: XOR<eqp_tpoCreateInput, eqp_tpoUncheckedCreateInput>
    /**
     * In case the eqp_tpo was found with the provided `where` argument, update it with this data.
     */
    update: XOR<eqp_tpoUpdateInput, eqp_tpoUncheckedUpdateInput>
  }

  /**
   * eqp_tpo delete
   */
  export type eqp_tpoDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_tpo
     */
    select?: eqp_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_tpo
     */
    omit?: eqp_tpoOmit<ExtArgs> | null
    /**
     * Filter which eqp_tpo to delete.
     */
    where: eqp_tpoWhereUniqueInput
  }

  /**
   * eqp_tpo deleteMany
   */
  export type eqp_tpoDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which eqp_tpos to delete
     */
    where?: eqp_tpoWhereInput
    /**
     * Limit how many eqp_tpos to delete.
     */
    limit?: number
  }

  /**
   * eqp_tpo without action
   */
  export type eqp_tpoDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the eqp_tpo
     */
    select?: eqp_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the eqp_tpo
     */
    omit?: eqp_tpoOmit<ExtArgs> | null
  }


  /**
   * Model frn
   */

  export type AggregateFrn = {
    _count: FrnCountAggregateOutputType | null
    _avg: FrnAvgAggregateOutputType | null
    _sum: FrnSumAggregateOutputType | null
    _min: FrnMinAggregateOutputType | null
    _max: FrnMaxAggregateOutputType | null
  }

  export type FrnAvgAggregateOutputType = {
    FrnId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type FrnSumAggregateOutputType = {
    FrnId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type FrnMinAggregateOutputType = {
    FrnId: number | null
    FrnNme: string | null
    FrnRdz: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type FrnMaxAggregateOutputType = {
    FrnId: number | null
    FrnNme: string | null
    FrnRdz: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type FrnCountAggregateOutputType = {
    FrnId: number
    FrnNme: number
    FrnRdz: number
    SttId: number
    UsrIdAlt: number
    DtaAlt: number
    MtvDel: number
    _all: number
  }


  export type FrnAvgAggregateInputType = {
    FrnId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type FrnSumAggregateInputType = {
    FrnId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type FrnMinAggregateInputType = {
    FrnId?: true
    FrnNme?: true
    FrnRdz?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type FrnMaxAggregateInputType = {
    FrnId?: true
    FrnNme?: true
    FrnRdz?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type FrnCountAggregateInputType = {
    FrnId?: true
    FrnNme?: true
    FrnRdz?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
    _all?: true
  }

  export type FrnAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which frn to aggregate.
     */
    where?: frnWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of frns to fetch.
     */
    orderBy?: frnOrderByWithRelationInput | frnOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: frnWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` frns from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` frns.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned frns
    **/
    _count?: true | FrnCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: FrnAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: FrnSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: FrnMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: FrnMaxAggregateInputType
  }

  export type GetFrnAggregateType<T extends FrnAggregateArgs> = {
        [P in keyof T & keyof AggregateFrn]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateFrn[P]>
      : GetScalarType<T[P], AggregateFrn[P]>
  }




  export type frnGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: frnWhereInput
    orderBy?: frnOrderByWithAggregationInput | frnOrderByWithAggregationInput[]
    by: FrnScalarFieldEnum[] | FrnScalarFieldEnum
    having?: frnScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: FrnCountAggregateInputType | true
    _avg?: FrnAvgAggregateInputType
    _sum?: FrnSumAggregateInputType
    _min?: FrnMinAggregateInputType
    _max?: FrnMaxAggregateInputType
  }

  export type FrnGroupByOutputType = {
    FrnId: number
    FrnNme: string
    FrnRdz: string
    SttId: number
    UsrIdAlt: number
    DtaAlt: Date
    MtvDel: string | null
    _count: FrnCountAggregateOutputType | null
    _avg: FrnAvgAggregateOutputType | null
    _sum: FrnSumAggregateOutputType | null
    _min: FrnMinAggregateOutputType | null
    _max: FrnMaxAggregateOutputType | null
  }

  type GetFrnGroupByPayload<T extends frnGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<FrnGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof FrnGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], FrnGroupByOutputType[P]>
            : GetScalarType<T[P], FrnGroupByOutputType[P]>
        }
      >
    >


  export type frnSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    FrnId?: boolean
    FrnNme?: boolean
    FrnRdz?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }, ExtArgs["result"]["frn"]>



  export type frnSelectScalar = {
    FrnId?: boolean
    FrnNme?: boolean
    FrnRdz?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }

  export type frnOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"FrnId" | "FrnNme" | "FrnRdz" | "SttId" | "UsrIdAlt" | "DtaAlt" | "MtvDel", ExtArgs["result"]["frn"]>

  export type $frnPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "frn"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      FrnId: number
      FrnNme: string
      FrnRdz: string
      SttId: number
      UsrIdAlt: number
      DtaAlt: Date
      MtvDel: string | null
    }, ExtArgs["result"]["frn"]>
    composites: {}
  }

  type frnGetPayload<S extends boolean | null | undefined | frnDefaultArgs> = $Result.GetResult<Prisma.$frnPayload, S>

  type frnCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<frnFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: FrnCountAggregateInputType | true
    }

  export interface frnDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['frn'], meta: { name: 'frn' } }
    /**
     * Find zero or one Frn that matches the filter.
     * @param {frnFindUniqueArgs} args - Arguments to find a Frn
     * @example
     * // Get one Frn
     * const frn = await prisma.frn.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends frnFindUniqueArgs>(args: SelectSubset<T, frnFindUniqueArgs<ExtArgs>>): Prisma__frnClient<$Result.GetResult<Prisma.$frnPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Frn that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {frnFindUniqueOrThrowArgs} args - Arguments to find a Frn
     * @example
     * // Get one Frn
     * const frn = await prisma.frn.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends frnFindUniqueOrThrowArgs>(args: SelectSubset<T, frnFindUniqueOrThrowArgs<ExtArgs>>): Prisma__frnClient<$Result.GetResult<Prisma.$frnPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Frn that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {frnFindFirstArgs} args - Arguments to find a Frn
     * @example
     * // Get one Frn
     * const frn = await prisma.frn.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends frnFindFirstArgs>(args?: SelectSubset<T, frnFindFirstArgs<ExtArgs>>): Prisma__frnClient<$Result.GetResult<Prisma.$frnPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Frn that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {frnFindFirstOrThrowArgs} args - Arguments to find a Frn
     * @example
     * // Get one Frn
     * const frn = await prisma.frn.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends frnFindFirstOrThrowArgs>(args?: SelectSubset<T, frnFindFirstOrThrowArgs<ExtArgs>>): Prisma__frnClient<$Result.GetResult<Prisma.$frnPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Frns that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {frnFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Frns
     * const frns = await prisma.frn.findMany()
     * 
     * // Get first 10 Frns
     * const frns = await prisma.frn.findMany({ take: 10 })
     * 
     * // Only select the `FrnId`
     * const frnWithFrnIdOnly = await prisma.frn.findMany({ select: { FrnId: true } })
     * 
     */
    findMany<T extends frnFindManyArgs>(args?: SelectSubset<T, frnFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$frnPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Frn.
     * @param {frnCreateArgs} args - Arguments to create a Frn.
     * @example
     * // Create one Frn
     * const Frn = await prisma.frn.create({
     *   data: {
     *     // ... data to create a Frn
     *   }
     * })
     * 
     */
    create<T extends frnCreateArgs>(args: SelectSubset<T, frnCreateArgs<ExtArgs>>): Prisma__frnClient<$Result.GetResult<Prisma.$frnPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Frns.
     * @param {frnCreateManyArgs} args - Arguments to create many Frns.
     * @example
     * // Create many Frns
     * const frn = await prisma.frn.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends frnCreateManyArgs>(args?: SelectSubset<T, frnCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Frn.
     * @param {frnDeleteArgs} args - Arguments to delete one Frn.
     * @example
     * // Delete one Frn
     * const Frn = await prisma.frn.delete({
     *   where: {
     *     // ... filter to delete one Frn
     *   }
     * })
     * 
     */
    delete<T extends frnDeleteArgs>(args: SelectSubset<T, frnDeleteArgs<ExtArgs>>): Prisma__frnClient<$Result.GetResult<Prisma.$frnPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Frn.
     * @param {frnUpdateArgs} args - Arguments to update one Frn.
     * @example
     * // Update one Frn
     * const frn = await prisma.frn.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends frnUpdateArgs>(args: SelectSubset<T, frnUpdateArgs<ExtArgs>>): Prisma__frnClient<$Result.GetResult<Prisma.$frnPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Frns.
     * @param {frnDeleteManyArgs} args - Arguments to filter Frns to delete.
     * @example
     * // Delete a few Frns
     * const { count } = await prisma.frn.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends frnDeleteManyArgs>(args?: SelectSubset<T, frnDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Frns.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {frnUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Frns
     * const frn = await prisma.frn.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends frnUpdateManyArgs>(args: SelectSubset<T, frnUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Frn.
     * @param {frnUpsertArgs} args - Arguments to update or create a Frn.
     * @example
     * // Update or create a Frn
     * const frn = await prisma.frn.upsert({
     *   create: {
     *     // ... data to create a Frn
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Frn we want to update
     *   }
     * })
     */
    upsert<T extends frnUpsertArgs>(args: SelectSubset<T, frnUpsertArgs<ExtArgs>>): Prisma__frnClient<$Result.GetResult<Prisma.$frnPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Frns.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {frnCountArgs} args - Arguments to filter Frns to count.
     * @example
     * // Count the number of Frns
     * const count = await prisma.frn.count({
     *   where: {
     *     // ... the filter for the Frns we want to count
     *   }
     * })
    **/
    count<T extends frnCountArgs>(
      args?: Subset<T, frnCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], FrnCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Frn.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {FrnAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends FrnAggregateArgs>(args: Subset<T, FrnAggregateArgs>): Prisma.PrismaPromise<GetFrnAggregateType<T>>

    /**
     * Group by Frn.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {frnGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends frnGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: frnGroupByArgs['orderBy'] }
        : { orderBy?: frnGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, frnGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetFrnGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the frn model
   */
  readonly fields: frnFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for frn.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__frnClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the frn model
   */
  interface frnFieldRefs {
    readonly FrnId: FieldRef<"frn", 'Int'>
    readonly FrnNme: FieldRef<"frn", 'String'>
    readonly FrnRdz: FieldRef<"frn", 'String'>
    readonly SttId: FieldRef<"frn", 'Int'>
    readonly UsrIdAlt: FieldRef<"frn", 'Int'>
    readonly DtaAlt: FieldRef<"frn", 'DateTime'>
    readonly MtvDel: FieldRef<"frn", 'String'>
  }
    

  // Custom InputTypes
  /**
   * frn findUnique
   */
  export type frnFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the frn
     */
    select?: frnSelect<ExtArgs> | null
    /**
     * Omit specific fields from the frn
     */
    omit?: frnOmit<ExtArgs> | null
    /**
     * Filter, which frn to fetch.
     */
    where: frnWhereUniqueInput
  }

  /**
   * frn findUniqueOrThrow
   */
  export type frnFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the frn
     */
    select?: frnSelect<ExtArgs> | null
    /**
     * Omit specific fields from the frn
     */
    omit?: frnOmit<ExtArgs> | null
    /**
     * Filter, which frn to fetch.
     */
    where: frnWhereUniqueInput
  }

  /**
   * frn findFirst
   */
  export type frnFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the frn
     */
    select?: frnSelect<ExtArgs> | null
    /**
     * Omit specific fields from the frn
     */
    omit?: frnOmit<ExtArgs> | null
    /**
     * Filter, which frn to fetch.
     */
    where?: frnWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of frns to fetch.
     */
    orderBy?: frnOrderByWithRelationInput | frnOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for frns.
     */
    cursor?: frnWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` frns from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` frns.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of frns.
     */
    distinct?: FrnScalarFieldEnum | FrnScalarFieldEnum[]
  }

  /**
   * frn findFirstOrThrow
   */
  export type frnFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the frn
     */
    select?: frnSelect<ExtArgs> | null
    /**
     * Omit specific fields from the frn
     */
    omit?: frnOmit<ExtArgs> | null
    /**
     * Filter, which frn to fetch.
     */
    where?: frnWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of frns to fetch.
     */
    orderBy?: frnOrderByWithRelationInput | frnOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for frns.
     */
    cursor?: frnWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` frns from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` frns.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of frns.
     */
    distinct?: FrnScalarFieldEnum | FrnScalarFieldEnum[]
  }

  /**
   * frn findMany
   */
  export type frnFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the frn
     */
    select?: frnSelect<ExtArgs> | null
    /**
     * Omit specific fields from the frn
     */
    omit?: frnOmit<ExtArgs> | null
    /**
     * Filter, which frns to fetch.
     */
    where?: frnWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of frns to fetch.
     */
    orderBy?: frnOrderByWithRelationInput | frnOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing frns.
     */
    cursor?: frnWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` frns from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` frns.
     */
    skip?: number
    distinct?: FrnScalarFieldEnum | FrnScalarFieldEnum[]
  }

  /**
   * frn create
   */
  export type frnCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the frn
     */
    select?: frnSelect<ExtArgs> | null
    /**
     * Omit specific fields from the frn
     */
    omit?: frnOmit<ExtArgs> | null
    /**
     * The data needed to create a frn.
     */
    data: XOR<frnCreateInput, frnUncheckedCreateInput>
  }

  /**
   * frn createMany
   */
  export type frnCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many frns.
     */
    data: frnCreateManyInput | frnCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * frn update
   */
  export type frnUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the frn
     */
    select?: frnSelect<ExtArgs> | null
    /**
     * Omit specific fields from the frn
     */
    omit?: frnOmit<ExtArgs> | null
    /**
     * The data needed to update a frn.
     */
    data: XOR<frnUpdateInput, frnUncheckedUpdateInput>
    /**
     * Choose, which frn to update.
     */
    where: frnWhereUniqueInput
  }

  /**
   * frn updateMany
   */
  export type frnUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update frns.
     */
    data: XOR<frnUpdateManyMutationInput, frnUncheckedUpdateManyInput>
    /**
     * Filter which frns to update
     */
    where?: frnWhereInput
    /**
     * Limit how many frns to update.
     */
    limit?: number
  }

  /**
   * frn upsert
   */
  export type frnUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the frn
     */
    select?: frnSelect<ExtArgs> | null
    /**
     * Omit specific fields from the frn
     */
    omit?: frnOmit<ExtArgs> | null
    /**
     * The filter to search for the frn to update in case it exists.
     */
    where: frnWhereUniqueInput
    /**
     * In case the frn found by the `where` argument doesn't exist, create a new frn with this data.
     */
    create: XOR<frnCreateInput, frnUncheckedCreateInput>
    /**
     * In case the frn was found with the provided `where` argument, update it with this data.
     */
    update: XOR<frnUpdateInput, frnUncheckedUpdateInput>
  }

  /**
   * frn delete
   */
  export type frnDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the frn
     */
    select?: frnSelect<ExtArgs> | null
    /**
     * Omit specific fields from the frn
     */
    omit?: frnOmit<ExtArgs> | null
    /**
     * Filter which frn to delete.
     */
    where: frnWhereUniqueInput
  }

  /**
   * frn deleteMany
   */
  export type frnDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which frns to delete
     */
    where?: frnWhereInput
    /**
     * Limit how many frns to delete.
     */
    limit?: number
  }

  /**
   * frn without action
   */
  export type frnDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the frn
     */
    select?: frnSelect<ExtArgs> | null
    /**
     * Omit specific fields from the frn
     */
    omit?: frnOmit<ExtArgs> | null
  }


  /**
   * Model rcg
   */

  export type AggregateRcg = {
    _count: RcgCountAggregateOutputType | null
    _avg: RcgAvgAggregateOutputType | null
    _sum: RcgSumAggregateOutputType | null
    _min: RcgMinAggregateOutputType | null
    _max: RcgMaxAggregateOutputType | null
  }

  export type RcgAvgAggregateOutputType = {
    RcgId: number | null
    RcgIdOrg: number | null
    EmpId: number | null
    UndId: number | null
    VclId: number | null
    CrrId: number | null
    CrrCnc: number | null
    SocIni: number | null
    SocFin: number | null
    RcgKwh: number | null
    OdoIni: number | null
    OdoFin: number | null
    SttRcgId: number | null
    FlhId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type RcgSumAggregateOutputType = {
    RcgId: number | null
    RcgIdOrg: number | null
    EmpId: number | null
    UndId: number | null
    VclId: number | null
    CrrId: number | null
    CrrCnc: number | null
    SocIni: number | null
    SocFin: number | null
    RcgKwh: number | null
    OdoIni: number | null
    OdoFin: number | null
    SttRcgId: number | null
    FlhId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type RcgMinAggregateOutputType = {
    RcgId: number | null
    RcgIdOrg: number | null
    EmpId: number | null
    DtaOpe: Date | null
    UndId: number | null
    VclId: number | null
    CrrId: number | null
    CrrCnc: number | null
    DtaIni: Date | null
    DtaFin: Date | null
    SocIni: number | null
    SocFin: number | null
    RcgKwh: number | null
    OdoIni: number | null
    OdoFin: number | null
    SttRcgId: number | null
    FlhId: number | null
    FlhDsc: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type RcgMaxAggregateOutputType = {
    RcgId: number | null
    RcgIdOrg: number | null
    EmpId: number | null
    DtaOpe: Date | null
    UndId: number | null
    VclId: number | null
    CrrId: number | null
    CrrCnc: number | null
    DtaIni: Date | null
    DtaFin: Date | null
    SocIni: number | null
    SocFin: number | null
    RcgKwh: number | null
    OdoIni: number | null
    OdoFin: number | null
    SttRcgId: number | null
    FlhId: number | null
    FlhDsc: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type RcgCountAggregateOutputType = {
    RcgId: number
    RcgIdOrg: number
    EmpId: number
    DtaOpe: number
    UndId: number
    VclId: number
    CrrId: number
    CrrCnc: number
    DtaIni: number
    DtaFin: number
    SocIni: number
    SocFin: number
    RcgKwh: number
    OdoIni: number
    OdoFin: number
    SttRcgId: number
    FlhId: number
    FlhDsc: number
    SttId: number
    UsrIdAlt: number
    DtaAlt: number
    MtvDel: number
    _all: number
  }


  export type RcgAvgAggregateInputType = {
    RcgId?: true
    RcgIdOrg?: true
    EmpId?: true
    UndId?: true
    VclId?: true
    CrrId?: true
    CrrCnc?: true
    SocIni?: true
    SocFin?: true
    RcgKwh?: true
    OdoIni?: true
    OdoFin?: true
    SttRcgId?: true
    FlhId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type RcgSumAggregateInputType = {
    RcgId?: true
    RcgIdOrg?: true
    EmpId?: true
    UndId?: true
    VclId?: true
    CrrId?: true
    CrrCnc?: true
    SocIni?: true
    SocFin?: true
    RcgKwh?: true
    OdoIni?: true
    OdoFin?: true
    SttRcgId?: true
    FlhId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type RcgMinAggregateInputType = {
    RcgId?: true
    RcgIdOrg?: true
    EmpId?: true
    DtaOpe?: true
    UndId?: true
    VclId?: true
    CrrId?: true
    CrrCnc?: true
    DtaIni?: true
    DtaFin?: true
    SocIni?: true
    SocFin?: true
    RcgKwh?: true
    OdoIni?: true
    OdoFin?: true
    SttRcgId?: true
    FlhId?: true
    FlhDsc?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type RcgMaxAggregateInputType = {
    RcgId?: true
    RcgIdOrg?: true
    EmpId?: true
    DtaOpe?: true
    UndId?: true
    VclId?: true
    CrrId?: true
    CrrCnc?: true
    DtaIni?: true
    DtaFin?: true
    SocIni?: true
    SocFin?: true
    RcgKwh?: true
    OdoIni?: true
    OdoFin?: true
    SttRcgId?: true
    FlhId?: true
    FlhDsc?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type RcgCountAggregateInputType = {
    RcgId?: true
    RcgIdOrg?: true
    EmpId?: true
    DtaOpe?: true
    UndId?: true
    VclId?: true
    CrrId?: true
    CrrCnc?: true
    DtaIni?: true
    DtaFin?: true
    SocIni?: true
    SocFin?: true
    RcgKwh?: true
    OdoIni?: true
    OdoFin?: true
    SttRcgId?: true
    FlhId?: true
    FlhDsc?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
    _all?: true
  }

  export type RcgAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which rcg to aggregate.
     */
    where?: rcgWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of rcgs to fetch.
     */
    orderBy?: rcgOrderByWithRelationInput | rcgOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: rcgWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` rcgs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` rcgs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned rcgs
    **/
    _count?: true | RcgCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: RcgAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: RcgSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: RcgMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: RcgMaxAggregateInputType
  }

  export type GetRcgAggregateType<T extends RcgAggregateArgs> = {
        [P in keyof T & keyof AggregateRcg]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateRcg[P]>
      : GetScalarType<T[P], AggregateRcg[P]>
  }




  export type rcgGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: rcgWhereInput
    orderBy?: rcgOrderByWithAggregationInput | rcgOrderByWithAggregationInput[]
    by: RcgScalarFieldEnum[] | RcgScalarFieldEnum
    having?: rcgScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: RcgCountAggregateInputType | true
    _avg?: RcgAvgAggregateInputType
    _sum?: RcgSumAggregateInputType
    _min?: RcgMinAggregateInputType
    _max?: RcgMaxAggregateInputType
  }

  export type RcgGroupByOutputType = {
    RcgId: number
    RcgIdOrg: number | null
    EmpId: number
    DtaOpe: Date
    UndId: number
    VclId: number
    CrrId: number | null
    CrrCnc: number | null
    DtaIni: Date
    DtaFin: Date | null
    SocIni: number | null
    SocFin: number | null
    RcgKwh: number | null
    OdoIni: number | null
    OdoFin: number | null
    SttRcgId: number
    FlhId: number
    FlhDsc: string | null
    SttId: number
    UsrIdAlt: number
    DtaAlt: Date
    MtvDel: string | null
    _count: RcgCountAggregateOutputType | null
    _avg: RcgAvgAggregateOutputType | null
    _sum: RcgSumAggregateOutputType | null
    _min: RcgMinAggregateOutputType | null
    _max: RcgMaxAggregateOutputType | null
  }

  type GetRcgGroupByPayload<T extends rcgGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<RcgGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof RcgGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], RcgGroupByOutputType[P]>
            : GetScalarType<T[P], RcgGroupByOutputType[P]>
        }
      >
    >


  export type rcgSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    RcgId?: boolean
    RcgIdOrg?: boolean
    EmpId?: boolean
    DtaOpe?: boolean
    UndId?: boolean
    VclId?: boolean
    CrrId?: boolean
    CrrCnc?: boolean
    DtaIni?: boolean
    DtaFin?: boolean
    SocIni?: boolean
    SocFin?: boolean
    RcgKwh?: boolean
    OdoIni?: boolean
    OdoFin?: boolean
    SttRcgId?: boolean
    FlhId?: boolean
    FlhDsc?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }, ExtArgs["result"]["rcg"]>



  export type rcgSelectScalar = {
    RcgId?: boolean
    RcgIdOrg?: boolean
    EmpId?: boolean
    DtaOpe?: boolean
    UndId?: boolean
    VclId?: boolean
    CrrId?: boolean
    CrrCnc?: boolean
    DtaIni?: boolean
    DtaFin?: boolean
    SocIni?: boolean
    SocFin?: boolean
    RcgKwh?: boolean
    OdoIni?: boolean
    OdoFin?: boolean
    SttRcgId?: boolean
    FlhId?: boolean
    FlhDsc?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }

  export type rcgOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"RcgId" | "RcgIdOrg" | "EmpId" | "DtaOpe" | "UndId" | "VclId" | "CrrId" | "CrrCnc" | "DtaIni" | "DtaFin" | "SocIni" | "SocFin" | "RcgKwh" | "OdoIni" | "OdoFin" | "SttRcgId" | "FlhId" | "FlhDsc" | "SttId" | "UsrIdAlt" | "DtaAlt" | "MtvDel", ExtArgs["result"]["rcg"]>

  export type $rcgPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "rcg"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      RcgId: number
      RcgIdOrg: number | null
      EmpId: number
      DtaOpe: Date
      UndId: number
      VclId: number
      CrrId: number | null
      CrrCnc: number | null
      DtaIni: Date
      DtaFin: Date | null
      SocIni: number | null
      SocFin: number | null
      RcgKwh: number | null
      OdoIni: number | null
      OdoFin: number | null
      SttRcgId: number
      FlhId: number
      FlhDsc: string | null
      SttId: number
      UsrIdAlt: number
      DtaAlt: Date
      MtvDel: string | null
    }, ExtArgs["result"]["rcg"]>
    composites: {}
  }

  type rcgGetPayload<S extends boolean | null | undefined | rcgDefaultArgs> = $Result.GetResult<Prisma.$rcgPayload, S>

  type rcgCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<rcgFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: RcgCountAggregateInputType | true
    }

  export interface rcgDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['rcg'], meta: { name: 'rcg' } }
    /**
     * Find zero or one Rcg that matches the filter.
     * @param {rcgFindUniqueArgs} args - Arguments to find a Rcg
     * @example
     * // Get one Rcg
     * const rcg = await prisma.rcg.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends rcgFindUniqueArgs>(args: SelectSubset<T, rcgFindUniqueArgs<ExtArgs>>): Prisma__rcgClient<$Result.GetResult<Prisma.$rcgPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Rcg that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {rcgFindUniqueOrThrowArgs} args - Arguments to find a Rcg
     * @example
     * // Get one Rcg
     * const rcg = await prisma.rcg.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends rcgFindUniqueOrThrowArgs>(args: SelectSubset<T, rcgFindUniqueOrThrowArgs<ExtArgs>>): Prisma__rcgClient<$Result.GetResult<Prisma.$rcgPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Rcg that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rcgFindFirstArgs} args - Arguments to find a Rcg
     * @example
     * // Get one Rcg
     * const rcg = await prisma.rcg.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends rcgFindFirstArgs>(args?: SelectSubset<T, rcgFindFirstArgs<ExtArgs>>): Prisma__rcgClient<$Result.GetResult<Prisma.$rcgPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Rcg that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rcgFindFirstOrThrowArgs} args - Arguments to find a Rcg
     * @example
     * // Get one Rcg
     * const rcg = await prisma.rcg.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends rcgFindFirstOrThrowArgs>(args?: SelectSubset<T, rcgFindFirstOrThrowArgs<ExtArgs>>): Prisma__rcgClient<$Result.GetResult<Prisma.$rcgPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Rcgs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rcgFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Rcgs
     * const rcgs = await prisma.rcg.findMany()
     * 
     * // Get first 10 Rcgs
     * const rcgs = await prisma.rcg.findMany({ take: 10 })
     * 
     * // Only select the `RcgId`
     * const rcgWithRcgIdOnly = await prisma.rcg.findMany({ select: { RcgId: true } })
     * 
     */
    findMany<T extends rcgFindManyArgs>(args?: SelectSubset<T, rcgFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$rcgPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Rcg.
     * @param {rcgCreateArgs} args - Arguments to create a Rcg.
     * @example
     * // Create one Rcg
     * const Rcg = await prisma.rcg.create({
     *   data: {
     *     // ... data to create a Rcg
     *   }
     * })
     * 
     */
    create<T extends rcgCreateArgs>(args: SelectSubset<T, rcgCreateArgs<ExtArgs>>): Prisma__rcgClient<$Result.GetResult<Prisma.$rcgPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Rcgs.
     * @param {rcgCreateManyArgs} args - Arguments to create many Rcgs.
     * @example
     * // Create many Rcgs
     * const rcg = await prisma.rcg.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends rcgCreateManyArgs>(args?: SelectSubset<T, rcgCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Rcg.
     * @param {rcgDeleteArgs} args - Arguments to delete one Rcg.
     * @example
     * // Delete one Rcg
     * const Rcg = await prisma.rcg.delete({
     *   where: {
     *     // ... filter to delete one Rcg
     *   }
     * })
     * 
     */
    delete<T extends rcgDeleteArgs>(args: SelectSubset<T, rcgDeleteArgs<ExtArgs>>): Prisma__rcgClient<$Result.GetResult<Prisma.$rcgPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Rcg.
     * @param {rcgUpdateArgs} args - Arguments to update one Rcg.
     * @example
     * // Update one Rcg
     * const rcg = await prisma.rcg.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends rcgUpdateArgs>(args: SelectSubset<T, rcgUpdateArgs<ExtArgs>>): Prisma__rcgClient<$Result.GetResult<Prisma.$rcgPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Rcgs.
     * @param {rcgDeleteManyArgs} args - Arguments to filter Rcgs to delete.
     * @example
     * // Delete a few Rcgs
     * const { count } = await prisma.rcg.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends rcgDeleteManyArgs>(args?: SelectSubset<T, rcgDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Rcgs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rcgUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Rcgs
     * const rcg = await prisma.rcg.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends rcgUpdateManyArgs>(args: SelectSubset<T, rcgUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Rcg.
     * @param {rcgUpsertArgs} args - Arguments to update or create a Rcg.
     * @example
     * // Update or create a Rcg
     * const rcg = await prisma.rcg.upsert({
     *   create: {
     *     // ... data to create a Rcg
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Rcg we want to update
     *   }
     * })
     */
    upsert<T extends rcgUpsertArgs>(args: SelectSubset<T, rcgUpsertArgs<ExtArgs>>): Prisma__rcgClient<$Result.GetResult<Prisma.$rcgPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Rcgs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rcgCountArgs} args - Arguments to filter Rcgs to count.
     * @example
     * // Count the number of Rcgs
     * const count = await prisma.rcg.count({
     *   where: {
     *     // ... the filter for the Rcgs we want to count
     *   }
     * })
    **/
    count<T extends rcgCountArgs>(
      args?: Subset<T, rcgCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], RcgCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Rcg.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RcgAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends RcgAggregateArgs>(args: Subset<T, RcgAggregateArgs>): Prisma.PrismaPromise<GetRcgAggregateType<T>>

    /**
     * Group by Rcg.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {rcgGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends rcgGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: rcgGroupByArgs['orderBy'] }
        : { orderBy?: rcgGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, rcgGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetRcgGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the rcg model
   */
  readonly fields: rcgFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for rcg.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__rcgClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the rcg model
   */
  interface rcgFieldRefs {
    readonly RcgId: FieldRef<"rcg", 'Int'>
    readonly RcgIdOrg: FieldRef<"rcg", 'Int'>
    readonly EmpId: FieldRef<"rcg", 'Int'>
    readonly DtaOpe: FieldRef<"rcg", 'DateTime'>
    readonly UndId: FieldRef<"rcg", 'Int'>
    readonly VclId: FieldRef<"rcg", 'Int'>
    readonly CrrId: FieldRef<"rcg", 'Int'>
    readonly CrrCnc: FieldRef<"rcg", 'Int'>
    readonly DtaIni: FieldRef<"rcg", 'DateTime'>
    readonly DtaFin: FieldRef<"rcg", 'DateTime'>
    readonly SocIni: FieldRef<"rcg", 'Int'>
    readonly SocFin: FieldRef<"rcg", 'Int'>
    readonly RcgKwh: FieldRef<"rcg", 'Float'>
    readonly OdoIni: FieldRef<"rcg", 'Float'>
    readonly OdoFin: FieldRef<"rcg", 'Float'>
    readonly SttRcgId: FieldRef<"rcg", 'Int'>
    readonly FlhId: FieldRef<"rcg", 'Int'>
    readonly FlhDsc: FieldRef<"rcg", 'String'>
    readonly SttId: FieldRef<"rcg", 'Int'>
    readonly UsrIdAlt: FieldRef<"rcg", 'Int'>
    readonly DtaAlt: FieldRef<"rcg", 'DateTime'>
    readonly MtvDel: FieldRef<"rcg", 'String'>
  }
    

  // Custom InputTypes
  /**
   * rcg findUnique
   */
  export type rcgFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rcg
     */
    select?: rcgSelect<ExtArgs> | null
    /**
     * Omit specific fields from the rcg
     */
    omit?: rcgOmit<ExtArgs> | null
    /**
     * Filter, which rcg to fetch.
     */
    where: rcgWhereUniqueInput
  }

  /**
   * rcg findUniqueOrThrow
   */
  export type rcgFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rcg
     */
    select?: rcgSelect<ExtArgs> | null
    /**
     * Omit specific fields from the rcg
     */
    omit?: rcgOmit<ExtArgs> | null
    /**
     * Filter, which rcg to fetch.
     */
    where: rcgWhereUniqueInput
  }

  /**
   * rcg findFirst
   */
  export type rcgFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rcg
     */
    select?: rcgSelect<ExtArgs> | null
    /**
     * Omit specific fields from the rcg
     */
    omit?: rcgOmit<ExtArgs> | null
    /**
     * Filter, which rcg to fetch.
     */
    where?: rcgWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of rcgs to fetch.
     */
    orderBy?: rcgOrderByWithRelationInput | rcgOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for rcgs.
     */
    cursor?: rcgWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` rcgs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` rcgs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of rcgs.
     */
    distinct?: RcgScalarFieldEnum | RcgScalarFieldEnum[]
  }

  /**
   * rcg findFirstOrThrow
   */
  export type rcgFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rcg
     */
    select?: rcgSelect<ExtArgs> | null
    /**
     * Omit specific fields from the rcg
     */
    omit?: rcgOmit<ExtArgs> | null
    /**
     * Filter, which rcg to fetch.
     */
    where?: rcgWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of rcgs to fetch.
     */
    orderBy?: rcgOrderByWithRelationInput | rcgOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for rcgs.
     */
    cursor?: rcgWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` rcgs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` rcgs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of rcgs.
     */
    distinct?: RcgScalarFieldEnum | RcgScalarFieldEnum[]
  }

  /**
   * rcg findMany
   */
  export type rcgFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rcg
     */
    select?: rcgSelect<ExtArgs> | null
    /**
     * Omit specific fields from the rcg
     */
    omit?: rcgOmit<ExtArgs> | null
    /**
     * Filter, which rcgs to fetch.
     */
    where?: rcgWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of rcgs to fetch.
     */
    orderBy?: rcgOrderByWithRelationInput | rcgOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing rcgs.
     */
    cursor?: rcgWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` rcgs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` rcgs.
     */
    skip?: number
    distinct?: RcgScalarFieldEnum | RcgScalarFieldEnum[]
  }

  /**
   * rcg create
   */
  export type rcgCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rcg
     */
    select?: rcgSelect<ExtArgs> | null
    /**
     * Omit specific fields from the rcg
     */
    omit?: rcgOmit<ExtArgs> | null
    /**
     * The data needed to create a rcg.
     */
    data: XOR<rcgCreateInput, rcgUncheckedCreateInput>
  }

  /**
   * rcg createMany
   */
  export type rcgCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many rcgs.
     */
    data: rcgCreateManyInput | rcgCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * rcg update
   */
  export type rcgUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rcg
     */
    select?: rcgSelect<ExtArgs> | null
    /**
     * Omit specific fields from the rcg
     */
    omit?: rcgOmit<ExtArgs> | null
    /**
     * The data needed to update a rcg.
     */
    data: XOR<rcgUpdateInput, rcgUncheckedUpdateInput>
    /**
     * Choose, which rcg to update.
     */
    where: rcgWhereUniqueInput
  }

  /**
   * rcg updateMany
   */
  export type rcgUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update rcgs.
     */
    data: XOR<rcgUpdateManyMutationInput, rcgUncheckedUpdateManyInput>
    /**
     * Filter which rcgs to update
     */
    where?: rcgWhereInput
    /**
     * Limit how many rcgs to update.
     */
    limit?: number
  }

  /**
   * rcg upsert
   */
  export type rcgUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rcg
     */
    select?: rcgSelect<ExtArgs> | null
    /**
     * Omit specific fields from the rcg
     */
    omit?: rcgOmit<ExtArgs> | null
    /**
     * The filter to search for the rcg to update in case it exists.
     */
    where: rcgWhereUniqueInput
    /**
     * In case the rcg found by the `where` argument doesn't exist, create a new rcg with this data.
     */
    create: XOR<rcgCreateInput, rcgUncheckedCreateInput>
    /**
     * In case the rcg was found with the provided `where` argument, update it with this data.
     */
    update: XOR<rcgUpdateInput, rcgUncheckedUpdateInput>
  }

  /**
   * rcg delete
   */
  export type rcgDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rcg
     */
    select?: rcgSelect<ExtArgs> | null
    /**
     * Omit specific fields from the rcg
     */
    omit?: rcgOmit<ExtArgs> | null
    /**
     * Filter which rcg to delete.
     */
    where: rcgWhereUniqueInput
  }

  /**
   * rcg deleteMany
   */
  export type rcgDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which rcgs to delete
     */
    where?: rcgWhereInput
    /**
     * Limit how many rcgs to delete.
     */
    limit?: number
  }

  /**
   * rcg without action
   */
  export type rcgDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the rcg
     */
    select?: rcgSelect<ExtArgs> | null
    /**
     * Omit specific fields from the rcg
     */
    omit?: rcgOmit<ExtArgs> | null
  }


  /**
   * Model stt
   */

  export type AggregateStt = {
    _count: SttCountAggregateOutputType | null
    _avg: SttAvgAggregateOutputType | null
    _sum: SttSumAggregateOutputType | null
    _min: SttMinAggregateOutputType | null
    _max: SttMaxAggregateOutputType | null
  }

  export type SttAvgAggregateOutputType = {
    SttId: number | null
    SttIdAtu: number | null
    UsrIdAlt: number | null
  }

  export type SttSumAggregateOutputType = {
    SttId: number | null
    SttIdAtu: number | null
    UsrIdAlt: number | null
  }

  export type SttMinAggregateOutputType = {
    SttId: number | null
    SttNme: string | null
    SttIdAtu: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type SttMaxAggregateOutputType = {
    SttId: number | null
    SttNme: string | null
    SttIdAtu: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type SttCountAggregateOutputType = {
    SttId: number
    SttNme: number
    SttIdAtu: number
    UsrIdAlt: number
    DtaAlt: number
    MtvDel: number
    _all: number
  }


  export type SttAvgAggregateInputType = {
    SttId?: true
    SttIdAtu?: true
    UsrIdAlt?: true
  }

  export type SttSumAggregateInputType = {
    SttId?: true
    SttIdAtu?: true
    UsrIdAlt?: true
  }

  export type SttMinAggregateInputType = {
    SttId?: true
    SttNme?: true
    SttIdAtu?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type SttMaxAggregateInputType = {
    SttId?: true
    SttNme?: true
    SttIdAtu?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type SttCountAggregateInputType = {
    SttId?: true
    SttNme?: true
    SttIdAtu?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
    _all?: true
  }

  export type SttAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which stt to aggregate.
     */
    where?: sttWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of stts to fetch.
     */
    orderBy?: sttOrderByWithRelationInput | sttOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: sttWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` stts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` stts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned stts
    **/
    _count?: true | SttCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: SttAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: SttSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SttMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SttMaxAggregateInputType
  }

  export type GetSttAggregateType<T extends SttAggregateArgs> = {
        [P in keyof T & keyof AggregateStt]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateStt[P]>
      : GetScalarType<T[P], AggregateStt[P]>
  }




  export type sttGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: sttWhereInput
    orderBy?: sttOrderByWithAggregationInput | sttOrderByWithAggregationInput[]
    by: SttScalarFieldEnum[] | SttScalarFieldEnum
    having?: sttScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SttCountAggregateInputType | true
    _avg?: SttAvgAggregateInputType
    _sum?: SttSumAggregateInputType
    _min?: SttMinAggregateInputType
    _max?: SttMaxAggregateInputType
  }

  export type SttGroupByOutputType = {
    SttId: number
    SttNme: string
    SttIdAtu: number
    UsrIdAlt: number
    DtaAlt: Date
    MtvDel: string | null
    _count: SttCountAggregateOutputType | null
    _avg: SttAvgAggregateOutputType | null
    _sum: SttSumAggregateOutputType | null
    _min: SttMinAggregateOutputType | null
    _max: SttMaxAggregateOutputType | null
  }

  type GetSttGroupByPayload<T extends sttGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SttGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SttGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SttGroupByOutputType[P]>
            : GetScalarType<T[P], SttGroupByOutputType[P]>
        }
      >
    >


  export type sttSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    SttId?: boolean
    SttNme?: boolean
    SttIdAtu?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }, ExtArgs["result"]["stt"]>



  export type sttSelectScalar = {
    SttId?: boolean
    SttNme?: boolean
    SttIdAtu?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }

  export type sttOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"SttId" | "SttNme" | "SttIdAtu" | "UsrIdAlt" | "DtaAlt" | "MtvDel", ExtArgs["result"]["stt"]>

  export type $sttPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "stt"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      SttId: number
      SttNme: string
      SttIdAtu: number
      UsrIdAlt: number
      DtaAlt: Date
      MtvDel: string | null
    }, ExtArgs["result"]["stt"]>
    composites: {}
  }

  type sttGetPayload<S extends boolean | null | undefined | sttDefaultArgs> = $Result.GetResult<Prisma.$sttPayload, S>

  type sttCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<sttFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SttCountAggregateInputType | true
    }

  export interface sttDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['stt'], meta: { name: 'stt' } }
    /**
     * Find zero or one Stt that matches the filter.
     * @param {sttFindUniqueArgs} args - Arguments to find a Stt
     * @example
     * // Get one Stt
     * const stt = await prisma.stt.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends sttFindUniqueArgs>(args: SelectSubset<T, sttFindUniqueArgs<ExtArgs>>): Prisma__sttClient<$Result.GetResult<Prisma.$sttPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Stt that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {sttFindUniqueOrThrowArgs} args - Arguments to find a Stt
     * @example
     * // Get one Stt
     * const stt = await prisma.stt.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends sttFindUniqueOrThrowArgs>(args: SelectSubset<T, sttFindUniqueOrThrowArgs<ExtArgs>>): Prisma__sttClient<$Result.GetResult<Prisma.$sttPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Stt that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {sttFindFirstArgs} args - Arguments to find a Stt
     * @example
     * // Get one Stt
     * const stt = await prisma.stt.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends sttFindFirstArgs>(args?: SelectSubset<T, sttFindFirstArgs<ExtArgs>>): Prisma__sttClient<$Result.GetResult<Prisma.$sttPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Stt that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {sttFindFirstOrThrowArgs} args - Arguments to find a Stt
     * @example
     * // Get one Stt
     * const stt = await prisma.stt.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends sttFindFirstOrThrowArgs>(args?: SelectSubset<T, sttFindFirstOrThrowArgs<ExtArgs>>): Prisma__sttClient<$Result.GetResult<Prisma.$sttPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Stts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {sttFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Stts
     * const stts = await prisma.stt.findMany()
     * 
     * // Get first 10 Stts
     * const stts = await prisma.stt.findMany({ take: 10 })
     * 
     * // Only select the `SttId`
     * const sttWithSttIdOnly = await prisma.stt.findMany({ select: { SttId: true } })
     * 
     */
    findMany<T extends sttFindManyArgs>(args?: SelectSubset<T, sttFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$sttPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Stt.
     * @param {sttCreateArgs} args - Arguments to create a Stt.
     * @example
     * // Create one Stt
     * const Stt = await prisma.stt.create({
     *   data: {
     *     // ... data to create a Stt
     *   }
     * })
     * 
     */
    create<T extends sttCreateArgs>(args: SelectSubset<T, sttCreateArgs<ExtArgs>>): Prisma__sttClient<$Result.GetResult<Prisma.$sttPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Stts.
     * @param {sttCreateManyArgs} args - Arguments to create many Stts.
     * @example
     * // Create many Stts
     * const stt = await prisma.stt.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends sttCreateManyArgs>(args?: SelectSubset<T, sttCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Stt.
     * @param {sttDeleteArgs} args - Arguments to delete one Stt.
     * @example
     * // Delete one Stt
     * const Stt = await prisma.stt.delete({
     *   where: {
     *     // ... filter to delete one Stt
     *   }
     * })
     * 
     */
    delete<T extends sttDeleteArgs>(args: SelectSubset<T, sttDeleteArgs<ExtArgs>>): Prisma__sttClient<$Result.GetResult<Prisma.$sttPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Stt.
     * @param {sttUpdateArgs} args - Arguments to update one Stt.
     * @example
     * // Update one Stt
     * const stt = await prisma.stt.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends sttUpdateArgs>(args: SelectSubset<T, sttUpdateArgs<ExtArgs>>): Prisma__sttClient<$Result.GetResult<Prisma.$sttPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Stts.
     * @param {sttDeleteManyArgs} args - Arguments to filter Stts to delete.
     * @example
     * // Delete a few Stts
     * const { count } = await prisma.stt.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends sttDeleteManyArgs>(args?: SelectSubset<T, sttDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Stts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {sttUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Stts
     * const stt = await prisma.stt.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends sttUpdateManyArgs>(args: SelectSubset<T, sttUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Stt.
     * @param {sttUpsertArgs} args - Arguments to update or create a Stt.
     * @example
     * // Update or create a Stt
     * const stt = await prisma.stt.upsert({
     *   create: {
     *     // ... data to create a Stt
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Stt we want to update
     *   }
     * })
     */
    upsert<T extends sttUpsertArgs>(args: SelectSubset<T, sttUpsertArgs<ExtArgs>>): Prisma__sttClient<$Result.GetResult<Prisma.$sttPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Stts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {sttCountArgs} args - Arguments to filter Stts to count.
     * @example
     * // Count the number of Stts
     * const count = await prisma.stt.count({
     *   where: {
     *     // ... the filter for the Stts we want to count
     *   }
     * })
    **/
    count<T extends sttCountArgs>(
      args?: Subset<T, sttCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SttCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Stt.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SttAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SttAggregateArgs>(args: Subset<T, SttAggregateArgs>): Prisma.PrismaPromise<GetSttAggregateType<T>>

    /**
     * Group by Stt.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {sttGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends sttGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: sttGroupByArgs['orderBy'] }
        : { orderBy?: sttGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, sttGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSttGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the stt model
   */
  readonly fields: sttFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for stt.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__sttClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the stt model
   */
  interface sttFieldRefs {
    readonly SttId: FieldRef<"stt", 'Int'>
    readonly SttNme: FieldRef<"stt", 'String'>
    readonly SttIdAtu: FieldRef<"stt", 'Int'>
    readonly UsrIdAlt: FieldRef<"stt", 'Int'>
    readonly DtaAlt: FieldRef<"stt", 'DateTime'>
    readonly MtvDel: FieldRef<"stt", 'String'>
  }
    

  // Custom InputTypes
  /**
   * stt findUnique
   */
  export type sttFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the stt
     */
    select?: sttSelect<ExtArgs> | null
    /**
     * Omit specific fields from the stt
     */
    omit?: sttOmit<ExtArgs> | null
    /**
     * Filter, which stt to fetch.
     */
    where: sttWhereUniqueInput
  }

  /**
   * stt findUniqueOrThrow
   */
  export type sttFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the stt
     */
    select?: sttSelect<ExtArgs> | null
    /**
     * Omit specific fields from the stt
     */
    omit?: sttOmit<ExtArgs> | null
    /**
     * Filter, which stt to fetch.
     */
    where: sttWhereUniqueInput
  }

  /**
   * stt findFirst
   */
  export type sttFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the stt
     */
    select?: sttSelect<ExtArgs> | null
    /**
     * Omit specific fields from the stt
     */
    omit?: sttOmit<ExtArgs> | null
    /**
     * Filter, which stt to fetch.
     */
    where?: sttWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of stts to fetch.
     */
    orderBy?: sttOrderByWithRelationInput | sttOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for stts.
     */
    cursor?: sttWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` stts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` stts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of stts.
     */
    distinct?: SttScalarFieldEnum | SttScalarFieldEnum[]
  }

  /**
   * stt findFirstOrThrow
   */
  export type sttFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the stt
     */
    select?: sttSelect<ExtArgs> | null
    /**
     * Omit specific fields from the stt
     */
    omit?: sttOmit<ExtArgs> | null
    /**
     * Filter, which stt to fetch.
     */
    where?: sttWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of stts to fetch.
     */
    orderBy?: sttOrderByWithRelationInput | sttOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for stts.
     */
    cursor?: sttWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` stts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` stts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of stts.
     */
    distinct?: SttScalarFieldEnum | SttScalarFieldEnum[]
  }

  /**
   * stt findMany
   */
  export type sttFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the stt
     */
    select?: sttSelect<ExtArgs> | null
    /**
     * Omit specific fields from the stt
     */
    omit?: sttOmit<ExtArgs> | null
    /**
     * Filter, which stts to fetch.
     */
    where?: sttWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of stts to fetch.
     */
    orderBy?: sttOrderByWithRelationInput | sttOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing stts.
     */
    cursor?: sttWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` stts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` stts.
     */
    skip?: number
    distinct?: SttScalarFieldEnum | SttScalarFieldEnum[]
  }

  /**
   * stt create
   */
  export type sttCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the stt
     */
    select?: sttSelect<ExtArgs> | null
    /**
     * Omit specific fields from the stt
     */
    omit?: sttOmit<ExtArgs> | null
    /**
     * The data needed to create a stt.
     */
    data: XOR<sttCreateInput, sttUncheckedCreateInput>
  }

  /**
   * stt createMany
   */
  export type sttCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many stts.
     */
    data: sttCreateManyInput | sttCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * stt update
   */
  export type sttUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the stt
     */
    select?: sttSelect<ExtArgs> | null
    /**
     * Omit specific fields from the stt
     */
    omit?: sttOmit<ExtArgs> | null
    /**
     * The data needed to update a stt.
     */
    data: XOR<sttUpdateInput, sttUncheckedUpdateInput>
    /**
     * Choose, which stt to update.
     */
    where: sttWhereUniqueInput
  }

  /**
   * stt updateMany
   */
  export type sttUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update stts.
     */
    data: XOR<sttUpdateManyMutationInput, sttUncheckedUpdateManyInput>
    /**
     * Filter which stts to update
     */
    where?: sttWhereInput
    /**
     * Limit how many stts to update.
     */
    limit?: number
  }

  /**
   * stt upsert
   */
  export type sttUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the stt
     */
    select?: sttSelect<ExtArgs> | null
    /**
     * Omit specific fields from the stt
     */
    omit?: sttOmit<ExtArgs> | null
    /**
     * The filter to search for the stt to update in case it exists.
     */
    where: sttWhereUniqueInput
    /**
     * In case the stt found by the `where` argument doesn't exist, create a new stt with this data.
     */
    create: XOR<sttCreateInput, sttUncheckedCreateInput>
    /**
     * In case the stt was found with the provided `where` argument, update it with this data.
     */
    update: XOR<sttUpdateInput, sttUncheckedUpdateInput>
  }

  /**
   * stt delete
   */
  export type sttDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the stt
     */
    select?: sttSelect<ExtArgs> | null
    /**
     * Omit specific fields from the stt
     */
    omit?: sttOmit<ExtArgs> | null
    /**
     * Filter which stt to delete.
     */
    where: sttWhereUniqueInput
  }

  /**
   * stt deleteMany
   */
  export type sttDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which stts to delete
     */
    where?: sttWhereInput
    /**
     * Limit how many stts to delete.
     */
    limit?: number
  }

  /**
   * stt without action
   */
  export type sttDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the stt
     */
    select?: sttSelect<ExtArgs> | null
    /**
     * Omit specific fields from the stt
     */
    omit?: sttOmit<ExtArgs> | null
  }


  /**
   * Model usr
   */

  export type AggregateUsr = {
    _count: UsrCountAggregateOutputType | null
    _avg: UsrAvgAggregateOutputType | null
    _sum: UsrSumAggregateOutputType | null
    _min: UsrMinAggregateOutputType | null
    _max: UsrMaxAggregateOutputType | null
  }

  export type UsrAvgAggregateOutputType = {
    EmpId: number | null
    UsrTpoId: number | null
    UsrId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type UsrSumAggregateOutputType = {
    EmpId: number | null
    UsrTpoId: number | null
    UsrId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type UsrMinAggregateOutputType = {
    EmpId: number | null
    UsrTpoId: number | null
    UsrId: number | null
    UsrNme: string | null
    UsrLgn: string | null
    UsrCpf: string | null
    UsrEml: string | null
    UsrPwd: string | null
    UsrFto: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type UsrMaxAggregateOutputType = {
    EmpId: number | null
    UsrTpoId: number | null
    UsrId: number | null
    UsrNme: string | null
    UsrLgn: string | null
    UsrCpf: string | null
    UsrEml: string | null
    UsrPwd: string | null
    UsrFto: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type UsrCountAggregateOutputType = {
    EmpId: number
    UsrTpoId: number
    UsrId: number
    UsrNme: number
    UsrLgn: number
    UsrCpf: number
    UsrEml: number
    UsrPwd: number
    UsrFto: number
    SttId: number
    UsrIdAlt: number
    DtaAlt: number
    MtvDel: number
    _all: number
  }


  export type UsrAvgAggregateInputType = {
    EmpId?: true
    UsrTpoId?: true
    UsrId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type UsrSumAggregateInputType = {
    EmpId?: true
    UsrTpoId?: true
    UsrId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type UsrMinAggregateInputType = {
    EmpId?: true
    UsrTpoId?: true
    UsrId?: true
    UsrNme?: true
    UsrLgn?: true
    UsrCpf?: true
    UsrEml?: true
    UsrPwd?: true
    UsrFto?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type UsrMaxAggregateInputType = {
    EmpId?: true
    UsrTpoId?: true
    UsrId?: true
    UsrNme?: true
    UsrLgn?: true
    UsrCpf?: true
    UsrEml?: true
    UsrPwd?: true
    UsrFto?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type UsrCountAggregateInputType = {
    EmpId?: true
    UsrTpoId?: true
    UsrId?: true
    UsrNme?: true
    UsrLgn?: true
    UsrCpf?: true
    UsrEml?: true
    UsrPwd?: true
    UsrFto?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
    _all?: true
  }

  export type UsrAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which usr to aggregate.
     */
    where?: usrWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usrs to fetch.
     */
    orderBy?: usrOrderByWithRelationInput | usrOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: usrWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usrs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usrs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned usrs
    **/
    _count?: true | UsrCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: UsrAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: UsrSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UsrMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UsrMaxAggregateInputType
  }

  export type GetUsrAggregateType<T extends UsrAggregateArgs> = {
        [P in keyof T & keyof AggregateUsr]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUsr[P]>
      : GetScalarType<T[P], AggregateUsr[P]>
  }




  export type usrGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: usrWhereInput
    orderBy?: usrOrderByWithAggregationInput | usrOrderByWithAggregationInput[]
    by: UsrScalarFieldEnum[] | UsrScalarFieldEnum
    having?: usrScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UsrCountAggregateInputType | true
    _avg?: UsrAvgAggregateInputType
    _sum?: UsrSumAggregateInputType
    _min?: UsrMinAggregateInputType
    _max?: UsrMaxAggregateInputType
  }

  export type UsrGroupByOutputType = {
    EmpId: number
    UsrTpoId: number
    UsrId: number
    UsrNme: string
    UsrLgn: string | null
    UsrCpf: string | null
    UsrEml: string
    UsrPwd: string
    UsrFto: string | null
    SttId: number
    UsrIdAlt: number
    DtaAlt: Date
    MtvDel: string | null
    _count: UsrCountAggregateOutputType | null
    _avg: UsrAvgAggregateOutputType | null
    _sum: UsrSumAggregateOutputType | null
    _min: UsrMinAggregateOutputType | null
    _max: UsrMaxAggregateOutputType | null
  }

  type GetUsrGroupByPayload<T extends usrGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UsrGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UsrGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UsrGroupByOutputType[P]>
            : GetScalarType<T[P], UsrGroupByOutputType[P]>
        }
      >
    >


  export type usrSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    EmpId?: boolean
    UsrTpoId?: boolean
    UsrId?: boolean
    UsrNme?: boolean
    UsrLgn?: boolean
    UsrCpf?: boolean
    UsrEml?: boolean
    UsrPwd?: boolean
    UsrFto?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }, ExtArgs["result"]["usr"]>



  export type usrSelectScalar = {
    EmpId?: boolean
    UsrTpoId?: boolean
    UsrId?: boolean
    UsrNme?: boolean
    UsrLgn?: boolean
    UsrCpf?: boolean
    UsrEml?: boolean
    UsrPwd?: boolean
    UsrFto?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }

  export type usrOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"EmpId" | "UsrTpoId" | "UsrId" | "UsrNme" | "UsrLgn" | "UsrCpf" | "UsrEml" | "UsrPwd" | "UsrFto" | "SttId" | "UsrIdAlt" | "DtaAlt" | "MtvDel", ExtArgs["result"]["usr"]>

  export type $usrPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "usr"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      EmpId: number
      UsrTpoId: number
      UsrId: number
      UsrNme: string
      UsrLgn: string | null
      UsrCpf: string | null
      UsrEml: string
      UsrPwd: string
      UsrFto: string | null
      SttId: number
      UsrIdAlt: number
      DtaAlt: Date
      MtvDel: string | null
    }, ExtArgs["result"]["usr"]>
    composites: {}
  }

  type usrGetPayload<S extends boolean | null | undefined | usrDefaultArgs> = $Result.GetResult<Prisma.$usrPayload, S>

  type usrCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<usrFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UsrCountAggregateInputType | true
    }

  export interface usrDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['usr'], meta: { name: 'usr' } }
    /**
     * Find zero or one Usr that matches the filter.
     * @param {usrFindUniqueArgs} args - Arguments to find a Usr
     * @example
     * // Get one Usr
     * const usr = await prisma.usr.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends usrFindUniqueArgs>(args: SelectSubset<T, usrFindUniqueArgs<ExtArgs>>): Prisma__usrClient<$Result.GetResult<Prisma.$usrPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Usr that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {usrFindUniqueOrThrowArgs} args - Arguments to find a Usr
     * @example
     * // Get one Usr
     * const usr = await prisma.usr.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends usrFindUniqueOrThrowArgs>(args: SelectSubset<T, usrFindUniqueOrThrowArgs<ExtArgs>>): Prisma__usrClient<$Result.GetResult<Prisma.$usrPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Usr that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usrFindFirstArgs} args - Arguments to find a Usr
     * @example
     * // Get one Usr
     * const usr = await prisma.usr.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends usrFindFirstArgs>(args?: SelectSubset<T, usrFindFirstArgs<ExtArgs>>): Prisma__usrClient<$Result.GetResult<Prisma.$usrPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Usr that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usrFindFirstOrThrowArgs} args - Arguments to find a Usr
     * @example
     * // Get one Usr
     * const usr = await prisma.usr.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends usrFindFirstOrThrowArgs>(args?: SelectSubset<T, usrFindFirstOrThrowArgs<ExtArgs>>): Prisma__usrClient<$Result.GetResult<Prisma.$usrPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Usrs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usrFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Usrs
     * const usrs = await prisma.usr.findMany()
     * 
     * // Get first 10 Usrs
     * const usrs = await prisma.usr.findMany({ take: 10 })
     * 
     * // Only select the `EmpId`
     * const usrWithEmpIdOnly = await prisma.usr.findMany({ select: { EmpId: true } })
     * 
     */
    findMany<T extends usrFindManyArgs>(args?: SelectSubset<T, usrFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usrPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Usr.
     * @param {usrCreateArgs} args - Arguments to create a Usr.
     * @example
     * // Create one Usr
     * const Usr = await prisma.usr.create({
     *   data: {
     *     // ... data to create a Usr
     *   }
     * })
     * 
     */
    create<T extends usrCreateArgs>(args: SelectSubset<T, usrCreateArgs<ExtArgs>>): Prisma__usrClient<$Result.GetResult<Prisma.$usrPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Usrs.
     * @param {usrCreateManyArgs} args - Arguments to create many Usrs.
     * @example
     * // Create many Usrs
     * const usr = await prisma.usr.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends usrCreateManyArgs>(args?: SelectSubset<T, usrCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Usr.
     * @param {usrDeleteArgs} args - Arguments to delete one Usr.
     * @example
     * // Delete one Usr
     * const Usr = await prisma.usr.delete({
     *   where: {
     *     // ... filter to delete one Usr
     *   }
     * })
     * 
     */
    delete<T extends usrDeleteArgs>(args: SelectSubset<T, usrDeleteArgs<ExtArgs>>): Prisma__usrClient<$Result.GetResult<Prisma.$usrPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Usr.
     * @param {usrUpdateArgs} args - Arguments to update one Usr.
     * @example
     * // Update one Usr
     * const usr = await prisma.usr.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends usrUpdateArgs>(args: SelectSubset<T, usrUpdateArgs<ExtArgs>>): Prisma__usrClient<$Result.GetResult<Prisma.$usrPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Usrs.
     * @param {usrDeleteManyArgs} args - Arguments to filter Usrs to delete.
     * @example
     * // Delete a few Usrs
     * const { count } = await prisma.usr.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends usrDeleteManyArgs>(args?: SelectSubset<T, usrDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Usrs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usrUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Usrs
     * const usr = await prisma.usr.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends usrUpdateManyArgs>(args: SelectSubset<T, usrUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Usr.
     * @param {usrUpsertArgs} args - Arguments to update or create a Usr.
     * @example
     * // Update or create a Usr
     * const usr = await prisma.usr.upsert({
     *   create: {
     *     // ... data to create a Usr
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Usr we want to update
     *   }
     * })
     */
    upsert<T extends usrUpsertArgs>(args: SelectSubset<T, usrUpsertArgs<ExtArgs>>): Prisma__usrClient<$Result.GetResult<Prisma.$usrPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Usrs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usrCountArgs} args - Arguments to filter Usrs to count.
     * @example
     * // Count the number of Usrs
     * const count = await prisma.usr.count({
     *   where: {
     *     // ... the filter for the Usrs we want to count
     *   }
     * })
    **/
    count<T extends usrCountArgs>(
      args?: Subset<T, usrCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UsrCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Usr.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UsrAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UsrAggregateArgs>(args: Subset<T, UsrAggregateArgs>): Prisma.PrismaPromise<GetUsrAggregateType<T>>

    /**
     * Group by Usr.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usrGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends usrGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: usrGroupByArgs['orderBy'] }
        : { orderBy?: usrGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, usrGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUsrGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the usr model
   */
  readonly fields: usrFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for usr.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__usrClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the usr model
   */
  interface usrFieldRefs {
    readonly EmpId: FieldRef<"usr", 'Int'>
    readonly UsrTpoId: FieldRef<"usr", 'Int'>
    readonly UsrId: FieldRef<"usr", 'Int'>
    readonly UsrNme: FieldRef<"usr", 'String'>
    readonly UsrLgn: FieldRef<"usr", 'String'>
    readonly UsrCpf: FieldRef<"usr", 'String'>
    readonly UsrEml: FieldRef<"usr", 'String'>
    readonly UsrPwd: FieldRef<"usr", 'String'>
    readonly UsrFto: FieldRef<"usr", 'String'>
    readonly SttId: FieldRef<"usr", 'Int'>
    readonly UsrIdAlt: FieldRef<"usr", 'Int'>
    readonly DtaAlt: FieldRef<"usr", 'DateTime'>
    readonly MtvDel: FieldRef<"usr", 'String'>
  }
    

  // Custom InputTypes
  /**
   * usr findUnique
   */
  export type usrFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr
     */
    select?: usrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr
     */
    omit?: usrOmit<ExtArgs> | null
    /**
     * Filter, which usr to fetch.
     */
    where: usrWhereUniqueInput
  }

  /**
   * usr findUniqueOrThrow
   */
  export type usrFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr
     */
    select?: usrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr
     */
    omit?: usrOmit<ExtArgs> | null
    /**
     * Filter, which usr to fetch.
     */
    where: usrWhereUniqueInput
  }

  /**
   * usr findFirst
   */
  export type usrFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr
     */
    select?: usrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr
     */
    omit?: usrOmit<ExtArgs> | null
    /**
     * Filter, which usr to fetch.
     */
    where?: usrWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usrs to fetch.
     */
    orderBy?: usrOrderByWithRelationInput | usrOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for usrs.
     */
    cursor?: usrWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usrs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usrs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of usrs.
     */
    distinct?: UsrScalarFieldEnum | UsrScalarFieldEnum[]
  }

  /**
   * usr findFirstOrThrow
   */
  export type usrFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr
     */
    select?: usrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr
     */
    omit?: usrOmit<ExtArgs> | null
    /**
     * Filter, which usr to fetch.
     */
    where?: usrWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usrs to fetch.
     */
    orderBy?: usrOrderByWithRelationInput | usrOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for usrs.
     */
    cursor?: usrWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usrs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usrs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of usrs.
     */
    distinct?: UsrScalarFieldEnum | UsrScalarFieldEnum[]
  }

  /**
   * usr findMany
   */
  export type usrFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr
     */
    select?: usrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr
     */
    omit?: usrOmit<ExtArgs> | null
    /**
     * Filter, which usrs to fetch.
     */
    where?: usrWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usrs to fetch.
     */
    orderBy?: usrOrderByWithRelationInput | usrOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing usrs.
     */
    cursor?: usrWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usrs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usrs.
     */
    skip?: number
    distinct?: UsrScalarFieldEnum | UsrScalarFieldEnum[]
  }

  /**
   * usr create
   */
  export type usrCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr
     */
    select?: usrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr
     */
    omit?: usrOmit<ExtArgs> | null
    /**
     * The data needed to create a usr.
     */
    data: XOR<usrCreateInput, usrUncheckedCreateInput>
  }

  /**
   * usr createMany
   */
  export type usrCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many usrs.
     */
    data: usrCreateManyInput | usrCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * usr update
   */
  export type usrUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr
     */
    select?: usrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr
     */
    omit?: usrOmit<ExtArgs> | null
    /**
     * The data needed to update a usr.
     */
    data: XOR<usrUpdateInput, usrUncheckedUpdateInput>
    /**
     * Choose, which usr to update.
     */
    where: usrWhereUniqueInput
  }

  /**
   * usr updateMany
   */
  export type usrUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update usrs.
     */
    data: XOR<usrUpdateManyMutationInput, usrUncheckedUpdateManyInput>
    /**
     * Filter which usrs to update
     */
    where?: usrWhereInput
    /**
     * Limit how many usrs to update.
     */
    limit?: number
  }

  /**
   * usr upsert
   */
  export type usrUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr
     */
    select?: usrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr
     */
    omit?: usrOmit<ExtArgs> | null
    /**
     * The filter to search for the usr to update in case it exists.
     */
    where: usrWhereUniqueInput
    /**
     * In case the usr found by the `where` argument doesn't exist, create a new usr with this data.
     */
    create: XOR<usrCreateInput, usrUncheckedCreateInput>
    /**
     * In case the usr was found with the provided `where` argument, update it with this data.
     */
    update: XOR<usrUpdateInput, usrUncheckedUpdateInput>
  }

  /**
   * usr delete
   */
  export type usrDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr
     */
    select?: usrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr
     */
    omit?: usrOmit<ExtArgs> | null
    /**
     * Filter which usr to delete.
     */
    where: usrWhereUniqueInput
  }

  /**
   * usr deleteMany
   */
  export type usrDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which usrs to delete
     */
    where?: usrWhereInput
    /**
     * Limit how many usrs to delete.
     */
    limit?: number
  }

  /**
   * usr without action
   */
  export type usrDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr
     */
    select?: usrSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr
     */
    omit?: usrOmit<ExtArgs> | null
  }


  /**
   * Model usr_tpo
   */

  export type AggregateUsr_tpo = {
    _count: Usr_tpoCountAggregateOutputType | null
    _avg: Usr_tpoAvgAggregateOutputType | null
    _sum: Usr_tpoSumAggregateOutputType | null
    _min: Usr_tpoMinAggregateOutputType | null
    _max: Usr_tpoMaxAggregateOutputType | null
  }

  export type Usr_tpoAvgAggregateOutputType = {
    UsrTpoId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type Usr_tpoSumAggregateOutputType = {
    UsrTpoId: number | null
    SttId: number | null
    UsrIdAlt: number | null
  }

  export type Usr_tpoMinAggregateOutputType = {
    UsrTpoId: number | null
    UsrTpoNme: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type Usr_tpoMaxAggregateOutputType = {
    UsrTpoId: number | null
    UsrTpoNme: string | null
    SttId: number | null
    UsrIdAlt: number | null
    DtaAlt: Date | null
    MtvDel: string | null
  }

  export type Usr_tpoCountAggregateOutputType = {
    UsrTpoId: number
    UsrTpoNme: number
    SttId: number
    UsrIdAlt: number
    DtaAlt: number
    MtvDel: number
    _all: number
  }


  export type Usr_tpoAvgAggregateInputType = {
    UsrTpoId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type Usr_tpoSumAggregateInputType = {
    UsrTpoId?: true
    SttId?: true
    UsrIdAlt?: true
  }

  export type Usr_tpoMinAggregateInputType = {
    UsrTpoId?: true
    UsrTpoNme?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type Usr_tpoMaxAggregateInputType = {
    UsrTpoId?: true
    UsrTpoNme?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
  }

  export type Usr_tpoCountAggregateInputType = {
    UsrTpoId?: true
    UsrTpoNme?: true
    SttId?: true
    UsrIdAlt?: true
    DtaAlt?: true
    MtvDel?: true
    _all?: true
  }

  export type Usr_tpoAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which usr_tpo to aggregate.
     */
    where?: usr_tpoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usr_tpos to fetch.
     */
    orderBy?: usr_tpoOrderByWithRelationInput | usr_tpoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: usr_tpoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usr_tpos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usr_tpos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned usr_tpos
    **/
    _count?: true | Usr_tpoCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: Usr_tpoAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: Usr_tpoSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: Usr_tpoMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: Usr_tpoMaxAggregateInputType
  }

  export type GetUsr_tpoAggregateType<T extends Usr_tpoAggregateArgs> = {
        [P in keyof T & keyof AggregateUsr_tpo]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUsr_tpo[P]>
      : GetScalarType<T[P], AggregateUsr_tpo[P]>
  }




  export type usr_tpoGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: usr_tpoWhereInput
    orderBy?: usr_tpoOrderByWithAggregationInput | usr_tpoOrderByWithAggregationInput[]
    by: Usr_tpoScalarFieldEnum[] | Usr_tpoScalarFieldEnum
    having?: usr_tpoScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: Usr_tpoCountAggregateInputType | true
    _avg?: Usr_tpoAvgAggregateInputType
    _sum?: Usr_tpoSumAggregateInputType
    _min?: Usr_tpoMinAggregateInputType
    _max?: Usr_tpoMaxAggregateInputType
  }

  export type Usr_tpoGroupByOutputType = {
    UsrTpoId: number
    UsrTpoNme: string
    SttId: number
    UsrIdAlt: number
    DtaAlt: Date
    MtvDel: string | null
    _count: Usr_tpoCountAggregateOutputType | null
    _avg: Usr_tpoAvgAggregateOutputType | null
    _sum: Usr_tpoSumAggregateOutputType | null
    _min: Usr_tpoMinAggregateOutputType | null
    _max: Usr_tpoMaxAggregateOutputType | null
  }

  type GetUsr_tpoGroupByPayload<T extends usr_tpoGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<Usr_tpoGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof Usr_tpoGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], Usr_tpoGroupByOutputType[P]>
            : GetScalarType<T[P], Usr_tpoGroupByOutputType[P]>
        }
      >
    >


  export type usr_tpoSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    UsrTpoId?: boolean
    UsrTpoNme?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }, ExtArgs["result"]["usr_tpo"]>



  export type usr_tpoSelectScalar = {
    UsrTpoId?: boolean
    UsrTpoNme?: boolean
    SttId?: boolean
    UsrIdAlt?: boolean
    DtaAlt?: boolean
    MtvDel?: boolean
  }

  export type usr_tpoOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"UsrTpoId" | "UsrTpoNme" | "SttId" | "UsrIdAlt" | "DtaAlt" | "MtvDel", ExtArgs["result"]["usr_tpo"]>

  export type $usr_tpoPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "usr_tpo"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      UsrTpoId: number
      UsrTpoNme: string
      SttId: number
      UsrIdAlt: number
      DtaAlt: Date
      MtvDel: string | null
    }, ExtArgs["result"]["usr_tpo"]>
    composites: {}
  }

  type usr_tpoGetPayload<S extends boolean | null | undefined | usr_tpoDefaultArgs> = $Result.GetResult<Prisma.$usr_tpoPayload, S>

  type usr_tpoCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<usr_tpoFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: Usr_tpoCountAggregateInputType | true
    }

  export interface usr_tpoDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['usr_tpo'], meta: { name: 'usr_tpo' } }
    /**
     * Find zero or one Usr_tpo that matches the filter.
     * @param {usr_tpoFindUniqueArgs} args - Arguments to find a Usr_tpo
     * @example
     * // Get one Usr_tpo
     * const usr_tpo = await prisma.usr_tpo.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends usr_tpoFindUniqueArgs>(args: SelectSubset<T, usr_tpoFindUniqueArgs<ExtArgs>>): Prisma__usr_tpoClient<$Result.GetResult<Prisma.$usr_tpoPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Usr_tpo that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {usr_tpoFindUniqueOrThrowArgs} args - Arguments to find a Usr_tpo
     * @example
     * // Get one Usr_tpo
     * const usr_tpo = await prisma.usr_tpo.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends usr_tpoFindUniqueOrThrowArgs>(args: SelectSubset<T, usr_tpoFindUniqueOrThrowArgs<ExtArgs>>): Prisma__usr_tpoClient<$Result.GetResult<Prisma.$usr_tpoPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Usr_tpo that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usr_tpoFindFirstArgs} args - Arguments to find a Usr_tpo
     * @example
     * // Get one Usr_tpo
     * const usr_tpo = await prisma.usr_tpo.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends usr_tpoFindFirstArgs>(args?: SelectSubset<T, usr_tpoFindFirstArgs<ExtArgs>>): Prisma__usr_tpoClient<$Result.GetResult<Prisma.$usr_tpoPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Usr_tpo that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usr_tpoFindFirstOrThrowArgs} args - Arguments to find a Usr_tpo
     * @example
     * // Get one Usr_tpo
     * const usr_tpo = await prisma.usr_tpo.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends usr_tpoFindFirstOrThrowArgs>(args?: SelectSubset<T, usr_tpoFindFirstOrThrowArgs<ExtArgs>>): Prisma__usr_tpoClient<$Result.GetResult<Prisma.$usr_tpoPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Usr_tpos that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usr_tpoFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Usr_tpos
     * const usr_tpos = await prisma.usr_tpo.findMany()
     * 
     * // Get first 10 Usr_tpos
     * const usr_tpos = await prisma.usr_tpo.findMany({ take: 10 })
     * 
     * // Only select the `UsrTpoId`
     * const usr_tpoWithUsrTpoIdOnly = await prisma.usr_tpo.findMany({ select: { UsrTpoId: true } })
     * 
     */
    findMany<T extends usr_tpoFindManyArgs>(args?: SelectSubset<T, usr_tpoFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$usr_tpoPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Usr_tpo.
     * @param {usr_tpoCreateArgs} args - Arguments to create a Usr_tpo.
     * @example
     * // Create one Usr_tpo
     * const Usr_tpo = await prisma.usr_tpo.create({
     *   data: {
     *     // ... data to create a Usr_tpo
     *   }
     * })
     * 
     */
    create<T extends usr_tpoCreateArgs>(args: SelectSubset<T, usr_tpoCreateArgs<ExtArgs>>): Prisma__usr_tpoClient<$Result.GetResult<Prisma.$usr_tpoPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Usr_tpos.
     * @param {usr_tpoCreateManyArgs} args - Arguments to create many Usr_tpos.
     * @example
     * // Create many Usr_tpos
     * const usr_tpo = await prisma.usr_tpo.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends usr_tpoCreateManyArgs>(args?: SelectSubset<T, usr_tpoCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a Usr_tpo.
     * @param {usr_tpoDeleteArgs} args - Arguments to delete one Usr_tpo.
     * @example
     * // Delete one Usr_tpo
     * const Usr_tpo = await prisma.usr_tpo.delete({
     *   where: {
     *     // ... filter to delete one Usr_tpo
     *   }
     * })
     * 
     */
    delete<T extends usr_tpoDeleteArgs>(args: SelectSubset<T, usr_tpoDeleteArgs<ExtArgs>>): Prisma__usr_tpoClient<$Result.GetResult<Prisma.$usr_tpoPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Usr_tpo.
     * @param {usr_tpoUpdateArgs} args - Arguments to update one Usr_tpo.
     * @example
     * // Update one Usr_tpo
     * const usr_tpo = await prisma.usr_tpo.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends usr_tpoUpdateArgs>(args: SelectSubset<T, usr_tpoUpdateArgs<ExtArgs>>): Prisma__usr_tpoClient<$Result.GetResult<Prisma.$usr_tpoPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Usr_tpos.
     * @param {usr_tpoDeleteManyArgs} args - Arguments to filter Usr_tpos to delete.
     * @example
     * // Delete a few Usr_tpos
     * const { count } = await prisma.usr_tpo.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends usr_tpoDeleteManyArgs>(args?: SelectSubset<T, usr_tpoDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Usr_tpos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usr_tpoUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Usr_tpos
     * const usr_tpo = await prisma.usr_tpo.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends usr_tpoUpdateManyArgs>(args: SelectSubset<T, usr_tpoUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one Usr_tpo.
     * @param {usr_tpoUpsertArgs} args - Arguments to update or create a Usr_tpo.
     * @example
     * // Update or create a Usr_tpo
     * const usr_tpo = await prisma.usr_tpo.upsert({
     *   create: {
     *     // ... data to create a Usr_tpo
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Usr_tpo we want to update
     *   }
     * })
     */
    upsert<T extends usr_tpoUpsertArgs>(args: SelectSubset<T, usr_tpoUpsertArgs<ExtArgs>>): Prisma__usr_tpoClient<$Result.GetResult<Prisma.$usr_tpoPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Usr_tpos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usr_tpoCountArgs} args - Arguments to filter Usr_tpos to count.
     * @example
     * // Count the number of Usr_tpos
     * const count = await prisma.usr_tpo.count({
     *   where: {
     *     // ... the filter for the Usr_tpos we want to count
     *   }
     * })
    **/
    count<T extends usr_tpoCountArgs>(
      args?: Subset<T, usr_tpoCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], Usr_tpoCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Usr_tpo.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {Usr_tpoAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends Usr_tpoAggregateArgs>(args: Subset<T, Usr_tpoAggregateArgs>): Prisma.PrismaPromise<GetUsr_tpoAggregateType<T>>

    /**
     * Group by Usr_tpo.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {usr_tpoGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends usr_tpoGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: usr_tpoGroupByArgs['orderBy'] }
        : { orderBy?: usr_tpoGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, usr_tpoGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUsr_tpoGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the usr_tpo model
   */
  readonly fields: usr_tpoFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for usr_tpo.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__usr_tpoClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the usr_tpo model
   */
  interface usr_tpoFieldRefs {
    readonly UsrTpoId: FieldRef<"usr_tpo", 'Int'>
    readonly UsrTpoNme: FieldRef<"usr_tpo", 'String'>
    readonly SttId: FieldRef<"usr_tpo", 'Int'>
    readonly UsrIdAlt: FieldRef<"usr_tpo", 'Int'>
    readonly DtaAlt: FieldRef<"usr_tpo", 'DateTime'>
    readonly MtvDel: FieldRef<"usr_tpo", 'String'>
  }
    

  // Custom InputTypes
  /**
   * usr_tpo findUnique
   */
  export type usr_tpoFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr_tpo
     */
    select?: usr_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr_tpo
     */
    omit?: usr_tpoOmit<ExtArgs> | null
    /**
     * Filter, which usr_tpo to fetch.
     */
    where: usr_tpoWhereUniqueInput
  }

  /**
   * usr_tpo findUniqueOrThrow
   */
  export type usr_tpoFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr_tpo
     */
    select?: usr_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr_tpo
     */
    omit?: usr_tpoOmit<ExtArgs> | null
    /**
     * Filter, which usr_tpo to fetch.
     */
    where: usr_tpoWhereUniqueInput
  }

  /**
   * usr_tpo findFirst
   */
  export type usr_tpoFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr_tpo
     */
    select?: usr_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr_tpo
     */
    omit?: usr_tpoOmit<ExtArgs> | null
    /**
     * Filter, which usr_tpo to fetch.
     */
    where?: usr_tpoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usr_tpos to fetch.
     */
    orderBy?: usr_tpoOrderByWithRelationInput | usr_tpoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for usr_tpos.
     */
    cursor?: usr_tpoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usr_tpos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usr_tpos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of usr_tpos.
     */
    distinct?: Usr_tpoScalarFieldEnum | Usr_tpoScalarFieldEnum[]
  }

  /**
   * usr_tpo findFirstOrThrow
   */
  export type usr_tpoFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr_tpo
     */
    select?: usr_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr_tpo
     */
    omit?: usr_tpoOmit<ExtArgs> | null
    /**
     * Filter, which usr_tpo to fetch.
     */
    where?: usr_tpoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usr_tpos to fetch.
     */
    orderBy?: usr_tpoOrderByWithRelationInput | usr_tpoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for usr_tpos.
     */
    cursor?: usr_tpoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usr_tpos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usr_tpos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of usr_tpos.
     */
    distinct?: Usr_tpoScalarFieldEnum | Usr_tpoScalarFieldEnum[]
  }

  /**
   * usr_tpo findMany
   */
  export type usr_tpoFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr_tpo
     */
    select?: usr_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr_tpo
     */
    omit?: usr_tpoOmit<ExtArgs> | null
    /**
     * Filter, which usr_tpos to fetch.
     */
    where?: usr_tpoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of usr_tpos to fetch.
     */
    orderBy?: usr_tpoOrderByWithRelationInput | usr_tpoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing usr_tpos.
     */
    cursor?: usr_tpoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` usr_tpos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` usr_tpos.
     */
    skip?: number
    distinct?: Usr_tpoScalarFieldEnum | Usr_tpoScalarFieldEnum[]
  }

  /**
   * usr_tpo create
   */
  export type usr_tpoCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr_tpo
     */
    select?: usr_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr_tpo
     */
    omit?: usr_tpoOmit<ExtArgs> | null
    /**
     * The data needed to create a usr_tpo.
     */
    data: XOR<usr_tpoCreateInput, usr_tpoUncheckedCreateInput>
  }

  /**
   * usr_tpo createMany
   */
  export type usr_tpoCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many usr_tpos.
     */
    data: usr_tpoCreateManyInput | usr_tpoCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * usr_tpo update
   */
  export type usr_tpoUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr_tpo
     */
    select?: usr_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr_tpo
     */
    omit?: usr_tpoOmit<ExtArgs> | null
    /**
     * The data needed to update a usr_tpo.
     */
    data: XOR<usr_tpoUpdateInput, usr_tpoUncheckedUpdateInput>
    /**
     * Choose, which usr_tpo to update.
     */
    where: usr_tpoWhereUniqueInput
  }

  /**
   * usr_tpo updateMany
   */
  export type usr_tpoUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update usr_tpos.
     */
    data: XOR<usr_tpoUpdateManyMutationInput, usr_tpoUncheckedUpdateManyInput>
    /**
     * Filter which usr_tpos to update
     */
    where?: usr_tpoWhereInput
    /**
     * Limit how many usr_tpos to update.
     */
    limit?: number
  }

  /**
   * usr_tpo upsert
   */
  export type usr_tpoUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr_tpo
     */
    select?: usr_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr_tpo
     */
    omit?: usr_tpoOmit<ExtArgs> | null
    /**
     * The filter to search for the usr_tpo to update in case it exists.
     */
    where: usr_tpoWhereUniqueInput
    /**
     * In case the usr_tpo found by the `where` argument doesn't exist, create a new usr_tpo with this data.
     */
    create: XOR<usr_tpoCreateInput, usr_tpoUncheckedCreateInput>
    /**
     * In case the usr_tpo was found with the provided `where` argument, update it with this data.
     */
    update: XOR<usr_tpoUpdateInput, usr_tpoUncheckedUpdateInput>
  }

  /**
   * usr_tpo delete
   */
  export type usr_tpoDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr_tpo
     */
    select?: usr_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr_tpo
     */
    omit?: usr_tpoOmit<ExtArgs> | null
    /**
     * Filter which usr_tpo to delete.
     */
    where: usr_tpoWhereUniqueInput
  }

  /**
   * usr_tpo deleteMany
   */
  export type usr_tpoDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which usr_tpos to delete
     */
    where?: usr_tpoWhereInput
    /**
     * Limit how many usr_tpos to delete.
     */
    limit?: number
  }

  /**
   * usr_tpo without action
   */
  export type usr_tpoDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the usr_tpo
     */
    select?: usr_tpoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the usr_tpo
     */
    omit?: usr_tpoOmit<ExtArgs> | null
  }


  /**
   * Model VwCarregador
   */

  export type AggregateVwCarregador = {
    _count: VwCarregadorCountAggregateOutputType | null
    _avg: VwCarregadorAvgAggregateOutputType | null
    _sum: VwCarregadorSumAggregateOutputType | null
    _min: VwCarregadorMinAggregateOutputType | null
    _max: VwCarregadorMaxAggregateOutputType | null
  }

  export type VwCarregadorAvgAggregateOutputType = {
    UndId: number | null
    EqpItmId: number | null
  }

  export type VwCarregadorSumAggregateOutputType = {
    UndId: number | null
    EqpItmId: number | null
  }

  export type VwCarregadorMinAggregateOutputType = {
    UndId: number | null
    EqpItmId: number | null
    Carregador: string | null
  }

  export type VwCarregadorMaxAggregateOutputType = {
    UndId: number | null
    EqpItmId: number | null
    Carregador: string | null
  }

  export type VwCarregadorCountAggregateOutputType = {
    UndId: number
    EqpItmId: number
    Carregador: number
    _all: number
  }


  export type VwCarregadorAvgAggregateInputType = {
    UndId?: true
    EqpItmId?: true
  }

  export type VwCarregadorSumAggregateInputType = {
    UndId?: true
    EqpItmId?: true
  }

  export type VwCarregadorMinAggregateInputType = {
    UndId?: true
    EqpItmId?: true
    Carregador?: true
  }

  export type VwCarregadorMaxAggregateInputType = {
    UndId?: true
    EqpItmId?: true
    Carregador?: true
  }

  export type VwCarregadorCountAggregateInputType = {
    UndId?: true
    EqpItmId?: true
    Carregador?: true
    _all?: true
  }

  export type VwCarregadorAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which VwCarregador to aggregate.
     */
    where?: VwCarregadorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VwCarregadors to fetch.
     */
    orderBy?: VwCarregadorOrderByWithRelationInput | VwCarregadorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: VwCarregadorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VwCarregadors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VwCarregadors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned VwCarregadors
    **/
    _count?: true | VwCarregadorCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: VwCarregadorAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: VwCarregadorSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: VwCarregadorMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: VwCarregadorMaxAggregateInputType
  }

  export type GetVwCarregadorAggregateType<T extends VwCarregadorAggregateArgs> = {
        [P in keyof T & keyof AggregateVwCarregador]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateVwCarregador[P]>
      : GetScalarType<T[P], AggregateVwCarregador[P]>
  }




  export type VwCarregadorGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VwCarregadorWhereInput
    orderBy?: VwCarregadorOrderByWithAggregationInput | VwCarregadorOrderByWithAggregationInput[]
    by: VwCarregadorScalarFieldEnum[] | VwCarregadorScalarFieldEnum
    having?: VwCarregadorScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: VwCarregadorCountAggregateInputType | true
    _avg?: VwCarregadorAvgAggregateInputType
    _sum?: VwCarregadorSumAggregateInputType
    _min?: VwCarregadorMinAggregateInputType
    _max?: VwCarregadorMaxAggregateInputType
  }

  export type VwCarregadorGroupByOutputType = {
    UndId: number
    EqpItmId: number
    Carregador: string | null
    _count: VwCarregadorCountAggregateOutputType | null
    _avg: VwCarregadorAvgAggregateOutputType | null
    _sum: VwCarregadorSumAggregateOutputType | null
    _min: VwCarregadorMinAggregateOutputType | null
    _max: VwCarregadorMaxAggregateOutputType | null
  }

  type GetVwCarregadorGroupByPayload<T extends VwCarregadorGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<VwCarregadorGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof VwCarregadorGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], VwCarregadorGroupByOutputType[P]>
            : GetScalarType<T[P], VwCarregadorGroupByOutputType[P]>
        }
      >
    >


  export type VwCarregadorSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    UndId?: boolean
    EqpItmId?: boolean
    Carregador?: boolean
  }, ExtArgs["result"]["vwCarregador"]>



  export type VwCarregadorSelectScalar = {
    UndId?: boolean
    EqpItmId?: boolean
    Carregador?: boolean
  }

  export type VwCarregadorOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"UndId" | "EqpItmId" | "Carregador", ExtArgs["result"]["vwCarregador"]>

  export type $VwCarregadorPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "VwCarregador"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      UndId: number
      EqpItmId: number
      Carregador: string | null
    }, ExtArgs["result"]["vwCarregador"]>
    composites: {}
  }

  type VwCarregadorGetPayload<S extends boolean | null | undefined | VwCarregadorDefaultArgs> = $Result.GetResult<Prisma.$VwCarregadorPayload, S>

  type VwCarregadorCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<VwCarregadorFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: VwCarregadorCountAggregateInputType | true
    }

  export interface VwCarregadorDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['VwCarregador'], meta: { name: 'VwCarregador' } }
    /**
     * Find zero or one VwCarregador that matches the filter.
     * @param {VwCarregadorFindUniqueArgs} args - Arguments to find a VwCarregador
     * @example
     * // Get one VwCarregador
     * const vwCarregador = await prisma.vwCarregador.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends VwCarregadorFindUniqueArgs>(args: SelectSubset<T, VwCarregadorFindUniqueArgs<ExtArgs>>): Prisma__VwCarregadorClient<$Result.GetResult<Prisma.$VwCarregadorPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one VwCarregador that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {VwCarregadorFindUniqueOrThrowArgs} args - Arguments to find a VwCarregador
     * @example
     * // Get one VwCarregador
     * const vwCarregador = await prisma.vwCarregador.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends VwCarregadorFindUniqueOrThrowArgs>(args: SelectSubset<T, VwCarregadorFindUniqueOrThrowArgs<ExtArgs>>): Prisma__VwCarregadorClient<$Result.GetResult<Prisma.$VwCarregadorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first VwCarregador that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwCarregadorFindFirstArgs} args - Arguments to find a VwCarregador
     * @example
     * // Get one VwCarregador
     * const vwCarregador = await prisma.vwCarregador.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends VwCarregadorFindFirstArgs>(args?: SelectSubset<T, VwCarregadorFindFirstArgs<ExtArgs>>): Prisma__VwCarregadorClient<$Result.GetResult<Prisma.$VwCarregadorPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first VwCarregador that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwCarregadorFindFirstOrThrowArgs} args - Arguments to find a VwCarregador
     * @example
     * // Get one VwCarregador
     * const vwCarregador = await prisma.vwCarregador.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends VwCarregadorFindFirstOrThrowArgs>(args?: SelectSubset<T, VwCarregadorFindFirstOrThrowArgs<ExtArgs>>): Prisma__VwCarregadorClient<$Result.GetResult<Prisma.$VwCarregadorPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more VwCarregadors that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwCarregadorFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all VwCarregadors
     * const vwCarregadors = await prisma.vwCarregador.findMany()
     * 
     * // Get first 10 VwCarregadors
     * const vwCarregadors = await prisma.vwCarregador.findMany({ take: 10 })
     * 
     * // Only select the `UndId`
     * const vwCarregadorWithUndIdOnly = await prisma.vwCarregador.findMany({ select: { UndId: true } })
     * 
     */
    findMany<T extends VwCarregadorFindManyArgs>(args?: SelectSubset<T, VwCarregadorFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VwCarregadorPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a VwCarregador.
     * @param {VwCarregadorCreateArgs} args - Arguments to create a VwCarregador.
     * @example
     * // Create one VwCarregador
     * const VwCarregador = await prisma.vwCarregador.create({
     *   data: {
     *     // ... data to create a VwCarregador
     *   }
     * })
     * 
     */
    create<T extends VwCarregadorCreateArgs>(args: SelectSubset<T, VwCarregadorCreateArgs<ExtArgs>>): Prisma__VwCarregadorClient<$Result.GetResult<Prisma.$VwCarregadorPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many VwCarregadors.
     * @param {VwCarregadorCreateManyArgs} args - Arguments to create many VwCarregadors.
     * @example
     * // Create many VwCarregadors
     * const vwCarregador = await prisma.vwCarregador.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends VwCarregadorCreateManyArgs>(args?: SelectSubset<T, VwCarregadorCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a VwCarregador.
     * @param {VwCarregadorDeleteArgs} args - Arguments to delete one VwCarregador.
     * @example
     * // Delete one VwCarregador
     * const VwCarregador = await prisma.vwCarregador.delete({
     *   where: {
     *     // ... filter to delete one VwCarregador
     *   }
     * })
     * 
     */
    delete<T extends VwCarregadorDeleteArgs>(args: SelectSubset<T, VwCarregadorDeleteArgs<ExtArgs>>): Prisma__VwCarregadorClient<$Result.GetResult<Prisma.$VwCarregadorPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one VwCarregador.
     * @param {VwCarregadorUpdateArgs} args - Arguments to update one VwCarregador.
     * @example
     * // Update one VwCarregador
     * const vwCarregador = await prisma.vwCarregador.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends VwCarregadorUpdateArgs>(args: SelectSubset<T, VwCarregadorUpdateArgs<ExtArgs>>): Prisma__VwCarregadorClient<$Result.GetResult<Prisma.$VwCarregadorPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more VwCarregadors.
     * @param {VwCarregadorDeleteManyArgs} args - Arguments to filter VwCarregadors to delete.
     * @example
     * // Delete a few VwCarregadors
     * const { count } = await prisma.vwCarregador.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends VwCarregadorDeleteManyArgs>(args?: SelectSubset<T, VwCarregadorDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more VwCarregadors.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwCarregadorUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many VwCarregadors
     * const vwCarregador = await prisma.vwCarregador.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends VwCarregadorUpdateManyArgs>(args: SelectSubset<T, VwCarregadorUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one VwCarregador.
     * @param {VwCarregadorUpsertArgs} args - Arguments to update or create a VwCarregador.
     * @example
     * // Update or create a VwCarregador
     * const vwCarregador = await prisma.vwCarregador.upsert({
     *   create: {
     *     // ... data to create a VwCarregador
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the VwCarregador we want to update
     *   }
     * })
     */
    upsert<T extends VwCarregadorUpsertArgs>(args: SelectSubset<T, VwCarregadorUpsertArgs<ExtArgs>>): Prisma__VwCarregadorClient<$Result.GetResult<Prisma.$VwCarregadorPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of VwCarregadors.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwCarregadorCountArgs} args - Arguments to filter VwCarregadors to count.
     * @example
     * // Count the number of VwCarregadors
     * const count = await prisma.vwCarregador.count({
     *   where: {
     *     // ... the filter for the VwCarregadors we want to count
     *   }
     * })
    **/
    count<T extends VwCarregadorCountArgs>(
      args?: Subset<T, VwCarregadorCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], VwCarregadorCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a VwCarregador.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwCarregadorAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends VwCarregadorAggregateArgs>(args: Subset<T, VwCarregadorAggregateArgs>): Prisma.PrismaPromise<GetVwCarregadorAggregateType<T>>

    /**
     * Group by VwCarregador.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwCarregadorGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends VwCarregadorGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: VwCarregadorGroupByArgs['orderBy'] }
        : { orderBy?: VwCarregadorGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, VwCarregadorGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetVwCarregadorGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the VwCarregador model
   */
  readonly fields: VwCarregadorFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for VwCarregador.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__VwCarregadorClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the VwCarregador model
   */
  interface VwCarregadorFieldRefs {
    readonly UndId: FieldRef<"VwCarregador", 'Int'>
    readonly EqpItmId: FieldRef<"VwCarregador", 'Int'>
    readonly Carregador: FieldRef<"VwCarregador", 'String'>
  }
    

  // Custom InputTypes
  /**
   * VwCarregador findUnique
   */
  export type VwCarregadorFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwCarregador
     */
    select?: VwCarregadorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwCarregador
     */
    omit?: VwCarregadorOmit<ExtArgs> | null
    /**
     * Filter, which VwCarregador to fetch.
     */
    where: VwCarregadorWhereUniqueInput
  }

  /**
   * VwCarregador findUniqueOrThrow
   */
  export type VwCarregadorFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwCarregador
     */
    select?: VwCarregadorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwCarregador
     */
    omit?: VwCarregadorOmit<ExtArgs> | null
    /**
     * Filter, which VwCarregador to fetch.
     */
    where: VwCarregadorWhereUniqueInput
  }

  /**
   * VwCarregador findFirst
   */
  export type VwCarregadorFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwCarregador
     */
    select?: VwCarregadorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwCarregador
     */
    omit?: VwCarregadorOmit<ExtArgs> | null
    /**
     * Filter, which VwCarregador to fetch.
     */
    where?: VwCarregadorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VwCarregadors to fetch.
     */
    orderBy?: VwCarregadorOrderByWithRelationInput | VwCarregadorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for VwCarregadors.
     */
    cursor?: VwCarregadorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VwCarregadors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VwCarregadors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VwCarregadors.
     */
    distinct?: VwCarregadorScalarFieldEnum | VwCarregadorScalarFieldEnum[]
  }

  /**
   * VwCarregador findFirstOrThrow
   */
  export type VwCarregadorFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwCarregador
     */
    select?: VwCarregadorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwCarregador
     */
    omit?: VwCarregadorOmit<ExtArgs> | null
    /**
     * Filter, which VwCarregador to fetch.
     */
    where?: VwCarregadorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VwCarregadors to fetch.
     */
    orderBy?: VwCarregadorOrderByWithRelationInput | VwCarregadorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for VwCarregadors.
     */
    cursor?: VwCarregadorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VwCarregadors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VwCarregadors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VwCarregadors.
     */
    distinct?: VwCarregadorScalarFieldEnum | VwCarregadorScalarFieldEnum[]
  }

  /**
   * VwCarregador findMany
   */
  export type VwCarregadorFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwCarregador
     */
    select?: VwCarregadorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwCarregador
     */
    omit?: VwCarregadorOmit<ExtArgs> | null
    /**
     * Filter, which VwCarregadors to fetch.
     */
    where?: VwCarregadorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VwCarregadors to fetch.
     */
    orderBy?: VwCarregadorOrderByWithRelationInput | VwCarregadorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing VwCarregadors.
     */
    cursor?: VwCarregadorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VwCarregadors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VwCarregadors.
     */
    skip?: number
    distinct?: VwCarregadorScalarFieldEnum | VwCarregadorScalarFieldEnum[]
  }

  /**
   * VwCarregador create
   */
  export type VwCarregadorCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwCarregador
     */
    select?: VwCarregadorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwCarregador
     */
    omit?: VwCarregadorOmit<ExtArgs> | null
    /**
     * The data needed to create a VwCarregador.
     */
    data: XOR<VwCarregadorCreateInput, VwCarregadorUncheckedCreateInput>
  }

  /**
   * VwCarregador createMany
   */
  export type VwCarregadorCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many VwCarregadors.
     */
    data: VwCarregadorCreateManyInput | VwCarregadorCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * VwCarregador update
   */
  export type VwCarregadorUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwCarregador
     */
    select?: VwCarregadorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwCarregador
     */
    omit?: VwCarregadorOmit<ExtArgs> | null
    /**
     * The data needed to update a VwCarregador.
     */
    data: XOR<VwCarregadorUpdateInput, VwCarregadorUncheckedUpdateInput>
    /**
     * Choose, which VwCarregador to update.
     */
    where: VwCarregadorWhereUniqueInput
  }

  /**
   * VwCarregador updateMany
   */
  export type VwCarregadorUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update VwCarregadors.
     */
    data: XOR<VwCarregadorUpdateManyMutationInput, VwCarregadorUncheckedUpdateManyInput>
    /**
     * Filter which VwCarregadors to update
     */
    where?: VwCarregadorWhereInput
    /**
     * Limit how many VwCarregadors to update.
     */
    limit?: number
  }

  /**
   * VwCarregador upsert
   */
  export type VwCarregadorUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwCarregador
     */
    select?: VwCarregadorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwCarregador
     */
    omit?: VwCarregadorOmit<ExtArgs> | null
    /**
     * The filter to search for the VwCarregador to update in case it exists.
     */
    where: VwCarregadorWhereUniqueInput
    /**
     * In case the VwCarregador found by the `where` argument doesn't exist, create a new VwCarregador with this data.
     */
    create: XOR<VwCarregadorCreateInput, VwCarregadorUncheckedCreateInput>
    /**
     * In case the VwCarregador was found with the provided `where` argument, update it with this data.
     */
    update: XOR<VwCarregadorUpdateInput, VwCarregadorUncheckedUpdateInput>
  }

  /**
   * VwCarregador delete
   */
  export type VwCarregadorDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwCarregador
     */
    select?: VwCarregadorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwCarregador
     */
    omit?: VwCarregadorOmit<ExtArgs> | null
    /**
     * Filter which VwCarregador to delete.
     */
    where: VwCarregadorWhereUniqueInput
  }

  /**
   * VwCarregador deleteMany
   */
  export type VwCarregadorDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which VwCarregadors to delete
     */
    where?: VwCarregadorWhereInput
    /**
     * Limit how many VwCarregadors to delete.
     */
    limit?: number
  }

  /**
   * VwCarregador without action
   */
  export type VwCarregadorDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwCarregador
     */
    select?: VwCarregadorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwCarregador
     */
    omit?: VwCarregadorOmit<ExtArgs> | null
  }


  /**
   * Model VwOnibus
   */

  export type AggregateVwOnibus = {
    _count: VwOnibusCountAggregateOutputType | null
    _avg: VwOnibusAvgAggregateOutputType | null
    _sum: VwOnibusSumAggregateOutputType | null
    _min: VwOnibusMinAggregateOutputType | null
    _max: VwOnibusMaxAggregateOutputType | null
  }

  export type VwOnibusAvgAggregateOutputType = {
    EqpItmId: number | null
  }

  export type VwOnibusSumAggregateOutputType = {
    EqpItmId: number | null
  }

  export type VwOnibusMinAggregateOutputType = {
    EqpItmId: number | null
    Onibus: string | null
    Situacao: string | null
  }

  export type VwOnibusMaxAggregateOutputType = {
    EqpItmId: number | null
    Onibus: string | null
    Situacao: string | null
  }

  export type VwOnibusCountAggregateOutputType = {
    EqpItmId: number
    Onibus: number
    Situacao: number
    _all: number
  }


  export type VwOnibusAvgAggregateInputType = {
    EqpItmId?: true
  }

  export type VwOnibusSumAggregateInputType = {
    EqpItmId?: true
  }

  export type VwOnibusMinAggregateInputType = {
    EqpItmId?: true
    Onibus?: true
    Situacao?: true
  }

  export type VwOnibusMaxAggregateInputType = {
    EqpItmId?: true
    Onibus?: true
    Situacao?: true
  }

  export type VwOnibusCountAggregateInputType = {
    EqpItmId?: true
    Onibus?: true
    Situacao?: true
    _all?: true
  }

  export type VwOnibusAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which VwOnibus to aggregate.
     */
    where?: VwOnibusWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VwOnibuses to fetch.
     */
    orderBy?: VwOnibusOrderByWithRelationInput | VwOnibusOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: VwOnibusWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VwOnibuses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VwOnibuses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned VwOnibuses
    **/
    _count?: true | VwOnibusCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: VwOnibusAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: VwOnibusSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: VwOnibusMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: VwOnibusMaxAggregateInputType
  }

  export type GetVwOnibusAggregateType<T extends VwOnibusAggregateArgs> = {
        [P in keyof T & keyof AggregateVwOnibus]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateVwOnibus[P]>
      : GetScalarType<T[P], AggregateVwOnibus[P]>
  }




  export type VwOnibusGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VwOnibusWhereInput
    orderBy?: VwOnibusOrderByWithAggregationInput | VwOnibusOrderByWithAggregationInput[]
    by: VwOnibusScalarFieldEnum[] | VwOnibusScalarFieldEnum
    having?: VwOnibusScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: VwOnibusCountAggregateInputType | true
    _avg?: VwOnibusAvgAggregateInputType
    _sum?: VwOnibusSumAggregateInputType
    _min?: VwOnibusMinAggregateInputType
    _max?: VwOnibusMaxAggregateInputType
  }

  export type VwOnibusGroupByOutputType = {
    EqpItmId: number
    Onibus: string
    Situacao: string
    _count: VwOnibusCountAggregateOutputType | null
    _avg: VwOnibusAvgAggregateOutputType | null
    _sum: VwOnibusSumAggregateOutputType | null
    _min: VwOnibusMinAggregateOutputType | null
    _max: VwOnibusMaxAggregateOutputType | null
  }

  type GetVwOnibusGroupByPayload<T extends VwOnibusGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<VwOnibusGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof VwOnibusGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], VwOnibusGroupByOutputType[P]>
            : GetScalarType<T[P], VwOnibusGroupByOutputType[P]>
        }
      >
    >


  export type VwOnibusSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    EqpItmId?: boolean
    Onibus?: boolean
    Situacao?: boolean
  }, ExtArgs["result"]["vwOnibus"]>



  export type VwOnibusSelectScalar = {
    EqpItmId?: boolean
    Onibus?: boolean
    Situacao?: boolean
  }

  export type VwOnibusOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"EqpItmId" | "Onibus" | "Situacao", ExtArgs["result"]["vwOnibus"]>

  export type $VwOnibusPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "VwOnibus"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      EqpItmId: number
      Onibus: string
      Situacao: string
    }, ExtArgs["result"]["vwOnibus"]>
    composites: {}
  }

  type VwOnibusGetPayload<S extends boolean | null | undefined | VwOnibusDefaultArgs> = $Result.GetResult<Prisma.$VwOnibusPayload, S>

  type VwOnibusCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<VwOnibusFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: VwOnibusCountAggregateInputType | true
    }

  export interface VwOnibusDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['VwOnibus'], meta: { name: 'VwOnibus' } }
    /**
     * Find zero or one VwOnibus that matches the filter.
     * @param {VwOnibusFindUniqueArgs} args - Arguments to find a VwOnibus
     * @example
     * // Get one VwOnibus
     * const vwOnibus = await prisma.vwOnibus.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends VwOnibusFindUniqueArgs>(args: SelectSubset<T, VwOnibusFindUniqueArgs<ExtArgs>>): Prisma__VwOnibusClient<$Result.GetResult<Prisma.$VwOnibusPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one VwOnibus that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {VwOnibusFindUniqueOrThrowArgs} args - Arguments to find a VwOnibus
     * @example
     * // Get one VwOnibus
     * const vwOnibus = await prisma.vwOnibus.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends VwOnibusFindUniqueOrThrowArgs>(args: SelectSubset<T, VwOnibusFindUniqueOrThrowArgs<ExtArgs>>): Prisma__VwOnibusClient<$Result.GetResult<Prisma.$VwOnibusPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first VwOnibus that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwOnibusFindFirstArgs} args - Arguments to find a VwOnibus
     * @example
     * // Get one VwOnibus
     * const vwOnibus = await prisma.vwOnibus.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends VwOnibusFindFirstArgs>(args?: SelectSubset<T, VwOnibusFindFirstArgs<ExtArgs>>): Prisma__VwOnibusClient<$Result.GetResult<Prisma.$VwOnibusPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first VwOnibus that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwOnibusFindFirstOrThrowArgs} args - Arguments to find a VwOnibus
     * @example
     * // Get one VwOnibus
     * const vwOnibus = await prisma.vwOnibus.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends VwOnibusFindFirstOrThrowArgs>(args?: SelectSubset<T, VwOnibusFindFirstOrThrowArgs<ExtArgs>>): Prisma__VwOnibusClient<$Result.GetResult<Prisma.$VwOnibusPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more VwOnibuses that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwOnibusFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all VwOnibuses
     * const vwOnibuses = await prisma.vwOnibus.findMany()
     * 
     * // Get first 10 VwOnibuses
     * const vwOnibuses = await prisma.vwOnibus.findMany({ take: 10 })
     * 
     * // Only select the `EqpItmId`
     * const vwOnibusWithEqpItmIdOnly = await prisma.vwOnibus.findMany({ select: { EqpItmId: true } })
     * 
     */
    findMany<T extends VwOnibusFindManyArgs>(args?: SelectSubset<T, VwOnibusFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VwOnibusPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a VwOnibus.
     * @param {VwOnibusCreateArgs} args - Arguments to create a VwOnibus.
     * @example
     * // Create one VwOnibus
     * const VwOnibus = await prisma.vwOnibus.create({
     *   data: {
     *     // ... data to create a VwOnibus
     *   }
     * })
     * 
     */
    create<T extends VwOnibusCreateArgs>(args: SelectSubset<T, VwOnibusCreateArgs<ExtArgs>>): Prisma__VwOnibusClient<$Result.GetResult<Prisma.$VwOnibusPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many VwOnibuses.
     * @param {VwOnibusCreateManyArgs} args - Arguments to create many VwOnibuses.
     * @example
     * // Create many VwOnibuses
     * const vwOnibus = await prisma.vwOnibus.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends VwOnibusCreateManyArgs>(args?: SelectSubset<T, VwOnibusCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a VwOnibus.
     * @param {VwOnibusDeleteArgs} args - Arguments to delete one VwOnibus.
     * @example
     * // Delete one VwOnibus
     * const VwOnibus = await prisma.vwOnibus.delete({
     *   where: {
     *     // ... filter to delete one VwOnibus
     *   }
     * })
     * 
     */
    delete<T extends VwOnibusDeleteArgs>(args: SelectSubset<T, VwOnibusDeleteArgs<ExtArgs>>): Prisma__VwOnibusClient<$Result.GetResult<Prisma.$VwOnibusPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one VwOnibus.
     * @param {VwOnibusUpdateArgs} args - Arguments to update one VwOnibus.
     * @example
     * // Update one VwOnibus
     * const vwOnibus = await prisma.vwOnibus.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends VwOnibusUpdateArgs>(args: SelectSubset<T, VwOnibusUpdateArgs<ExtArgs>>): Prisma__VwOnibusClient<$Result.GetResult<Prisma.$VwOnibusPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more VwOnibuses.
     * @param {VwOnibusDeleteManyArgs} args - Arguments to filter VwOnibuses to delete.
     * @example
     * // Delete a few VwOnibuses
     * const { count } = await prisma.vwOnibus.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends VwOnibusDeleteManyArgs>(args?: SelectSubset<T, VwOnibusDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more VwOnibuses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwOnibusUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many VwOnibuses
     * const vwOnibus = await prisma.vwOnibus.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends VwOnibusUpdateManyArgs>(args: SelectSubset<T, VwOnibusUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one VwOnibus.
     * @param {VwOnibusUpsertArgs} args - Arguments to update or create a VwOnibus.
     * @example
     * // Update or create a VwOnibus
     * const vwOnibus = await prisma.vwOnibus.upsert({
     *   create: {
     *     // ... data to create a VwOnibus
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the VwOnibus we want to update
     *   }
     * })
     */
    upsert<T extends VwOnibusUpsertArgs>(args: SelectSubset<T, VwOnibusUpsertArgs<ExtArgs>>): Prisma__VwOnibusClient<$Result.GetResult<Prisma.$VwOnibusPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of VwOnibuses.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwOnibusCountArgs} args - Arguments to filter VwOnibuses to count.
     * @example
     * // Count the number of VwOnibuses
     * const count = await prisma.vwOnibus.count({
     *   where: {
     *     // ... the filter for the VwOnibuses we want to count
     *   }
     * })
    **/
    count<T extends VwOnibusCountArgs>(
      args?: Subset<T, VwOnibusCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], VwOnibusCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a VwOnibus.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwOnibusAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends VwOnibusAggregateArgs>(args: Subset<T, VwOnibusAggregateArgs>): Prisma.PrismaPromise<GetVwOnibusAggregateType<T>>

    /**
     * Group by VwOnibus.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwOnibusGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends VwOnibusGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: VwOnibusGroupByArgs['orderBy'] }
        : { orderBy?: VwOnibusGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, VwOnibusGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetVwOnibusGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the VwOnibus model
   */
  readonly fields: VwOnibusFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for VwOnibus.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__VwOnibusClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the VwOnibus model
   */
  interface VwOnibusFieldRefs {
    readonly EqpItmId: FieldRef<"VwOnibus", 'Int'>
    readonly Onibus: FieldRef<"VwOnibus", 'String'>
    readonly Situacao: FieldRef<"VwOnibus", 'String'>
  }
    

  // Custom InputTypes
  /**
   * VwOnibus findUnique
   */
  export type VwOnibusFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwOnibus
     */
    select?: VwOnibusSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwOnibus
     */
    omit?: VwOnibusOmit<ExtArgs> | null
    /**
     * Filter, which VwOnibus to fetch.
     */
    where: VwOnibusWhereUniqueInput
  }

  /**
   * VwOnibus findUniqueOrThrow
   */
  export type VwOnibusFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwOnibus
     */
    select?: VwOnibusSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwOnibus
     */
    omit?: VwOnibusOmit<ExtArgs> | null
    /**
     * Filter, which VwOnibus to fetch.
     */
    where: VwOnibusWhereUniqueInput
  }

  /**
   * VwOnibus findFirst
   */
  export type VwOnibusFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwOnibus
     */
    select?: VwOnibusSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwOnibus
     */
    omit?: VwOnibusOmit<ExtArgs> | null
    /**
     * Filter, which VwOnibus to fetch.
     */
    where?: VwOnibusWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VwOnibuses to fetch.
     */
    orderBy?: VwOnibusOrderByWithRelationInput | VwOnibusOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for VwOnibuses.
     */
    cursor?: VwOnibusWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VwOnibuses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VwOnibuses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VwOnibuses.
     */
    distinct?: VwOnibusScalarFieldEnum | VwOnibusScalarFieldEnum[]
  }

  /**
   * VwOnibus findFirstOrThrow
   */
  export type VwOnibusFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwOnibus
     */
    select?: VwOnibusSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwOnibus
     */
    omit?: VwOnibusOmit<ExtArgs> | null
    /**
     * Filter, which VwOnibus to fetch.
     */
    where?: VwOnibusWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VwOnibuses to fetch.
     */
    orderBy?: VwOnibusOrderByWithRelationInput | VwOnibusOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for VwOnibuses.
     */
    cursor?: VwOnibusWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VwOnibuses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VwOnibuses.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VwOnibuses.
     */
    distinct?: VwOnibusScalarFieldEnum | VwOnibusScalarFieldEnum[]
  }

  /**
   * VwOnibus findMany
   */
  export type VwOnibusFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwOnibus
     */
    select?: VwOnibusSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwOnibus
     */
    omit?: VwOnibusOmit<ExtArgs> | null
    /**
     * Filter, which VwOnibuses to fetch.
     */
    where?: VwOnibusWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VwOnibuses to fetch.
     */
    orderBy?: VwOnibusOrderByWithRelationInput | VwOnibusOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing VwOnibuses.
     */
    cursor?: VwOnibusWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VwOnibuses from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VwOnibuses.
     */
    skip?: number
    distinct?: VwOnibusScalarFieldEnum | VwOnibusScalarFieldEnum[]
  }

  /**
   * VwOnibus create
   */
  export type VwOnibusCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwOnibus
     */
    select?: VwOnibusSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwOnibus
     */
    omit?: VwOnibusOmit<ExtArgs> | null
    /**
     * The data needed to create a VwOnibus.
     */
    data: XOR<VwOnibusCreateInput, VwOnibusUncheckedCreateInput>
  }

  /**
   * VwOnibus createMany
   */
  export type VwOnibusCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many VwOnibuses.
     */
    data: VwOnibusCreateManyInput | VwOnibusCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * VwOnibus update
   */
  export type VwOnibusUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwOnibus
     */
    select?: VwOnibusSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwOnibus
     */
    omit?: VwOnibusOmit<ExtArgs> | null
    /**
     * The data needed to update a VwOnibus.
     */
    data: XOR<VwOnibusUpdateInput, VwOnibusUncheckedUpdateInput>
    /**
     * Choose, which VwOnibus to update.
     */
    where: VwOnibusWhereUniqueInput
  }

  /**
   * VwOnibus updateMany
   */
  export type VwOnibusUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update VwOnibuses.
     */
    data: XOR<VwOnibusUpdateManyMutationInput, VwOnibusUncheckedUpdateManyInput>
    /**
     * Filter which VwOnibuses to update
     */
    where?: VwOnibusWhereInput
    /**
     * Limit how many VwOnibuses to update.
     */
    limit?: number
  }

  /**
   * VwOnibus upsert
   */
  export type VwOnibusUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwOnibus
     */
    select?: VwOnibusSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwOnibus
     */
    omit?: VwOnibusOmit<ExtArgs> | null
    /**
     * The filter to search for the VwOnibus to update in case it exists.
     */
    where: VwOnibusWhereUniqueInput
    /**
     * In case the VwOnibus found by the `where` argument doesn't exist, create a new VwOnibus with this data.
     */
    create: XOR<VwOnibusCreateInput, VwOnibusUncheckedCreateInput>
    /**
     * In case the VwOnibus was found with the provided `where` argument, update it with this data.
     */
    update: XOR<VwOnibusUpdateInput, VwOnibusUncheckedUpdateInput>
  }

  /**
   * VwOnibus delete
   */
  export type VwOnibusDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwOnibus
     */
    select?: VwOnibusSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwOnibus
     */
    omit?: VwOnibusOmit<ExtArgs> | null
    /**
     * Filter which VwOnibus to delete.
     */
    where: VwOnibusWhereUniqueInput
  }

  /**
   * VwOnibus deleteMany
   */
  export type VwOnibusDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which VwOnibuses to delete
     */
    where?: VwOnibusWhereInput
    /**
     * Limit how many VwOnibuses to delete.
     */
    limit?: number
  }

  /**
   * VwOnibus without action
   */
  export type VwOnibusDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwOnibus
     */
    select?: VwOnibusSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwOnibus
     */
    omit?: VwOnibusOmit<ExtArgs> | null
  }


  /**
   * Model VwPostoRecarga
   */

  export type AggregateVwPostoRecarga = {
    _count: VwPostoRecargaCountAggregateOutputType | null
    _avg: VwPostoRecargaAvgAggregateOutputType | null
    _sum: VwPostoRecargaSumAggregateOutputType | null
    _min: VwPostoRecargaMinAggregateOutputType | null
    _max: VwPostoRecargaMaxAggregateOutputType | null
  }

  export type VwPostoRecargaAvgAggregateOutputType = {
    UndId: number | null
    EqpItmId: number | null
  }

  export type VwPostoRecargaSumAggregateOutputType = {
    UndId: number | null
    EqpItmId: number | null
  }

  export type VwPostoRecargaMinAggregateOutputType = {
    UndId: number | null
    PostoRecarga: string | null
    Latitude: string | null
    Longitude: string | null
    EqpItmId: number | null
    Carregador: string | null
  }

  export type VwPostoRecargaMaxAggregateOutputType = {
    UndId: number | null
    PostoRecarga: string | null
    Latitude: string | null
    Longitude: string | null
    EqpItmId: number | null
    Carregador: string | null
  }

  export type VwPostoRecargaCountAggregateOutputType = {
    UndId: number
    PostoRecarga: number
    Latitude: number
    Longitude: number
    EqpItmId: number
    Carregador: number
    _all: number
  }


  export type VwPostoRecargaAvgAggregateInputType = {
    UndId?: true
    EqpItmId?: true
  }

  export type VwPostoRecargaSumAggregateInputType = {
    UndId?: true
    EqpItmId?: true
  }

  export type VwPostoRecargaMinAggregateInputType = {
    UndId?: true
    PostoRecarga?: true
    Latitude?: true
    Longitude?: true
    EqpItmId?: true
    Carregador?: true
  }

  export type VwPostoRecargaMaxAggregateInputType = {
    UndId?: true
    PostoRecarga?: true
    Latitude?: true
    Longitude?: true
    EqpItmId?: true
    Carregador?: true
  }

  export type VwPostoRecargaCountAggregateInputType = {
    UndId?: true
    PostoRecarga?: true
    Latitude?: true
    Longitude?: true
    EqpItmId?: true
    Carregador?: true
    _all?: true
  }

  export type VwPostoRecargaAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which VwPostoRecarga to aggregate.
     */
    where?: VwPostoRecargaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VwPostoRecargas to fetch.
     */
    orderBy?: VwPostoRecargaOrderByWithRelationInput | VwPostoRecargaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: VwPostoRecargaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VwPostoRecargas from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VwPostoRecargas.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned VwPostoRecargas
    **/
    _count?: true | VwPostoRecargaCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: VwPostoRecargaAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: VwPostoRecargaSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: VwPostoRecargaMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: VwPostoRecargaMaxAggregateInputType
  }

  export type GetVwPostoRecargaAggregateType<T extends VwPostoRecargaAggregateArgs> = {
        [P in keyof T & keyof AggregateVwPostoRecarga]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateVwPostoRecarga[P]>
      : GetScalarType<T[P], AggregateVwPostoRecarga[P]>
  }




  export type VwPostoRecargaGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VwPostoRecargaWhereInput
    orderBy?: VwPostoRecargaOrderByWithAggregationInput | VwPostoRecargaOrderByWithAggregationInput[]
    by: VwPostoRecargaScalarFieldEnum[] | VwPostoRecargaScalarFieldEnum
    having?: VwPostoRecargaScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: VwPostoRecargaCountAggregateInputType | true
    _avg?: VwPostoRecargaAvgAggregateInputType
    _sum?: VwPostoRecargaSumAggregateInputType
    _min?: VwPostoRecargaMinAggregateInputType
    _max?: VwPostoRecargaMaxAggregateInputType
  }

  export type VwPostoRecargaGroupByOutputType = {
    UndId: number
    PostoRecarga: string
    Latitude: string | null
    Longitude: string | null
    EqpItmId: number | null
    Carregador: string | null
    _count: VwPostoRecargaCountAggregateOutputType | null
    _avg: VwPostoRecargaAvgAggregateOutputType | null
    _sum: VwPostoRecargaSumAggregateOutputType | null
    _min: VwPostoRecargaMinAggregateOutputType | null
    _max: VwPostoRecargaMaxAggregateOutputType | null
  }

  type GetVwPostoRecargaGroupByPayload<T extends VwPostoRecargaGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<VwPostoRecargaGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof VwPostoRecargaGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], VwPostoRecargaGroupByOutputType[P]>
            : GetScalarType<T[P], VwPostoRecargaGroupByOutputType[P]>
        }
      >
    >


  export type VwPostoRecargaSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    UndId?: boolean
    PostoRecarga?: boolean
    Latitude?: boolean
    Longitude?: boolean
    EqpItmId?: boolean
    Carregador?: boolean
  }, ExtArgs["result"]["vwPostoRecarga"]>



  export type VwPostoRecargaSelectScalar = {
    UndId?: boolean
    PostoRecarga?: boolean
    Latitude?: boolean
    Longitude?: boolean
    EqpItmId?: boolean
    Carregador?: boolean
  }

  export type VwPostoRecargaOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"UndId" | "PostoRecarga" | "Latitude" | "Longitude" | "EqpItmId" | "Carregador", ExtArgs["result"]["vwPostoRecarga"]>

  export type $VwPostoRecargaPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "VwPostoRecarga"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      UndId: number
      PostoRecarga: string
      Latitude: string | null
      Longitude: string | null
      EqpItmId: number | null
      Carregador: string | null
    }, ExtArgs["result"]["vwPostoRecarga"]>
    composites: {}
  }

  type VwPostoRecargaGetPayload<S extends boolean | null | undefined | VwPostoRecargaDefaultArgs> = $Result.GetResult<Prisma.$VwPostoRecargaPayload, S>

  type VwPostoRecargaCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<VwPostoRecargaFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: VwPostoRecargaCountAggregateInputType | true
    }

  export interface VwPostoRecargaDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['VwPostoRecarga'], meta: { name: 'VwPostoRecarga' } }
    /**
     * Find zero or one VwPostoRecarga that matches the filter.
     * @param {VwPostoRecargaFindUniqueArgs} args - Arguments to find a VwPostoRecarga
     * @example
     * // Get one VwPostoRecarga
     * const vwPostoRecarga = await prisma.vwPostoRecarga.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends VwPostoRecargaFindUniqueArgs>(args: SelectSubset<T, VwPostoRecargaFindUniqueArgs<ExtArgs>>): Prisma__VwPostoRecargaClient<$Result.GetResult<Prisma.$VwPostoRecargaPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one VwPostoRecarga that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {VwPostoRecargaFindUniqueOrThrowArgs} args - Arguments to find a VwPostoRecarga
     * @example
     * // Get one VwPostoRecarga
     * const vwPostoRecarga = await prisma.vwPostoRecarga.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends VwPostoRecargaFindUniqueOrThrowArgs>(args: SelectSubset<T, VwPostoRecargaFindUniqueOrThrowArgs<ExtArgs>>): Prisma__VwPostoRecargaClient<$Result.GetResult<Prisma.$VwPostoRecargaPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first VwPostoRecarga that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwPostoRecargaFindFirstArgs} args - Arguments to find a VwPostoRecarga
     * @example
     * // Get one VwPostoRecarga
     * const vwPostoRecarga = await prisma.vwPostoRecarga.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends VwPostoRecargaFindFirstArgs>(args?: SelectSubset<T, VwPostoRecargaFindFirstArgs<ExtArgs>>): Prisma__VwPostoRecargaClient<$Result.GetResult<Prisma.$VwPostoRecargaPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first VwPostoRecarga that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwPostoRecargaFindFirstOrThrowArgs} args - Arguments to find a VwPostoRecarga
     * @example
     * // Get one VwPostoRecarga
     * const vwPostoRecarga = await prisma.vwPostoRecarga.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends VwPostoRecargaFindFirstOrThrowArgs>(args?: SelectSubset<T, VwPostoRecargaFindFirstOrThrowArgs<ExtArgs>>): Prisma__VwPostoRecargaClient<$Result.GetResult<Prisma.$VwPostoRecargaPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more VwPostoRecargas that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwPostoRecargaFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all VwPostoRecargas
     * const vwPostoRecargas = await prisma.vwPostoRecarga.findMany()
     * 
     * // Get first 10 VwPostoRecargas
     * const vwPostoRecargas = await prisma.vwPostoRecarga.findMany({ take: 10 })
     * 
     * // Only select the `UndId`
     * const vwPostoRecargaWithUndIdOnly = await prisma.vwPostoRecarga.findMany({ select: { UndId: true } })
     * 
     */
    findMany<T extends VwPostoRecargaFindManyArgs>(args?: SelectSubset<T, VwPostoRecargaFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VwPostoRecargaPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a VwPostoRecarga.
     * @param {VwPostoRecargaCreateArgs} args - Arguments to create a VwPostoRecarga.
     * @example
     * // Create one VwPostoRecarga
     * const VwPostoRecarga = await prisma.vwPostoRecarga.create({
     *   data: {
     *     // ... data to create a VwPostoRecarga
     *   }
     * })
     * 
     */
    create<T extends VwPostoRecargaCreateArgs>(args: SelectSubset<T, VwPostoRecargaCreateArgs<ExtArgs>>): Prisma__VwPostoRecargaClient<$Result.GetResult<Prisma.$VwPostoRecargaPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many VwPostoRecargas.
     * @param {VwPostoRecargaCreateManyArgs} args - Arguments to create many VwPostoRecargas.
     * @example
     * // Create many VwPostoRecargas
     * const vwPostoRecarga = await prisma.vwPostoRecarga.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends VwPostoRecargaCreateManyArgs>(args?: SelectSubset<T, VwPostoRecargaCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Delete a VwPostoRecarga.
     * @param {VwPostoRecargaDeleteArgs} args - Arguments to delete one VwPostoRecarga.
     * @example
     * // Delete one VwPostoRecarga
     * const VwPostoRecarga = await prisma.vwPostoRecarga.delete({
     *   where: {
     *     // ... filter to delete one VwPostoRecarga
     *   }
     * })
     * 
     */
    delete<T extends VwPostoRecargaDeleteArgs>(args: SelectSubset<T, VwPostoRecargaDeleteArgs<ExtArgs>>): Prisma__VwPostoRecargaClient<$Result.GetResult<Prisma.$VwPostoRecargaPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one VwPostoRecarga.
     * @param {VwPostoRecargaUpdateArgs} args - Arguments to update one VwPostoRecarga.
     * @example
     * // Update one VwPostoRecarga
     * const vwPostoRecarga = await prisma.vwPostoRecarga.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends VwPostoRecargaUpdateArgs>(args: SelectSubset<T, VwPostoRecargaUpdateArgs<ExtArgs>>): Prisma__VwPostoRecargaClient<$Result.GetResult<Prisma.$VwPostoRecargaPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more VwPostoRecargas.
     * @param {VwPostoRecargaDeleteManyArgs} args - Arguments to filter VwPostoRecargas to delete.
     * @example
     * // Delete a few VwPostoRecargas
     * const { count } = await prisma.vwPostoRecarga.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends VwPostoRecargaDeleteManyArgs>(args?: SelectSubset<T, VwPostoRecargaDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more VwPostoRecargas.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwPostoRecargaUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many VwPostoRecargas
     * const vwPostoRecarga = await prisma.vwPostoRecarga.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends VwPostoRecargaUpdateManyArgs>(args: SelectSubset<T, VwPostoRecargaUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create or update one VwPostoRecarga.
     * @param {VwPostoRecargaUpsertArgs} args - Arguments to update or create a VwPostoRecarga.
     * @example
     * // Update or create a VwPostoRecarga
     * const vwPostoRecarga = await prisma.vwPostoRecarga.upsert({
     *   create: {
     *     // ... data to create a VwPostoRecarga
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the VwPostoRecarga we want to update
     *   }
     * })
     */
    upsert<T extends VwPostoRecargaUpsertArgs>(args: SelectSubset<T, VwPostoRecargaUpsertArgs<ExtArgs>>): Prisma__VwPostoRecargaClient<$Result.GetResult<Prisma.$VwPostoRecargaPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of VwPostoRecargas.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwPostoRecargaCountArgs} args - Arguments to filter VwPostoRecargas to count.
     * @example
     * // Count the number of VwPostoRecargas
     * const count = await prisma.vwPostoRecarga.count({
     *   where: {
     *     // ... the filter for the VwPostoRecargas we want to count
     *   }
     * })
    **/
    count<T extends VwPostoRecargaCountArgs>(
      args?: Subset<T, VwPostoRecargaCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], VwPostoRecargaCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a VwPostoRecarga.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwPostoRecargaAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends VwPostoRecargaAggregateArgs>(args: Subset<T, VwPostoRecargaAggregateArgs>): Prisma.PrismaPromise<GetVwPostoRecargaAggregateType<T>>

    /**
     * Group by VwPostoRecarga.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VwPostoRecargaGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends VwPostoRecargaGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: VwPostoRecargaGroupByArgs['orderBy'] }
        : { orderBy?: VwPostoRecargaGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, VwPostoRecargaGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetVwPostoRecargaGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the VwPostoRecarga model
   */
  readonly fields: VwPostoRecargaFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for VwPostoRecarga.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__VwPostoRecargaClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the VwPostoRecarga model
   */
  interface VwPostoRecargaFieldRefs {
    readonly UndId: FieldRef<"VwPostoRecarga", 'Int'>
    readonly PostoRecarga: FieldRef<"VwPostoRecarga", 'String'>
    readonly Latitude: FieldRef<"VwPostoRecarga", 'String'>
    readonly Longitude: FieldRef<"VwPostoRecarga", 'String'>
    readonly EqpItmId: FieldRef<"VwPostoRecarga", 'Int'>
    readonly Carregador: FieldRef<"VwPostoRecarga", 'String'>
  }
    

  // Custom InputTypes
  /**
   * VwPostoRecarga findUnique
   */
  export type VwPostoRecargaFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwPostoRecarga
     */
    select?: VwPostoRecargaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwPostoRecarga
     */
    omit?: VwPostoRecargaOmit<ExtArgs> | null
    /**
     * Filter, which VwPostoRecarga to fetch.
     */
    where: VwPostoRecargaWhereUniqueInput
  }

  /**
   * VwPostoRecarga findUniqueOrThrow
   */
  export type VwPostoRecargaFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwPostoRecarga
     */
    select?: VwPostoRecargaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwPostoRecarga
     */
    omit?: VwPostoRecargaOmit<ExtArgs> | null
    /**
     * Filter, which VwPostoRecarga to fetch.
     */
    where: VwPostoRecargaWhereUniqueInput
  }

  /**
   * VwPostoRecarga findFirst
   */
  export type VwPostoRecargaFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwPostoRecarga
     */
    select?: VwPostoRecargaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwPostoRecarga
     */
    omit?: VwPostoRecargaOmit<ExtArgs> | null
    /**
     * Filter, which VwPostoRecarga to fetch.
     */
    where?: VwPostoRecargaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VwPostoRecargas to fetch.
     */
    orderBy?: VwPostoRecargaOrderByWithRelationInput | VwPostoRecargaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for VwPostoRecargas.
     */
    cursor?: VwPostoRecargaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VwPostoRecargas from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VwPostoRecargas.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VwPostoRecargas.
     */
    distinct?: VwPostoRecargaScalarFieldEnum | VwPostoRecargaScalarFieldEnum[]
  }

  /**
   * VwPostoRecarga findFirstOrThrow
   */
  export type VwPostoRecargaFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwPostoRecarga
     */
    select?: VwPostoRecargaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwPostoRecarga
     */
    omit?: VwPostoRecargaOmit<ExtArgs> | null
    /**
     * Filter, which VwPostoRecarga to fetch.
     */
    where?: VwPostoRecargaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VwPostoRecargas to fetch.
     */
    orderBy?: VwPostoRecargaOrderByWithRelationInput | VwPostoRecargaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for VwPostoRecargas.
     */
    cursor?: VwPostoRecargaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VwPostoRecargas from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VwPostoRecargas.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VwPostoRecargas.
     */
    distinct?: VwPostoRecargaScalarFieldEnum | VwPostoRecargaScalarFieldEnum[]
  }

  /**
   * VwPostoRecarga findMany
   */
  export type VwPostoRecargaFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwPostoRecarga
     */
    select?: VwPostoRecargaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwPostoRecarga
     */
    omit?: VwPostoRecargaOmit<ExtArgs> | null
    /**
     * Filter, which VwPostoRecargas to fetch.
     */
    where?: VwPostoRecargaWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VwPostoRecargas to fetch.
     */
    orderBy?: VwPostoRecargaOrderByWithRelationInput | VwPostoRecargaOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing VwPostoRecargas.
     */
    cursor?: VwPostoRecargaWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VwPostoRecargas from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VwPostoRecargas.
     */
    skip?: number
    distinct?: VwPostoRecargaScalarFieldEnum | VwPostoRecargaScalarFieldEnum[]
  }

  /**
   * VwPostoRecarga create
   */
  export type VwPostoRecargaCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwPostoRecarga
     */
    select?: VwPostoRecargaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwPostoRecarga
     */
    omit?: VwPostoRecargaOmit<ExtArgs> | null
    /**
     * The data needed to create a VwPostoRecarga.
     */
    data: XOR<VwPostoRecargaCreateInput, VwPostoRecargaUncheckedCreateInput>
  }

  /**
   * VwPostoRecarga createMany
   */
  export type VwPostoRecargaCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many VwPostoRecargas.
     */
    data: VwPostoRecargaCreateManyInput | VwPostoRecargaCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * VwPostoRecarga update
   */
  export type VwPostoRecargaUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwPostoRecarga
     */
    select?: VwPostoRecargaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwPostoRecarga
     */
    omit?: VwPostoRecargaOmit<ExtArgs> | null
    /**
     * The data needed to update a VwPostoRecarga.
     */
    data: XOR<VwPostoRecargaUpdateInput, VwPostoRecargaUncheckedUpdateInput>
    /**
     * Choose, which VwPostoRecarga to update.
     */
    where: VwPostoRecargaWhereUniqueInput
  }

  /**
   * VwPostoRecarga updateMany
   */
  export type VwPostoRecargaUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update VwPostoRecargas.
     */
    data: XOR<VwPostoRecargaUpdateManyMutationInput, VwPostoRecargaUncheckedUpdateManyInput>
    /**
     * Filter which VwPostoRecargas to update
     */
    where?: VwPostoRecargaWhereInput
    /**
     * Limit how many VwPostoRecargas to update.
     */
    limit?: number
  }

  /**
   * VwPostoRecarga upsert
   */
  export type VwPostoRecargaUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwPostoRecarga
     */
    select?: VwPostoRecargaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwPostoRecarga
     */
    omit?: VwPostoRecargaOmit<ExtArgs> | null
    /**
     * The filter to search for the VwPostoRecarga to update in case it exists.
     */
    where: VwPostoRecargaWhereUniqueInput
    /**
     * In case the VwPostoRecarga found by the `where` argument doesn't exist, create a new VwPostoRecarga with this data.
     */
    create: XOR<VwPostoRecargaCreateInput, VwPostoRecargaUncheckedCreateInput>
    /**
     * In case the VwPostoRecarga was found with the provided `where` argument, update it with this data.
     */
    update: XOR<VwPostoRecargaUpdateInput, VwPostoRecargaUncheckedUpdateInput>
  }

  /**
   * VwPostoRecarga delete
   */
  export type VwPostoRecargaDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwPostoRecarga
     */
    select?: VwPostoRecargaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwPostoRecarga
     */
    omit?: VwPostoRecargaOmit<ExtArgs> | null
    /**
     * Filter which VwPostoRecarga to delete.
     */
    where: VwPostoRecargaWhereUniqueInput
  }

  /**
   * VwPostoRecarga deleteMany
   */
  export type VwPostoRecargaDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which VwPostoRecargas to delete
     */
    where?: VwPostoRecargaWhereInput
    /**
     * Limit how many VwPostoRecargas to delete.
     */
    limit?: number
  }

  /**
   * VwPostoRecarga without action
   */
  export type VwPostoRecargaDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VwPostoRecarga
     */
    select?: VwPostoRecargaSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VwPostoRecarga
     */
    omit?: VwPostoRecargaOmit<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const CbtScalarFieldEnum: {
    CbtId: 'CbtId',
    CbtNme: 'CbtNme',
    SttId: 'SttId',
    UsrIdAlt: 'UsrIdAlt',
    DtaAlt: 'DtaAlt',
    MtvDel: 'MtvDel'
  };

  export type CbtScalarFieldEnum = (typeof CbtScalarFieldEnum)[keyof typeof CbtScalarFieldEnum]


  export const EmpScalarFieldEnum: {
    EmpId: 'EmpId',
    EmpNme: 'EmpNme',
    EmpRaz: 'EmpRaz',
    EmpRdz: 'EmpRdz',
    EmpAtv: 'EmpAtv',
    EmpCnpj: 'EmpCnpj',
    Enduf: 'Enduf',
    EndCdd: 'EndCdd',
    EndLtt: 'EndLtt',
    EndLgt: 'EndLgt',
    EndCep: 'EndCep',
    EndEmp: 'EndEmp',
    EndCpl: 'EndCpl',
    EmpLgo: 'EmpLgo',
    EmpUrl: 'EmpUrl',
    EmlCtt: 'EmlCtt',
    EmlFrm: 'EmlFrm',
    EmlFrmPwd: 'EmlFrmPwd',
    FneCtt: 'FneCtt',
    FneWha: 'FneWha',
    RssIns: 'RssIns',
    RssFac: 'RssFac',
    RssTwi: 'RssTwi',
    RssYou: 'RssYou',
    TpoPix: 'TpoPix',
    ChvPix: 'ChvPix',
    QRPixImg: 'QRPixImg',
    QRPixCpy: 'QRPixCpy',
    SttId: 'SttId',
    UsrIdAlt: 'UsrIdAlt',
    DtaAlt: 'DtaAlt',
    MtvDel: 'MtvDel'
  };

  export type EmpScalarFieldEnum = (typeof EmpScalarFieldEnum)[keyof typeof EmpScalarFieldEnum]


  export const Emp_undScalarFieldEnum: {
    EmpId: 'EmpId',
    UndId: 'UndId',
    UndNme: 'UndNme',
    UndRdz: 'UndRdz',
    UndReg: 'UndReg',
    GpsLtd: 'GpsLtd',
    GpsLgt: 'GpsLgt',
    PstRcg: 'PstRcg',
    SttId: 'SttId',
    UsrIdAlt: 'UsrIdAlt',
    DtaAlt: 'DtaAlt',
    MtvDel: 'MtvDel'
  };

  export type Emp_undScalarFieldEnum = (typeof Emp_undScalarFieldEnum)[keyof typeof Emp_undScalarFieldEnum]


  export const Eqp_fbrScalarFieldEnum: {
    EqpFbrId: 'EqpFbrId',
    EqpFbrNme: 'EqpFbrNme',
    SttId: 'SttId',
    UsrIdAlt: 'UsrIdAlt',
    DtaAlt: 'DtaAlt',
    MtvDel: 'MtvDel'
  };

  export type Eqp_fbrScalarFieldEnum = (typeof Eqp_fbrScalarFieldEnum)[keyof typeof Eqp_fbrScalarFieldEnum]


  export const Eqp_itmScalarFieldEnum: {
    FrnId: 'FrnId',
    EqpTpoId: 'EqpTpoId',
    EqpFbrId: 'EqpFbrId',
    EqpMdlId: 'EqpMdlId',
    EqpItmId: 'EqpItmId',
    EqpItmCdg: 'EqpItmCdg',
    EqpItmPlc: 'EqpItmPlc',
    EqpItmAnoMdl: 'EqpItmAnoMdl',
    CbtId: 'CbtId',
    EqpItmTmh: 'EqpItmTmh',
    SttId: 'SttId',
    UsrIdAlt: 'UsrIdAlt',
    DtaAlt: 'DtaAlt',
    MtvDel: 'MtvDel'
  };

  export type Eqp_itmScalarFieldEnum = (typeof Eqp_itmScalarFieldEnum)[keyof typeof Eqp_itmScalarFieldEnum]


  export const Eqp_locScalarFieldEnum: {
    EqpTpoId: 'EqpTpoId',
    EqpItmId: 'EqpItmId',
    UndId: 'UndId',
    SttId: 'SttId',
    UsrIdAlt: 'UsrIdAlt',
    DtaAlt: 'DtaAlt',
    MtvDel: 'MtvDel'
  };

  export type Eqp_locScalarFieldEnum = (typeof Eqp_locScalarFieldEnum)[keyof typeof Eqp_locScalarFieldEnum]


  export const Eqp_mdlScalarFieldEnum: {
    EqpTpoId: 'EqpTpoId',
    EqpFbrId: 'EqpFbrId',
    EqpMdlId: 'EqpMdlId',
    EqpMdlNme: 'EqpMdlNme',
    SttId: 'SttId',
    UsrIdAlt: 'UsrIdAlt',
    DtaAlt: 'DtaAlt',
    MtvDel: 'MtvDel'
  };

  export type Eqp_mdlScalarFieldEnum = (typeof Eqp_mdlScalarFieldEnum)[keyof typeof Eqp_mdlScalarFieldEnum]


  export const Eqp_tpoScalarFieldEnum: {
    EqpTpoId: 'EqpTpoId',
    EqpTpoNme: 'EqpTpoNme',
    SttId: 'SttId',
    UsrIdAlt: 'UsrIdAlt',
    DtaAlt: 'DtaAlt',
    MtvDel: 'MtvDel'
  };

  export type Eqp_tpoScalarFieldEnum = (typeof Eqp_tpoScalarFieldEnum)[keyof typeof Eqp_tpoScalarFieldEnum]


  export const FrnScalarFieldEnum: {
    FrnId: 'FrnId',
    FrnNme: 'FrnNme',
    FrnRdz: 'FrnRdz',
    SttId: 'SttId',
    UsrIdAlt: 'UsrIdAlt',
    DtaAlt: 'DtaAlt',
    MtvDel: 'MtvDel'
  };

  export type FrnScalarFieldEnum = (typeof FrnScalarFieldEnum)[keyof typeof FrnScalarFieldEnum]


  export const RcgScalarFieldEnum: {
    RcgId: 'RcgId',
    RcgIdOrg: 'RcgIdOrg',
    EmpId: 'EmpId',
    DtaOpe: 'DtaOpe',
    UndId: 'UndId',
    VclId: 'VclId',
    CrrId: 'CrrId',
    CrrCnc: 'CrrCnc',
    DtaIni: 'DtaIni',
    DtaFin: 'DtaFin',
    SocIni: 'SocIni',
    SocFin: 'SocFin',
    RcgKwh: 'RcgKwh',
    OdoIni: 'OdoIni',
    OdoFin: 'OdoFin',
    SttRcgId: 'SttRcgId',
    FlhId: 'FlhId',
    FlhDsc: 'FlhDsc',
    SttId: 'SttId',
    UsrIdAlt: 'UsrIdAlt',
    DtaAlt: 'DtaAlt',
    MtvDel: 'MtvDel'
  };

  export type RcgScalarFieldEnum = (typeof RcgScalarFieldEnum)[keyof typeof RcgScalarFieldEnum]


  export const SttScalarFieldEnum: {
    SttId: 'SttId',
    SttNme: 'SttNme',
    SttIdAtu: 'SttIdAtu',
    UsrIdAlt: 'UsrIdAlt',
    DtaAlt: 'DtaAlt',
    MtvDel: 'MtvDel'
  };

  export type SttScalarFieldEnum = (typeof SttScalarFieldEnum)[keyof typeof SttScalarFieldEnum]


  export const UsrScalarFieldEnum: {
    EmpId: 'EmpId',
    UsrTpoId: 'UsrTpoId',
    UsrId: 'UsrId',
    UsrNme: 'UsrNme',
    UsrLgn: 'UsrLgn',
    UsrCpf: 'UsrCpf',
    UsrEml: 'UsrEml',
    UsrPwd: 'UsrPwd',
    UsrFto: 'UsrFto',
    SttId: 'SttId',
    UsrIdAlt: 'UsrIdAlt',
    DtaAlt: 'DtaAlt',
    MtvDel: 'MtvDel'
  };

  export type UsrScalarFieldEnum = (typeof UsrScalarFieldEnum)[keyof typeof UsrScalarFieldEnum]


  export const Usr_tpoScalarFieldEnum: {
    UsrTpoId: 'UsrTpoId',
    UsrTpoNme: 'UsrTpoNme',
    SttId: 'SttId',
    UsrIdAlt: 'UsrIdAlt',
    DtaAlt: 'DtaAlt',
    MtvDel: 'MtvDel'
  };

  export type Usr_tpoScalarFieldEnum = (typeof Usr_tpoScalarFieldEnum)[keyof typeof Usr_tpoScalarFieldEnum]


  export const VwCarregadorScalarFieldEnum: {
    UndId: 'UndId',
    EqpItmId: 'EqpItmId',
    Carregador: 'Carregador'
  };

  export type VwCarregadorScalarFieldEnum = (typeof VwCarregadorScalarFieldEnum)[keyof typeof VwCarregadorScalarFieldEnum]


  export const VwOnibusScalarFieldEnum: {
    EqpItmId: 'EqpItmId',
    Onibus: 'Onibus',
    Situacao: 'Situacao'
  };

  export type VwOnibusScalarFieldEnum = (typeof VwOnibusScalarFieldEnum)[keyof typeof VwOnibusScalarFieldEnum]


  export const VwPostoRecargaScalarFieldEnum: {
    UndId: 'UndId',
    PostoRecarga: 'PostoRecarga',
    Latitude: 'Latitude',
    Longitude: 'Longitude',
    EqpItmId: 'EqpItmId',
    Carregador: 'Carregador'
  };

  export type VwPostoRecargaScalarFieldEnum = (typeof VwPostoRecargaScalarFieldEnum)[keyof typeof VwPostoRecargaScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  export const cbtOrderByRelevanceFieldEnum: {
    CbtNme: 'CbtNme',
    MtvDel: 'MtvDel'
  };

  export type cbtOrderByRelevanceFieldEnum = (typeof cbtOrderByRelevanceFieldEnum)[keyof typeof cbtOrderByRelevanceFieldEnum]


  export const empOrderByRelevanceFieldEnum: {
    EmpNme: 'EmpNme',
    EmpRaz: 'EmpRaz',
    EmpRdz: 'EmpRdz',
    EmpAtv: 'EmpAtv',
    EmpCnpj: 'EmpCnpj',
    Enduf: 'Enduf',
    EndCdd: 'EndCdd',
    EndLtt: 'EndLtt',
    EndLgt: 'EndLgt',
    EndCep: 'EndCep',
    EndEmp: 'EndEmp',
    EndCpl: 'EndCpl',
    EmpLgo: 'EmpLgo',
    EmpUrl: 'EmpUrl',
    EmlCtt: 'EmlCtt',
    EmlFrm: 'EmlFrm',
    EmlFrmPwd: 'EmlFrmPwd',
    FneCtt: 'FneCtt',
    FneWha: 'FneWha',
    RssIns: 'RssIns',
    RssFac: 'RssFac',
    RssTwi: 'RssTwi',
    RssYou: 'RssYou',
    TpoPix: 'TpoPix',
    ChvPix: 'ChvPix',
    QRPixImg: 'QRPixImg',
    QRPixCpy: 'QRPixCpy',
    MtvDel: 'MtvDel'
  };

  export type empOrderByRelevanceFieldEnum = (typeof empOrderByRelevanceFieldEnum)[keyof typeof empOrderByRelevanceFieldEnum]


  export const emp_undOrderByRelevanceFieldEnum: {
    UndNme: 'UndNme',
    UndRdz: 'UndRdz',
    UndReg: 'UndReg',
    GpsLtd: 'GpsLtd',
    GpsLgt: 'GpsLgt',
    MtvDel: 'MtvDel'
  };

  export type emp_undOrderByRelevanceFieldEnum = (typeof emp_undOrderByRelevanceFieldEnum)[keyof typeof emp_undOrderByRelevanceFieldEnum]


  export const eqp_fbrOrderByRelevanceFieldEnum: {
    EqpFbrNme: 'EqpFbrNme',
    MtvDel: 'MtvDel'
  };

  export type eqp_fbrOrderByRelevanceFieldEnum = (typeof eqp_fbrOrderByRelevanceFieldEnum)[keyof typeof eqp_fbrOrderByRelevanceFieldEnum]


  export const eqp_itmOrderByRelevanceFieldEnum: {
    EqpItmCdg: 'EqpItmCdg',
    EqpItmPlc: 'EqpItmPlc',
    EqpItmAnoMdl: 'EqpItmAnoMdl',
    EqpItmTmh: 'EqpItmTmh',
    MtvDel: 'MtvDel'
  };

  export type eqp_itmOrderByRelevanceFieldEnum = (typeof eqp_itmOrderByRelevanceFieldEnum)[keyof typeof eqp_itmOrderByRelevanceFieldEnum]


  export const eqp_locOrderByRelevanceFieldEnum: {
    MtvDel: 'MtvDel'
  };

  export type eqp_locOrderByRelevanceFieldEnum = (typeof eqp_locOrderByRelevanceFieldEnum)[keyof typeof eqp_locOrderByRelevanceFieldEnum]


  export const eqp_mdlOrderByRelevanceFieldEnum: {
    EqpMdlNme: 'EqpMdlNme',
    MtvDel: 'MtvDel'
  };

  export type eqp_mdlOrderByRelevanceFieldEnum = (typeof eqp_mdlOrderByRelevanceFieldEnum)[keyof typeof eqp_mdlOrderByRelevanceFieldEnum]


  export const eqp_tpoOrderByRelevanceFieldEnum: {
    EqpTpoNme: 'EqpTpoNme',
    MtvDel: 'MtvDel'
  };

  export type eqp_tpoOrderByRelevanceFieldEnum = (typeof eqp_tpoOrderByRelevanceFieldEnum)[keyof typeof eqp_tpoOrderByRelevanceFieldEnum]


  export const frnOrderByRelevanceFieldEnum: {
    FrnNme: 'FrnNme',
    FrnRdz: 'FrnRdz',
    MtvDel: 'MtvDel'
  };

  export type frnOrderByRelevanceFieldEnum = (typeof frnOrderByRelevanceFieldEnum)[keyof typeof frnOrderByRelevanceFieldEnum]


  export const rcgOrderByRelevanceFieldEnum: {
    FlhDsc: 'FlhDsc',
    MtvDel: 'MtvDel'
  };

  export type rcgOrderByRelevanceFieldEnum = (typeof rcgOrderByRelevanceFieldEnum)[keyof typeof rcgOrderByRelevanceFieldEnum]


  export const sttOrderByRelevanceFieldEnum: {
    SttNme: 'SttNme',
    MtvDel: 'MtvDel'
  };

  export type sttOrderByRelevanceFieldEnum = (typeof sttOrderByRelevanceFieldEnum)[keyof typeof sttOrderByRelevanceFieldEnum]


  export const usrOrderByRelevanceFieldEnum: {
    UsrNme: 'UsrNme',
    UsrLgn: 'UsrLgn',
    UsrCpf: 'UsrCpf',
    UsrEml: 'UsrEml',
    UsrPwd: 'UsrPwd',
    UsrFto: 'UsrFto',
    MtvDel: 'MtvDel'
  };

  export type usrOrderByRelevanceFieldEnum = (typeof usrOrderByRelevanceFieldEnum)[keyof typeof usrOrderByRelevanceFieldEnum]


  export const usr_tpoOrderByRelevanceFieldEnum: {
    UsrTpoNme: 'UsrTpoNme',
    MtvDel: 'MtvDel'
  };

  export type usr_tpoOrderByRelevanceFieldEnum = (typeof usr_tpoOrderByRelevanceFieldEnum)[keyof typeof usr_tpoOrderByRelevanceFieldEnum]


  export const VwCarregadorOrderByRelevanceFieldEnum: {
    Carregador: 'Carregador'
  };

  export type VwCarregadorOrderByRelevanceFieldEnum = (typeof VwCarregadorOrderByRelevanceFieldEnum)[keyof typeof VwCarregadorOrderByRelevanceFieldEnum]


  export const VwOnibusOrderByRelevanceFieldEnum: {
    Onibus: 'Onibus',
    Situacao: 'Situacao'
  };

  export type VwOnibusOrderByRelevanceFieldEnum = (typeof VwOnibusOrderByRelevanceFieldEnum)[keyof typeof VwOnibusOrderByRelevanceFieldEnum]


  export const VwPostoRecargaOrderByRelevanceFieldEnum: {
    PostoRecarga: 'PostoRecarga',
    Latitude: 'Latitude',
    Longitude: 'Longitude',
    Carregador: 'Carregador'
  };

  export type VwPostoRecargaOrderByRelevanceFieldEnum = (typeof VwPostoRecargaOrderByRelevanceFieldEnum)[keyof typeof VwPostoRecargaOrderByRelevanceFieldEnum]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    
  /**
   * Deep Input Types
   */


  export type cbtWhereInput = {
    AND?: cbtWhereInput | cbtWhereInput[]
    OR?: cbtWhereInput[]
    NOT?: cbtWhereInput | cbtWhereInput[]
    CbtId?: IntFilter<"cbt"> | number
    CbtNme?: StringFilter<"cbt"> | string
    SttId?: IntFilter<"cbt"> | number
    UsrIdAlt?: IntFilter<"cbt"> | number
    DtaAlt?: DateTimeFilter<"cbt"> | Date | string
    MtvDel?: StringNullableFilter<"cbt"> | string | null
  }

  export type cbtOrderByWithRelationInput = {
    CbtId?: SortOrder
    CbtNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _relevance?: cbtOrderByRelevanceInput
  }

  export type cbtWhereUniqueInput = Prisma.AtLeast<{
    CbtId?: number
    AND?: cbtWhereInput | cbtWhereInput[]
    OR?: cbtWhereInput[]
    NOT?: cbtWhereInput | cbtWhereInput[]
    CbtNme?: StringFilter<"cbt"> | string
    SttId?: IntFilter<"cbt"> | number
    UsrIdAlt?: IntFilter<"cbt"> | number
    DtaAlt?: DateTimeFilter<"cbt"> | Date | string
    MtvDel?: StringNullableFilter<"cbt"> | string | null
  }, "CbtId">

  export type cbtOrderByWithAggregationInput = {
    CbtId?: SortOrder
    CbtNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _count?: cbtCountOrderByAggregateInput
    _avg?: cbtAvgOrderByAggregateInput
    _max?: cbtMaxOrderByAggregateInput
    _min?: cbtMinOrderByAggregateInput
    _sum?: cbtSumOrderByAggregateInput
  }

  export type cbtScalarWhereWithAggregatesInput = {
    AND?: cbtScalarWhereWithAggregatesInput | cbtScalarWhereWithAggregatesInput[]
    OR?: cbtScalarWhereWithAggregatesInput[]
    NOT?: cbtScalarWhereWithAggregatesInput | cbtScalarWhereWithAggregatesInput[]
    CbtId?: IntWithAggregatesFilter<"cbt"> | number
    CbtNme?: StringWithAggregatesFilter<"cbt"> | string
    SttId?: IntWithAggregatesFilter<"cbt"> | number
    UsrIdAlt?: IntWithAggregatesFilter<"cbt"> | number
    DtaAlt?: DateTimeWithAggregatesFilter<"cbt"> | Date | string
    MtvDel?: StringNullableWithAggregatesFilter<"cbt"> | string | null
  }

  export type empWhereInput = {
    AND?: empWhereInput | empWhereInput[]
    OR?: empWhereInput[]
    NOT?: empWhereInput | empWhereInput[]
    EmpId?: IntFilter<"emp"> | number
    EmpNme?: StringFilter<"emp"> | string
    EmpRaz?: StringNullableFilter<"emp"> | string | null
    EmpRdz?: StringNullableFilter<"emp"> | string | null
    EmpAtv?: StringNullableFilter<"emp"> | string | null
    EmpCnpj?: StringNullableFilter<"emp"> | string | null
    Enduf?: StringNullableFilter<"emp"> | string | null
    EndCdd?: StringNullableFilter<"emp"> | string | null
    EndLtt?: StringNullableFilter<"emp"> | string | null
    EndLgt?: StringNullableFilter<"emp"> | string | null
    EndCep?: StringNullableFilter<"emp"> | string | null
    EndEmp?: StringNullableFilter<"emp"> | string | null
    EndCpl?: StringNullableFilter<"emp"> | string | null
    EmpLgo?: StringNullableFilter<"emp"> | string | null
    EmpUrl?: StringNullableFilter<"emp"> | string | null
    EmlCtt?: StringNullableFilter<"emp"> | string | null
    EmlFrm?: StringNullableFilter<"emp"> | string | null
    EmlFrmPwd?: StringNullableFilter<"emp"> | string | null
    FneCtt?: StringNullableFilter<"emp"> | string | null
    FneWha?: StringNullableFilter<"emp"> | string | null
    RssIns?: StringNullableFilter<"emp"> | string | null
    RssFac?: StringNullableFilter<"emp"> | string | null
    RssTwi?: StringNullableFilter<"emp"> | string | null
    RssYou?: StringNullableFilter<"emp"> | string | null
    TpoPix?: StringNullableFilter<"emp"> | string | null
    ChvPix?: StringNullableFilter<"emp"> | string | null
    QRPixImg?: StringNullableFilter<"emp"> | string | null
    QRPixCpy?: StringNullableFilter<"emp"> | string | null
    SttId?: IntFilter<"emp"> | number
    UsrIdAlt?: IntFilter<"emp"> | number
    DtaAlt?: DateTimeFilter<"emp"> | Date | string
    MtvDel?: StringNullableFilter<"emp"> | string | null
  }

  export type empOrderByWithRelationInput = {
    EmpId?: SortOrder
    EmpNme?: SortOrder
    EmpRaz?: SortOrderInput | SortOrder
    EmpRdz?: SortOrderInput | SortOrder
    EmpAtv?: SortOrderInput | SortOrder
    EmpCnpj?: SortOrderInput | SortOrder
    Enduf?: SortOrderInput | SortOrder
    EndCdd?: SortOrderInput | SortOrder
    EndLtt?: SortOrderInput | SortOrder
    EndLgt?: SortOrderInput | SortOrder
    EndCep?: SortOrderInput | SortOrder
    EndEmp?: SortOrderInput | SortOrder
    EndCpl?: SortOrderInput | SortOrder
    EmpLgo?: SortOrderInput | SortOrder
    EmpUrl?: SortOrderInput | SortOrder
    EmlCtt?: SortOrderInput | SortOrder
    EmlFrm?: SortOrderInput | SortOrder
    EmlFrmPwd?: SortOrderInput | SortOrder
    FneCtt?: SortOrderInput | SortOrder
    FneWha?: SortOrderInput | SortOrder
    RssIns?: SortOrderInput | SortOrder
    RssFac?: SortOrderInput | SortOrder
    RssTwi?: SortOrderInput | SortOrder
    RssYou?: SortOrderInput | SortOrder
    TpoPix?: SortOrderInput | SortOrder
    ChvPix?: SortOrderInput | SortOrder
    QRPixImg?: SortOrderInput | SortOrder
    QRPixCpy?: SortOrderInput | SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _relevance?: empOrderByRelevanceInput
  }

  export type empWhereUniqueInput = Prisma.AtLeast<{
    EmpId?: number
    AND?: empWhereInput | empWhereInput[]
    OR?: empWhereInput[]
    NOT?: empWhereInput | empWhereInput[]
    EmpNme?: StringFilter<"emp"> | string
    EmpRaz?: StringNullableFilter<"emp"> | string | null
    EmpRdz?: StringNullableFilter<"emp"> | string | null
    EmpAtv?: StringNullableFilter<"emp"> | string | null
    EmpCnpj?: StringNullableFilter<"emp"> | string | null
    Enduf?: StringNullableFilter<"emp"> | string | null
    EndCdd?: StringNullableFilter<"emp"> | string | null
    EndLtt?: StringNullableFilter<"emp"> | string | null
    EndLgt?: StringNullableFilter<"emp"> | string | null
    EndCep?: StringNullableFilter<"emp"> | string | null
    EndEmp?: StringNullableFilter<"emp"> | string | null
    EndCpl?: StringNullableFilter<"emp"> | string | null
    EmpLgo?: StringNullableFilter<"emp"> | string | null
    EmpUrl?: StringNullableFilter<"emp"> | string | null
    EmlCtt?: StringNullableFilter<"emp"> | string | null
    EmlFrm?: StringNullableFilter<"emp"> | string | null
    EmlFrmPwd?: StringNullableFilter<"emp"> | string | null
    FneCtt?: StringNullableFilter<"emp"> | string | null
    FneWha?: StringNullableFilter<"emp"> | string | null
    RssIns?: StringNullableFilter<"emp"> | string | null
    RssFac?: StringNullableFilter<"emp"> | string | null
    RssTwi?: StringNullableFilter<"emp"> | string | null
    RssYou?: StringNullableFilter<"emp"> | string | null
    TpoPix?: StringNullableFilter<"emp"> | string | null
    ChvPix?: StringNullableFilter<"emp"> | string | null
    QRPixImg?: StringNullableFilter<"emp"> | string | null
    QRPixCpy?: StringNullableFilter<"emp"> | string | null
    SttId?: IntFilter<"emp"> | number
    UsrIdAlt?: IntFilter<"emp"> | number
    DtaAlt?: DateTimeFilter<"emp"> | Date | string
    MtvDel?: StringNullableFilter<"emp"> | string | null
  }, "EmpId">

  export type empOrderByWithAggregationInput = {
    EmpId?: SortOrder
    EmpNme?: SortOrder
    EmpRaz?: SortOrderInput | SortOrder
    EmpRdz?: SortOrderInput | SortOrder
    EmpAtv?: SortOrderInput | SortOrder
    EmpCnpj?: SortOrderInput | SortOrder
    Enduf?: SortOrderInput | SortOrder
    EndCdd?: SortOrderInput | SortOrder
    EndLtt?: SortOrderInput | SortOrder
    EndLgt?: SortOrderInput | SortOrder
    EndCep?: SortOrderInput | SortOrder
    EndEmp?: SortOrderInput | SortOrder
    EndCpl?: SortOrderInput | SortOrder
    EmpLgo?: SortOrderInput | SortOrder
    EmpUrl?: SortOrderInput | SortOrder
    EmlCtt?: SortOrderInput | SortOrder
    EmlFrm?: SortOrderInput | SortOrder
    EmlFrmPwd?: SortOrderInput | SortOrder
    FneCtt?: SortOrderInput | SortOrder
    FneWha?: SortOrderInput | SortOrder
    RssIns?: SortOrderInput | SortOrder
    RssFac?: SortOrderInput | SortOrder
    RssTwi?: SortOrderInput | SortOrder
    RssYou?: SortOrderInput | SortOrder
    TpoPix?: SortOrderInput | SortOrder
    ChvPix?: SortOrderInput | SortOrder
    QRPixImg?: SortOrderInput | SortOrder
    QRPixCpy?: SortOrderInput | SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _count?: empCountOrderByAggregateInput
    _avg?: empAvgOrderByAggregateInput
    _max?: empMaxOrderByAggregateInput
    _min?: empMinOrderByAggregateInput
    _sum?: empSumOrderByAggregateInput
  }

  export type empScalarWhereWithAggregatesInput = {
    AND?: empScalarWhereWithAggregatesInput | empScalarWhereWithAggregatesInput[]
    OR?: empScalarWhereWithAggregatesInput[]
    NOT?: empScalarWhereWithAggregatesInput | empScalarWhereWithAggregatesInput[]
    EmpId?: IntWithAggregatesFilter<"emp"> | number
    EmpNme?: StringWithAggregatesFilter<"emp"> | string
    EmpRaz?: StringNullableWithAggregatesFilter<"emp"> | string | null
    EmpRdz?: StringNullableWithAggregatesFilter<"emp"> | string | null
    EmpAtv?: StringNullableWithAggregatesFilter<"emp"> | string | null
    EmpCnpj?: StringNullableWithAggregatesFilter<"emp"> | string | null
    Enduf?: StringNullableWithAggregatesFilter<"emp"> | string | null
    EndCdd?: StringNullableWithAggregatesFilter<"emp"> | string | null
    EndLtt?: StringNullableWithAggregatesFilter<"emp"> | string | null
    EndLgt?: StringNullableWithAggregatesFilter<"emp"> | string | null
    EndCep?: StringNullableWithAggregatesFilter<"emp"> | string | null
    EndEmp?: StringNullableWithAggregatesFilter<"emp"> | string | null
    EndCpl?: StringNullableWithAggregatesFilter<"emp"> | string | null
    EmpLgo?: StringNullableWithAggregatesFilter<"emp"> | string | null
    EmpUrl?: StringNullableWithAggregatesFilter<"emp"> | string | null
    EmlCtt?: StringNullableWithAggregatesFilter<"emp"> | string | null
    EmlFrm?: StringNullableWithAggregatesFilter<"emp"> | string | null
    EmlFrmPwd?: StringNullableWithAggregatesFilter<"emp"> | string | null
    FneCtt?: StringNullableWithAggregatesFilter<"emp"> | string | null
    FneWha?: StringNullableWithAggregatesFilter<"emp"> | string | null
    RssIns?: StringNullableWithAggregatesFilter<"emp"> | string | null
    RssFac?: StringNullableWithAggregatesFilter<"emp"> | string | null
    RssTwi?: StringNullableWithAggregatesFilter<"emp"> | string | null
    RssYou?: StringNullableWithAggregatesFilter<"emp"> | string | null
    TpoPix?: StringNullableWithAggregatesFilter<"emp"> | string | null
    ChvPix?: StringNullableWithAggregatesFilter<"emp"> | string | null
    QRPixImg?: StringNullableWithAggregatesFilter<"emp"> | string | null
    QRPixCpy?: StringNullableWithAggregatesFilter<"emp"> | string | null
    SttId?: IntWithAggregatesFilter<"emp"> | number
    UsrIdAlt?: IntWithAggregatesFilter<"emp"> | number
    DtaAlt?: DateTimeWithAggregatesFilter<"emp"> | Date | string
    MtvDel?: StringNullableWithAggregatesFilter<"emp"> | string | null
  }

  export type emp_undWhereInput = {
    AND?: emp_undWhereInput | emp_undWhereInput[]
    OR?: emp_undWhereInput[]
    NOT?: emp_undWhereInput | emp_undWhereInput[]
    EmpId?: IntFilter<"emp_und"> | number
    UndId?: IntFilter<"emp_und"> | number
    UndNme?: StringFilter<"emp_und"> | string
    UndRdz?: StringNullableFilter<"emp_und"> | string | null
    UndReg?: StringNullableFilter<"emp_und"> | string | null
    GpsLtd?: StringNullableFilter<"emp_und"> | string | null
    GpsLgt?: StringNullableFilter<"emp_und"> | string | null
    PstRcg?: IntNullableFilter<"emp_und"> | number | null
    SttId?: IntFilter<"emp_und"> | number
    UsrIdAlt?: IntFilter<"emp_und"> | number
    DtaAlt?: DateTimeFilter<"emp_und"> | Date | string
    MtvDel?: StringNullableFilter<"emp_und"> | string | null
  }

  export type emp_undOrderByWithRelationInput = {
    EmpId?: SortOrder
    UndId?: SortOrder
    UndNme?: SortOrder
    UndRdz?: SortOrderInput | SortOrder
    UndReg?: SortOrderInput | SortOrder
    GpsLtd?: SortOrderInput | SortOrder
    GpsLgt?: SortOrderInput | SortOrder
    PstRcg?: SortOrderInput | SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _relevance?: emp_undOrderByRelevanceInput
  }

  export type emp_undWhereUniqueInput = Prisma.AtLeast<{
    UndId?: number
    AND?: emp_undWhereInput | emp_undWhereInput[]
    OR?: emp_undWhereInput[]
    NOT?: emp_undWhereInput | emp_undWhereInput[]
    EmpId?: IntFilter<"emp_und"> | number
    UndNme?: StringFilter<"emp_und"> | string
    UndRdz?: StringNullableFilter<"emp_und"> | string | null
    UndReg?: StringNullableFilter<"emp_und"> | string | null
    GpsLtd?: StringNullableFilter<"emp_und"> | string | null
    GpsLgt?: StringNullableFilter<"emp_und"> | string | null
    PstRcg?: IntNullableFilter<"emp_und"> | number | null
    SttId?: IntFilter<"emp_und"> | number
    UsrIdAlt?: IntFilter<"emp_und"> | number
    DtaAlt?: DateTimeFilter<"emp_und"> | Date | string
    MtvDel?: StringNullableFilter<"emp_und"> | string | null
  }, "UndId">

  export type emp_undOrderByWithAggregationInput = {
    EmpId?: SortOrder
    UndId?: SortOrder
    UndNme?: SortOrder
    UndRdz?: SortOrderInput | SortOrder
    UndReg?: SortOrderInput | SortOrder
    GpsLtd?: SortOrderInput | SortOrder
    GpsLgt?: SortOrderInput | SortOrder
    PstRcg?: SortOrderInput | SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _count?: emp_undCountOrderByAggregateInput
    _avg?: emp_undAvgOrderByAggregateInput
    _max?: emp_undMaxOrderByAggregateInput
    _min?: emp_undMinOrderByAggregateInput
    _sum?: emp_undSumOrderByAggregateInput
  }

  export type emp_undScalarWhereWithAggregatesInput = {
    AND?: emp_undScalarWhereWithAggregatesInput | emp_undScalarWhereWithAggregatesInput[]
    OR?: emp_undScalarWhereWithAggregatesInput[]
    NOT?: emp_undScalarWhereWithAggregatesInput | emp_undScalarWhereWithAggregatesInput[]
    EmpId?: IntWithAggregatesFilter<"emp_und"> | number
    UndId?: IntWithAggregatesFilter<"emp_und"> | number
    UndNme?: StringWithAggregatesFilter<"emp_und"> | string
    UndRdz?: StringNullableWithAggregatesFilter<"emp_und"> | string | null
    UndReg?: StringNullableWithAggregatesFilter<"emp_und"> | string | null
    GpsLtd?: StringNullableWithAggregatesFilter<"emp_und"> | string | null
    GpsLgt?: StringNullableWithAggregatesFilter<"emp_und"> | string | null
    PstRcg?: IntNullableWithAggregatesFilter<"emp_und"> | number | null
    SttId?: IntWithAggregatesFilter<"emp_und"> | number
    UsrIdAlt?: IntWithAggregatesFilter<"emp_und"> | number
    DtaAlt?: DateTimeWithAggregatesFilter<"emp_und"> | Date | string
    MtvDel?: StringNullableWithAggregatesFilter<"emp_und"> | string | null
  }

  export type eqp_fbrWhereInput = {
    AND?: eqp_fbrWhereInput | eqp_fbrWhereInput[]
    OR?: eqp_fbrWhereInput[]
    NOT?: eqp_fbrWhereInput | eqp_fbrWhereInput[]
    EqpFbrId?: IntFilter<"eqp_fbr"> | number
    EqpFbrNme?: StringFilter<"eqp_fbr"> | string
    SttId?: IntFilter<"eqp_fbr"> | number
    UsrIdAlt?: IntFilter<"eqp_fbr"> | number
    DtaAlt?: DateTimeFilter<"eqp_fbr"> | Date | string
    MtvDel?: StringNullableFilter<"eqp_fbr"> | string | null
  }

  export type eqp_fbrOrderByWithRelationInput = {
    EqpFbrId?: SortOrder
    EqpFbrNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _relevance?: eqp_fbrOrderByRelevanceInput
  }

  export type eqp_fbrWhereUniqueInput = Prisma.AtLeast<{
    EqpFbrId?: number
    AND?: eqp_fbrWhereInput | eqp_fbrWhereInput[]
    OR?: eqp_fbrWhereInput[]
    NOT?: eqp_fbrWhereInput | eqp_fbrWhereInput[]
    EqpFbrNme?: StringFilter<"eqp_fbr"> | string
    SttId?: IntFilter<"eqp_fbr"> | number
    UsrIdAlt?: IntFilter<"eqp_fbr"> | number
    DtaAlt?: DateTimeFilter<"eqp_fbr"> | Date | string
    MtvDel?: StringNullableFilter<"eqp_fbr"> | string | null
  }, "EqpFbrId">

  export type eqp_fbrOrderByWithAggregationInput = {
    EqpFbrId?: SortOrder
    EqpFbrNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _count?: eqp_fbrCountOrderByAggregateInput
    _avg?: eqp_fbrAvgOrderByAggregateInput
    _max?: eqp_fbrMaxOrderByAggregateInput
    _min?: eqp_fbrMinOrderByAggregateInput
    _sum?: eqp_fbrSumOrderByAggregateInput
  }

  export type eqp_fbrScalarWhereWithAggregatesInput = {
    AND?: eqp_fbrScalarWhereWithAggregatesInput | eqp_fbrScalarWhereWithAggregatesInput[]
    OR?: eqp_fbrScalarWhereWithAggregatesInput[]
    NOT?: eqp_fbrScalarWhereWithAggregatesInput | eqp_fbrScalarWhereWithAggregatesInput[]
    EqpFbrId?: IntWithAggregatesFilter<"eqp_fbr"> | number
    EqpFbrNme?: StringWithAggregatesFilter<"eqp_fbr"> | string
    SttId?: IntWithAggregatesFilter<"eqp_fbr"> | number
    UsrIdAlt?: IntWithAggregatesFilter<"eqp_fbr"> | number
    DtaAlt?: DateTimeWithAggregatesFilter<"eqp_fbr"> | Date | string
    MtvDel?: StringNullableWithAggregatesFilter<"eqp_fbr"> | string | null
  }

  export type eqp_itmWhereInput = {
    AND?: eqp_itmWhereInput | eqp_itmWhereInput[]
    OR?: eqp_itmWhereInput[]
    NOT?: eqp_itmWhereInput | eqp_itmWhereInput[]
    FrnId?: IntFilter<"eqp_itm"> | number
    EqpTpoId?: IntFilter<"eqp_itm"> | number
    EqpFbrId?: IntFilter<"eqp_itm"> | number
    EqpMdlId?: IntFilter<"eqp_itm"> | number
    EqpItmId?: IntFilter<"eqp_itm"> | number
    EqpItmCdg?: StringFilter<"eqp_itm"> | string
    EqpItmPlc?: StringNullableFilter<"eqp_itm"> | string | null
    EqpItmAnoMdl?: StringNullableFilter<"eqp_itm"> | string | null
    CbtId?: IntFilter<"eqp_itm"> | number
    EqpItmTmh?: StringFilter<"eqp_itm"> | string
    SttId?: IntFilter<"eqp_itm"> | number
    UsrIdAlt?: IntFilter<"eqp_itm"> | number
    DtaAlt?: DateTimeFilter<"eqp_itm"> | Date | string
    MtvDel?: StringNullableFilter<"eqp_itm"> | string | null
  }

  export type eqp_itmOrderByWithRelationInput = {
    FrnId?: SortOrder
    EqpTpoId?: SortOrder
    EqpFbrId?: SortOrder
    EqpMdlId?: SortOrder
    EqpItmId?: SortOrder
    EqpItmCdg?: SortOrder
    EqpItmPlc?: SortOrderInput | SortOrder
    EqpItmAnoMdl?: SortOrderInput | SortOrder
    CbtId?: SortOrder
    EqpItmTmh?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _relevance?: eqp_itmOrderByRelevanceInput
  }

  export type eqp_itmWhereUniqueInput = Prisma.AtLeast<{
    EqpItmId?: number
    AND?: eqp_itmWhereInput | eqp_itmWhereInput[]
    OR?: eqp_itmWhereInput[]
    NOT?: eqp_itmWhereInput | eqp_itmWhereInput[]
    FrnId?: IntFilter<"eqp_itm"> | number
    EqpTpoId?: IntFilter<"eqp_itm"> | number
    EqpFbrId?: IntFilter<"eqp_itm"> | number
    EqpMdlId?: IntFilter<"eqp_itm"> | number
    EqpItmCdg?: StringFilter<"eqp_itm"> | string
    EqpItmPlc?: StringNullableFilter<"eqp_itm"> | string | null
    EqpItmAnoMdl?: StringNullableFilter<"eqp_itm"> | string | null
    CbtId?: IntFilter<"eqp_itm"> | number
    EqpItmTmh?: StringFilter<"eqp_itm"> | string
    SttId?: IntFilter<"eqp_itm"> | number
    UsrIdAlt?: IntFilter<"eqp_itm"> | number
    DtaAlt?: DateTimeFilter<"eqp_itm"> | Date | string
    MtvDel?: StringNullableFilter<"eqp_itm"> | string | null
  }, "EqpItmId">

  export type eqp_itmOrderByWithAggregationInput = {
    FrnId?: SortOrder
    EqpTpoId?: SortOrder
    EqpFbrId?: SortOrder
    EqpMdlId?: SortOrder
    EqpItmId?: SortOrder
    EqpItmCdg?: SortOrder
    EqpItmPlc?: SortOrderInput | SortOrder
    EqpItmAnoMdl?: SortOrderInput | SortOrder
    CbtId?: SortOrder
    EqpItmTmh?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _count?: eqp_itmCountOrderByAggregateInput
    _avg?: eqp_itmAvgOrderByAggregateInput
    _max?: eqp_itmMaxOrderByAggregateInput
    _min?: eqp_itmMinOrderByAggregateInput
    _sum?: eqp_itmSumOrderByAggregateInput
  }

  export type eqp_itmScalarWhereWithAggregatesInput = {
    AND?: eqp_itmScalarWhereWithAggregatesInput | eqp_itmScalarWhereWithAggregatesInput[]
    OR?: eqp_itmScalarWhereWithAggregatesInput[]
    NOT?: eqp_itmScalarWhereWithAggregatesInput | eqp_itmScalarWhereWithAggregatesInput[]
    FrnId?: IntWithAggregatesFilter<"eqp_itm"> | number
    EqpTpoId?: IntWithAggregatesFilter<"eqp_itm"> | number
    EqpFbrId?: IntWithAggregatesFilter<"eqp_itm"> | number
    EqpMdlId?: IntWithAggregatesFilter<"eqp_itm"> | number
    EqpItmId?: IntWithAggregatesFilter<"eqp_itm"> | number
    EqpItmCdg?: StringWithAggregatesFilter<"eqp_itm"> | string
    EqpItmPlc?: StringNullableWithAggregatesFilter<"eqp_itm"> | string | null
    EqpItmAnoMdl?: StringNullableWithAggregatesFilter<"eqp_itm"> | string | null
    CbtId?: IntWithAggregatesFilter<"eqp_itm"> | number
    EqpItmTmh?: StringWithAggregatesFilter<"eqp_itm"> | string
    SttId?: IntWithAggregatesFilter<"eqp_itm"> | number
    UsrIdAlt?: IntWithAggregatesFilter<"eqp_itm"> | number
    DtaAlt?: DateTimeWithAggregatesFilter<"eqp_itm"> | Date | string
    MtvDel?: StringNullableWithAggregatesFilter<"eqp_itm"> | string | null
  }

  export type eqp_locWhereInput = {
    AND?: eqp_locWhereInput | eqp_locWhereInput[]
    OR?: eqp_locWhereInput[]
    NOT?: eqp_locWhereInput | eqp_locWhereInput[]
    EqpTpoId?: IntFilter<"eqp_loc"> | number
    EqpItmId?: IntFilter<"eqp_loc"> | number
    UndId?: IntFilter<"eqp_loc"> | number
    SttId?: IntFilter<"eqp_loc"> | number
    UsrIdAlt?: IntFilter<"eqp_loc"> | number
    DtaAlt?: DateTimeFilter<"eqp_loc"> | Date | string
    MtvDel?: StringNullableFilter<"eqp_loc"> | string | null
  }

  export type eqp_locOrderByWithRelationInput = {
    EqpTpoId?: SortOrder
    EqpItmId?: SortOrder
    UndId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _relevance?: eqp_locOrderByRelevanceInput
  }

  export type eqp_locWhereUniqueInput = Prisma.AtLeast<{
    EqpItmId_UndId?: eqp_locEqpItmIdUndIdCompoundUniqueInput
    AND?: eqp_locWhereInput | eqp_locWhereInput[]
    OR?: eqp_locWhereInput[]
    NOT?: eqp_locWhereInput | eqp_locWhereInput[]
    EqpTpoId?: IntFilter<"eqp_loc"> | number
    EqpItmId?: IntFilter<"eqp_loc"> | number
    UndId?: IntFilter<"eqp_loc"> | number
    SttId?: IntFilter<"eqp_loc"> | number
    UsrIdAlt?: IntFilter<"eqp_loc"> | number
    DtaAlt?: DateTimeFilter<"eqp_loc"> | Date | string
    MtvDel?: StringNullableFilter<"eqp_loc"> | string | null
  }, "EqpItmId_UndId">

  export type eqp_locOrderByWithAggregationInput = {
    EqpTpoId?: SortOrder
    EqpItmId?: SortOrder
    UndId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _count?: eqp_locCountOrderByAggregateInput
    _avg?: eqp_locAvgOrderByAggregateInput
    _max?: eqp_locMaxOrderByAggregateInput
    _min?: eqp_locMinOrderByAggregateInput
    _sum?: eqp_locSumOrderByAggregateInput
  }

  export type eqp_locScalarWhereWithAggregatesInput = {
    AND?: eqp_locScalarWhereWithAggregatesInput | eqp_locScalarWhereWithAggregatesInput[]
    OR?: eqp_locScalarWhereWithAggregatesInput[]
    NOT?: eqp_locScalarWhereWithAggregatesInput | eqp_locScalarWhereWithAggregatesInput[]
    EqpTpoId?: IntWithAggregatesFilter<"eqp_loc"> | number
    EqpItmId?: IntWithAggregatesFilter<"eqp_loc"> | number
    UndId?: IntWithAggregatesFilter<"eqp_loc"> | number
    SttId?: IntWithAggregatesFilter<"eqp_loc"> | number
    UsrIdAlt?: IntWithAggregatesFilter<"eqp_loc"> | number
    DtaAlt?: DateTimeWithAggregatesFilter<"eqp_loc"> | Date | string
    MtvDel?: StringNullableWithAggregatesFilter<"eqp_loc"> | string | null
  }

  export type eqp_mdlWhereInput = {
    AND?: eqp_mdlWhereInput | eqp_mdlWhereInput[]
    OR?: eqp_mdlWhereInput[]
    NOT?: eqp_mdlWhereInput | eqp_mdlWhereInput[]
    EqpTpoId?: IntFilter<"eqp_mdl"> | number
    EqpFbrId?: IntFilter<"eqp_mdl"> | number
    EqpMdlId?: IntFilter<"eqp_mdl"> | number
    EqpMdlNme?: StringFilter<"eqp_mdl"> | string
    SttId?: IntFilter<"eqp_mdl"> | number
    UsrIdAlt?: IntFilter<"eqp_mdl"> | number
    DtaAlt?: DateTimeFilter<"eqp_mdl"> | Date | string
    MtvDel?: StringNullableFilter<"eqp_mdl"> | string | null
  }

  export type eqp_mdlOrderByWithRelationInput = {
    EqpTpoId?: SortOrder
    EqpFbrId?: SortOrder
    EqpMdlId?: SortOrder
    EqpMdlNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _relevance?: eqp_mdlOrderByRelevanceInput
  }

  export type eqp_mdlWhereUniqueInput = Prisma.AtLeast<{
    EqpMdlId?: number
    AND?: eqp_mdlWhereInput | eqp_mdlWhereInput[]
    OR?: eqp_mdlWhereInput[]
    NOT?: eqp_mdlWhereInput | eqp_mdlWhereInput[]
    EqpTpoId?: IntFilter<"eqp_mdl"> | number
    EqpFbrId?: IntFilter<"eqp_mdl"> | number
    EqpMdlNme?: StringFilter<"eqp_mdl"> | string
    SttId?: IntFilter<"eqp_mdl"> | number
    UsrIdAlt?: IntFilter<"eqp_mdl"> | number
    DtaAlt?: DateTimeFilter<"eqp_mdl"> | Date | string
    MtvDel?: StringNullableFilter<"eqp_mdl"> | string | null
  }, "EqpMdlId">

  export type eqp_mdlOrderByWithAggregationInput = {
    EqpTpoId?: SortOrder
    EqpFbrId?: SortOrder
    EqpMdlId?: SortOrder
    EqpMdlNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _count?: eqp_mdlCountOrderByAggregateInput
    _avg?: eqp_mdlAvgOrderByAggregateInput
    _max?: eqp_mdlMaxOrderByAggregateInput
    _min?: eqp_mdlMinOrderByAggregateInput
    _sum?: eqp_mdlSumOrderByAggregateInput
  }

  export type eqp_mdlScalarWhereWithAggregatesInput = {
    AND?: eqp_mdlScalarWhereWithAggregatesInput | eqp_mdlScalarWhereWithAggregatesInput[]
    OR?: eqp_mdlScalarWhereWithAggregatesInput[]
    NOT?: eqp_mdlScalarWhereWithAggregatesInput | eqp_mdlScalarWhereWithAggregatesInput[]
    EqpTpoId?: IntWithAggregatesFilter<"eqp_mdl"> | number
    EqpFbrId?: IntWithAggregatesFilter<"eqp_mdl"> | number
    EqpMdlId?: IntWithAggregatesFilter<"eqp_mdl"> | number
    EqpMdlNme?: StringWithAggregatesFilter<"eqp_mdl"> | string
    SttId?: IntWithAggregatesFilter<"eqp_mdl"> | number
    UsrIdAlt?: IntWithAggregatesFilter<"eqp_mdl"> | number
    DtaAlt?: DateTimeWithAggregatesFilter<"eqp_mdl"> | Date | string
    MtvDel?: StringNullableWithAggregatesFilter<"eqp_mdl"> | string | null
  }

  export type eqp_tpoWhereInput = {
    AND?: eqp_tpoWhereInput | eqp_tpoWhereInput[]
    OR?: eqp_tpoWhereInput[]
    NOT?: eqp_tpoWhereInput | eqp_tpoWhereInput[]
    EqpTpoId?: IntFilter<"eqp_tpo"> | number
    EqpTpoNme?: StringFilter<"eqp_tpo"> | string
    SttId?: IntFilter<"eqp_tpo"> | number
    UsrIdAlt?: IntFilter<"eqp_tpo"> | number
    DtaAlt?: DateTimeFilter<"eqp_tpo"> | Date | string
    MtvDel?: StringNullableFilter<"eqp_tpo"> | string | null
  }

  export type eqp_tpoOrderByWithRelationInput = {
    EqpTpoId?: SortOrder
    EqpTpoNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _relevance?: eqp_tpoOrderByRelevanceInput
  }

  export type eqp_tpoWhereUniqueInput = Prisma.AtLeast<{
    EqpTpoId?: number
    AND?: eqp_tpoWhereInput | eqp_tpoWhereInput[]
    OR?: eqp_tpoWhereInput[]
    NOT?: eqp_tpoWhereInput | eqp_tpoWhereInput[]
    EqpTpoNme?: StringFilter<"eqp_tpo"> | string
    SttId?: IntFilter<"eqp_tpo"> | number
    UsrIdAlt?: IntFilter<"eqp_tpo"> | number
    DtaAlt?: DateTimeFilter<"eqp_tpo"> | Date | string
    MtvDel?: StringNullableFilter<"eqp_tpo"> | string | null
  }, "EqpTpoId">

  export type eqp_tpoOrderByWithAggregationInput = {
    EqpTpoId?: SortOrder
    EqpTpoNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _count?: eqp_tpoCountOrderByAggregateInput
    _avg?: eqp_tpoAvgOrderByAggregateInput
    _max?: eqp_tpoMaxOrderByAggregateInput
    _min?: eqp_tpoMinOrderByAggregateInput
    _sum?: eqp_tpoSumOrderByAggregateInput
  }

  export type eqp_tpoScalarWhereWithAggregatesInput = {
    AND?: eqp_tpoScalarWhereWithAggregatesInput | eqp_tpoScalarWhereWithAggregatesInput[]
    OR?: eqp_tpoScalarWhereWithAggregatesInput[]
    NOT?: eqp_tpoScalarWhereWithAggregatesInput | eqp_tpoScalarWhereWithAggregatesInput[]
    EqpTpoId?: IntWithAggregatesFilter<"eqp_tpo"> | number
    EqpTpoNme?: StringWithAggregatesFilter<"eqp_tpo"> | string
    SttId?: IntWithAggregatesFilter<"eqp_tpo"> | number
    UsrIdAlt?: IntWithAggregatesFilter<"eqp_tpo"> | number
    DtaAlt?: DateTimeWithAggregatesFilter<"eqp_tpo"> | Date | string
    MtvDel?: StringNullableWithAggregatesFilter<"eqp_tpo"> | string | null
  }

  export type frnWhereInput = {
    AND?: frnWhereInput | frnWhereInput[]
    OR?: frnWhereInput[]
    NOT?: frnWhereInput | frnWhereInput[]
    FrnId?: IntFilter<"frn"> | number
    FrnNme?: StringFilter<"frn"> | string
    FrnRdz?: StringFilter<"frn"> | string
    SttId?: IntFilter<"frn"> | number
    UsrIdAlt?: IntFilter<"frn"> | number
    DtaAlt?: DateTimeFilter<"frn"> | Date | string
    MtvDel?: StringNullableFilter<"frn"> | string | null
  }

  export type frnOrderByWithRelationInput = {
    FrnId?: SortOrder
    FrnNme?: SortOrder
    FrnRdz?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _relevance?: frnOrderByRelevanceInput
  }

  export type frnWhereUniqueInput = Prisma.AtLeast<{
    FrnId?: number
    AND?: frnWhereInput | frnWhereInput[]
    OR?: frnWhereInput[]
    NOT?: frnWhereInput | frnWhereInput[]
    FrnNme?: StringFilter<"frn"> | string
    FrnRdz?: StringFilter<"frn"> | string
    SttId?: IntFilter<"frn"> | number
    UsrIdAlt?: IntFilter<"frn"> | number
    DtaAlt?: DateTimeFilter<"frn"> | Date | string
    MtvDel?: StringNullableFilter<"frn"> | string | null
  }, "FrnId">

  export type frnOrderByWithAggregationInput = {
    FrnId?: SortOrder
    FrnNme?: SortOrder
    FrnRdz?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _count?: frnCountOrderByAggregateInput
    _avg?: frnAvgOrderByAggregateInput
    _max?: frnMaxOrderByAggregateInput
    _min?: frnMinOrderByAggregateInput
    _sum?: frnSumOrderByAggregateInput
  }

  export type frnScalarWhereWithAggregatesInput = {
    AND?: frnScalarWhereWithAggregatesInput | frnScalarWhereWithAggregatesInput[]
    OR?: frnScalarWhereWithAggregatesInput[]
    NOT?: frnScalarWhereWithAggregatesInput | frnScalarWhereWithAggregatesInput[]
    FrnId?: IntWithAggregatesFilter<"frn"> | number
    FrnNme?: StringWithAggregatesFilter<"frn"> | string
    FrnRdz?: StringWithAggregatesFilter<"frn"> | string
    SttId?: IntWithAggregatesFilter<"frn"> | number
    UsrIdAlt?: IntWithAggregatesFilter<"frn"> | number
    DtaAlt?: DateTimeWithAggregatesFilter<"frn"> | Date | string
    MtvDel?: StringNullableWithAggregatesFilter<"frn"> | string | null
  }

  export type rcgWhereInput = {
    AND?: rcgWhereInput | rcgWhereInput[]
    OR?: rcgWhereInput[]
    NOT?: rcgWhereInput | rcgWhereInput[]
    RcgId?: IntFilter<"rcg"> | number
    RcgIdOrg?: IntNullableFilter<"rcg"> | number | null
    EmpId?: IntFilter<"rcg"> | number
    DtaOpe?: DateTimeFilter<"rcg"> | Date | string
    UndId?: IntFilter<"rcg"> | number
    VclId?: IntFilter<"rcg"> | number
    CrrId?: IntNullableFilter<"rcg"> | number | null
    CrrCnc?: IntNullableFilter<"rcg"> | number | null
    DtaIni?: DateTimeFilter<"rcg"> | Date | string
    DtaFin?: DateTimeNullableFilter<"rcg"> | Date | string | null
    SocIni?: IntNullableFilter<"rcg"> | number | null
    SocFin?: IntNullableFilter<"rcg"> | number | null
    RcgKwh?: FloatNullableFilter<"rcg"> | number | null
    OdoIni?: FloatNullableFilter<"rcg"> | number | null
    OdoFin?: FloatNullableFilter<"rcg"> | number | null
    SttRcgId?: IntFilter<"rcg"> | number
    FlhId?: IntFilter<"rcg"> | number
    FlhDsc?: StringNullableFilter<"rcg"> | string | null
    SttId?: IntFilter<"rcg"> | number
    UsrIdAlt?: IntFilter<"rcg"> | number
    DtaAlt?: DateTimeFilter<"rcg"> | Date | string
    MtvDel?: StringNullableFilter<"rcg"> | string | null
  }

  export type rcgOrderByWithRelationInput = {
    RcgId?: SortOrder
    RcgIdOrg?: SortOrderInput | SortOrder
    EmpId?: SortOrder
    DtaOpe?: SortOrder
    UndId?: SortOrder
    VclId?: SortOrder
    CrrId?: SortOrderInput | SortOrder
    CrrCnc?: SortOrderInput | SortOrder
    DtaIni?: SortOrder
    DtaFin?: SortOrderInput | SortOrder
    SocIni?: SortOrderInput | SortOrder
    SocFin?: SortOrderInput | SortOrder
    RcgKwh?: SortOrderInput | SortOrder
    OdoIni?: SortOrderInput | SortOrder
    OdoFin?: SortOrderInput | SortOrder
    SttRcgId?: SortOrder
    FlhId?: SortOrder
    FlhDsc?: SortOrderInput | SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _relevance?: rcgOrderByRelevanceInput
  }

  export type rcgWhereUniqueInput = Prisma.AtLeast<{
    RcgId?: number
    AND?: rcgWhereInput | rcgWhereInput[]
    OR?: rcgWhereInput[]
    NOT?: rcgWhereInput | rcgWhereInput[]
    RcgIdOrg?: IntNullableFilter<"rcg"> | number | null
    EmpId?: IntFilter<"rcg"> | number
    DtaOpe?: DateTimeFilter<"rcg"> | Date | string
    UndId?: IntFilter<"rcg"> | number
    VclId?: IntFilter<"rcg"> | number
    CrrId?: IntNullableFilter<"rcg"> | number | null
    CrrCnc?: IntNullableFilter<"rcg"> | number | null
    DtaIni?: DateTimeFilter<"rcg"> | Date | string
    DtaFin?: DateTimeNullableFilter<"rcg"> | Date | string | null
    SocIni?: IntNullableFilter<"rcg"> | number | null
    SocFin?: IntNullableFilter<"rcg"> | number | null
    RcgKwh?: FloatNullableFilter<"rcg"> | number | null
    OdoIni?: FloatNullableFilter<"rcg"> | number | null
    OdoFin?: FloatNullableFilter<"rcg"> | number | null
    SttRcgId?: IntFilter<"rcg"> | number
    FlhId?: IntFilter<"rcg"> | number
    FlhDsc?: StringNullableFilter<"rcg"> | string | null
    SttId?: IntFilter<"rcg"> | number
    UsrIdAlt?: IntFilter<"rcg"> | number
    DtaAlt?: DateTimeFilter<"rcg"> | Date | string
    MtvDel?: StringNullableFilter<"rcg"> | string | null
  }, "RcgId">

  export type rcgOrderByWithAggregationInput = {
    RcgId?: SortOrder
    RcgIdOrg?: SortOrderInput | SortOrder
    EmpId?: SortOrder
    DtaOpe?: SortOrder
    UndId?: SortOrder
    VclId?: SortOrder
    CrrId?: SortOrderInput | SortOrder
    CrrCnc?: SortOrderInput | SortOrder
    DtaIni?: SortOrder
    DtaFin?: SortOrderInput | SortOrder
    SocIni?: SortOrderInput | SortOrder
    SocFin?: SortOrderInput | SortOrder
    RcgKwh?: SortOrderInput | SortOrder
    OdoIni?: SortOrderInput | SortOrder
    OdoFin?: SortOrderInput | SortOrder
    SttRcgId?: SortOrder
    FlhId?: SortOrder
    FlhDsc?: SortOrderInput | SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _count?: rcgCountOrderByAggregateInput
    _avg?: rcgAvgOrderByAggregateInput
    _max?: rcgMaxOrderByAggregateInput
    _min?: rcgMinOrderByAggregateInput
    _sum?: rcgSumOrderByAggregateInput
  }

  export type rcgScalarWhereWithAggregatesInput = {
    AND?: rcgScalarWhereWithAggregatesInput | rcgScalarWhereWithAggregatesInput[]
    OR?: rcgScalarWhereWithAggregatesInput[]
    NOT?: rcgScalarWhereWithAggregatesInput | rcgScalarWhereWithAggregatesInput[]
    RcgId?: IntWithAggregatesFilter<"rcg"> | number
    RcgIdOrg?: IntNullableWithAggregatesFilter<"rcg"> | number | null
    EmpId?: IntWithAggregatesFilter<"rcg"> | number
    DtaOpe?: DateTimeWithAggregatesFilter<"rcg"> | Date | string
    UndId?: IntWithAggregatesFilter<"rcg"> | number
    VclId?: IntWithAggregatesFilter<"rcg"> | number
    CrrId?: IntNullableWithAggregatesFilter<"rcg"> | number | null
    CrrCnc?: IntNullableWithAggregatesFilter<"rcg"> | number | null
    DtaIni?: DateTimeWithAggregatesFilter<"rcg"> | Date | string
    DtaFin?: DateTimeNullableWithAggregatesFilter<"rcg"> | Date | string | null
    SocIni?: IntNullableWithAggregatesFilter<"rcg"> | number | null
    SocFin?: IntNullableWithAggregatesFilter<"rcg"> | number | null
    RcgKwh?: FloatNullableWithAggregatesFilter<"rcg"> | number | null
    OdoIni?: FloatNullableWithAggregatesFilter<"rcg"> | number | null
    OdoFin?: FloatNullableWithAggregatesFilter<"rcg"> | number | null
    SttRcgId?: IntWithAggregatesFilter<"rcg"> | number
    FlhId?: IntWithAggregatesFilter<"rcg"> | number
    FlhDsc?: StringNullableWithAggregatesFilter<"rcg"> | string | null
    SttId?: IntWithAggregatesFilter<"rcg"> | number
    UsrIdAlt?: IntWithAggregatesFilter<"rcg"> | number
    DtaAlt?: DateTimeWithAggregatesFilter<"rcg"> | Date | string
    MtvDel?: StringNullableWithAggregatesFilter<"rcg"> | string | null
  }

  export type sttWhereInput = {
    AND?: sttWhereInput | sttWhereInput[]
    OR?: sttWhereInput[]
    NOT?: sttWhereInput | sttWhereInput[]
    SttId?: IntFilter<"stt"> | number
    SttNme?: StringFilter<"stt"> | string
    SttIdAtu?: IntFilter<"stt"> | number
    UsrIdAlt?: IntFilter<"stt"> | number
    DtaAlt?: DateTimeFilter<"stt"> | Date | string
    MtvDel?: StringNullableFilter<"stt"> | string | null
  }

  export type sttOrderByWithRelationInput = {
    SttId?: SortOrder
    SttNme?: SortOrder
    SttIdAtu?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _relevance?: sttOrderByRelevanceInput
  }

  export type sttWhereUniqueInput = Prisma.AtLeast<{
    SttId?: number
    AND?: sttWhereInput | sttWhereInput[]
    OR?: sttWhereInput[]
    NOT?: sttWhereInput | sttWhereInput[]
    SttNme?: StringFilter<"stt"> | string
    SttIdAtu?: IntFilter<"stt"> | number
    UsrIdAlt?: IntFilter<"stt"> | number
    DtaAlt?: DateTimeFilter<"stt"> | Date | string
    MtvDel?: StringNullableFilter<"stt"> | string | null
  }, "SttId">

  export type sttOrderByWithAggregationInput = {
    SttId?: SortOrder
    SttNme?: SortOrder
    SttIdAtu?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _count?: sttCountOrderByAggregateInput
    _avg?: sttAvgOrderByAggregateInput
    _max?: sttMaxOrderByAggregateInput
    _min?: sttMinOrderByAggregateInput
    _sum?: sttSumOrderByAggregateInput
  }

  export type sttScalarWhereWithAggregatesInput = {
    AND?: sttScalarWhereWithAggregatesInput | sttScalarWhereWithAggregatesInput[]
    OR?: sttScalarWhereWithAggregatesInput[]
    NOT?: sttScalarWhereWithAggregatesInput | sttScalarWhereWithAggregatesInput[]
    SttId?: IntWithAggregatesFilter<"stt"> | number
    SttNme?: StringWithAggregatesFilter<"stt"> | string
    SttIdAtu?: IntWithAggregatesFilter<"stt"> | number
    UsrIdAlt?: IntWithAggregatesFilter<"stt"> | number
    DtaAlt?: DateTimeWithAggregatesFilter<"stt"> | Date | string
    MtvDel?: StringNullableWithAggregatesFilter<"stt"> | string | null
  }

  export type usrWhereInput = {
    AND?: usrWhereInput | usrWhereInput[]
    OR?: usrWhereInput[]
    NOT?: usrWhereInput | usrWhereInput[]
    EmpId?: IntFilter<"usr"> | number
    UsrTpoId?: IntFilter<"usr"> | number
    UsrId?: IntFilter<"usr"> | number
    UsrNme?: StringFilter<"usr"> | string
    UsrLgn?: StringNullableFilter<"usr"> | string | null
    UsrCpf?: StringNullableFilter<"usr"> | string | null
    UsrEml?: StringFilter<"usr"> | string
    UsrPwd?: StringFilter<"usr"> | string
    UsrFto?: StringNullableFilter<"usr"> | string | null
    SttId?: IntFilter<"usr"> | number
    UsrIdAlt?: IntFilter<"usr"> | number
    DtaAlt?: DateTimeFilter<"usr"> | Date | string
    MtvDel?: StringNullableFilter<"usr"> | string | null
  }

  export type usrOrderByWithRelationInput = {
    EmpId?: SortOrder
    UsrTpoId?: SortOrder
    UsrId?: SortOrder
    UsrNme?: SortOrder
    UsrLgn?: SortOrderInput | SortOrder
    UsrCpf?: SortOrderInput | SortOrder
    UsrEml?: SortOrder
    UsrPwd?: SortOrder
    UsrFto?: SortOrderInput | SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _relevance?: usrOrderByRelevanceInput
  }

  export type usrWhereUniqueInput = Prisma.AtLeast<{
    UsrId?: number
    UsrLgn?: string
    UsrCpf?: string
    UsrEml?: string
    AND?: usrWhereInput | usrWhereInput[]
    OR?: usrWhereInput[]
    NOT?: usrWhereInput | usrWhereInput[]
    EmpId?: IntFilter<"usr"> | number
    UsrTpoId?: IntFilter<"usr"> | number
    UsrNme?: StringFilter<"usr"> | string
    UsrPwd?: StringFilter<"usr"> | string
    UsrFto?: StringNullableFilter<"usr"> | string | null
    SttId?: IntFilter<"usr"> | number
    UsrIdAlt?: IntFilter<"usr"> | number
    DtaAlt?: DateTimeFilter<"usr"> | Date | string
    MtvDel?: StringNullableFilter<"usr"> | string | null
  }, "UsrId" | "UsrLgn" | "UsrCpf" | "UsrEml">

  export type usrOrderByWithAggregationInput = {
    EmpId?: SortOrder
    UsrTpoId?: SortOrder
    UsrId?: SortOrder
    UsrNme?: SortOrder
    UsrLgn?: SortOrderInput | SortOrder
    UsrCpf?: SortOrderInput | SortOrder
    UsrEml?: SortOrder
    UsrPwd?: SortOrder
    UsrFto?: SortOrderInput | SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _count?: usrCountOrderByAggregateInput
    _avg?: usrAvgOrderByAggregateInput
    _max?: usrMaxOrderByAggregateInput
    _min?: usrMinOrderByAggregateInput
    _sum?: usrSumOrderByAggregateInput
  }

  export type usrScalarWhereWithAggregatesInput = {
    AND?: usrScalarWhereWithAggregatesInput | usrScalarWhereWithAggregatesInput[]
    OR?: usrScalarWhereWithAggregatesInput[]
    NOT?: usrScalarWhereWithAggregatesInput | usrScalarWhereWithAggregatesInput[]
    EmpId?: IntWithAggregatesFilter<"usr"> | number
    UsrTpoId?: IntWithAggregatesFilter<"usr"> | number
    UsrId?: IntWithAggregatesFilter<"usr"> | number
    UsrNme?: StringWithAggregatesFilter<"usr"> | string
    UsrLgn?: StringNullableWithAggregatesFilter<"usr"> | string | null
    UsrCpf?: StringNullableWithAggregatesFilter<"usr"> | string | null
    UsrEml?: StringWithAggregatesFilter<"usr"> | string
    UsrPwd?: StringWithAggregatesFilter<"usr"> | string
    UsrFto?: StringNullableWithAggregatesFilter<"usr"> | string | null
    SttId?: IntWithAggregatesFilter<"usr"> | number
    UsrIdAlt?: IntWithAggregatesFilter<"usr"> | number
    DtaAlt?: DateTimeWithAggregatesFilter<"usr"> | Date | string
    MtvDel?: StringNullableWithAggregatesFilter<"usr"> | string | null
  }

  export type usr_tpoWhereInput = {
    AND?: usr_tpoWhereInput | usr_tpoWhereInput[]
    OR?: usr_tpoWhereInput[]
    NOT?: usr_tpoWhereInput | usr_tpoWhereInput[]
    UsrTpoId?: IntFilter<"usr_tpo"> | number
    UsrTpoNme?: StringFilter<"usr_tpo"> | string
    SttId?: IntFilter<"usr_tpo"> | number
    UsrIdAlt?: IntFilter<"usr_tpo"> | number
    DtaAlt?: DateTimeFilter<"usr_tpo"> | Date | string
    MtvDel?: StringNullableFilter<"usr_tpo"> | string | null
  }

  export type usr_tpoOrderByWithRelationInput = {
    UsrTpoId?: SortOrder
    UsrTpoNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _relevance?: usr_tpoOrderByRelevanceInput
  }

  export type usr_tpoWhereUniqueInput = Prisma.AtLeast<{
    UsrTpoId?: number
    UsrTpoNme?: string
    AND?: usr_tpoWhereInput | usr_tpoWhereInput[]
    OR?: usr_tpoWhereInput[]
    NOT?: usr_tpoWhereInput | usr_tpoWhereInput[]
    SttId?: IntFilter<"usr_tpo"> | number
    UsrIdAlt?: IntFilter<"usr_tpo"> | number
    DtaAlt?: DateTimeFilter<"usr_tpo"> | Date | string
    MtvDel?: StringNullableFilter<"usr_tpo"> | string | null
  }, "UsrTpoId" | "UsrTpoNme">

  export type usr_tpoOrderByWithAggregationInput = {
    UsrTpoId?: SortOrder
    UsrTpoNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrderInput | SortOrder
    _count?: usr_tpoCountOrderByAggregateInput
    _avg?: usr_tpoAvgOrderByAggregateInput
    _max?: usr_tpoMaxOrderByAggregateInput
    _min?: usr_tpoMinOrderByAggregateInput
    _sum?: usr_tpoSumOrderByAggregateInput
  }

  export type usr_tpoScalarWhereWithAggregatesInput = {
    AND?: usr_tpoScalarWhereWithAggregatesInput | usr_tpoScalarWhereWithAggregatesInput[]
    OR?: usr_tpoScalarWhereWithAggregatesInput[]
    NOT?: usr_tpoScalarWhereWithAggregatesInput | usr_tpoScalarWhereWithAggregatesInput[]
    UsrTpoId?: IntWithAggregatesFilter<"usr_tpo"> | number
    UsrTpoNme?: StringWithAggregatesFilter<"usr_tpo"> | string
    SttId?: IntWithAggregatesFilter<"usr_tpo"> | number
    UsrIdAlt?: IntWithAggregatesFilter<"usr_tpo"> | number
    DtaAlt?: DateTimeWithAggregatesFilter<"usr_tpo"> | Date | string
    MtvDel?: StringNullableWithAggregatesFilter<"usr_tpo"> | string | null
  }

  export type VwCarregadorWhereInput = {
    AND?: VwCarregadorWhereInput | VwCarregadorWhereInput[]
    OR?: VwCarregadorWhereInput[]
    NOT?: VwCarregadorWhereInput | VwCarregadorWhereInput[]
    UndId?: IntFilter<"VwCarregador"> | number
    EqpItmId?: IntFilter<"VwCarregador"> | number
    Carregador?: StringNullableFilter<"VwCarregador"> | string | null
  }

  export type VwCarregadorOrderByWithRelationInput = {
    UndId?: SortOrder
    EqpItmId?: SortOrder
    Carregador?: SortOrderInput | SortOrder
    _relevance?: VwCarregadorOrderByRelevanceInput
  }

  export type VwCarregadorWhereUniqueInput = Prisma.AtLeast<{
    UndId_EqpItmId?: VwCarregadorUndIdEqpItmIdCompoundUniqueInput
    AND?: VwCarregadorWhereInput | VwCarregadorWhereInput[]
    OR?: VwCarregadorWhereInput[]
    NOT?: VwCarregadorWhereInput | VwCarregadorWhereInput[]
    UndId?: IntFilter<"VwCarregador"> | number
    EqpItmId?: IntFilter<"VwCarregador"> | number
    Carregador?: StringNullableFilter<"VwCarregador"> | string | null
  }, "UndId_EqpItmId">

  export type VwCarregadorOrderByWithAggregationInput = {
    UndId?: SortOrder
    EqpItmId?: SortOrder
    Carregador?: SortOrderInput | SortOrder
    _count?: VwCarregadorCountOrderByAggregateInput
    _avg?: VwCarregadorAvgOrderByAggregateInput
    _max?: VwCarregadorMaxOrderByAggregateInput
    _min?: VwCarregadorMinOrderByAggregateInput
    _sum?: VwCarregadorSumOrderByAggregateInput
  }

  export type VwCarregadorScalarWhereWithAggregatesInput = {
    AND?: VwCarregadorScalarWhereWithAggregatesInput | VwCarregadorScalarWhereWithAggregatesInput[]
    OR?: VwCarregadorScalarWhereWithAggregatesInput[]
    NOT?: VwCarregadorScalarWhereWithAggregatesInput | VwCarregadorScalarWhereWithAggregatesInput[]
    UndId?: IntWithAggregatesFilter<"VwCarregador"> | number
    EqpItmId?: IntWithAggregatesFilter<"VwCarregador"> | number
    Carregador?: StringNullableWithAggregatesFilter<"VwCarregador"> | string | null
  }

  export type VwOnibusWhereInput = {
    AND?: VwOnibusWhereInput | VwOnibusWhereInput[]
    OR?: VwOnibusWhereInput[]
    NOT?: VwOnibusWhereInput | VwOnibusWhereInput[]
    EqpItmId?: IntFilter<"VwOnibus"> | number
    Onibus?: StringFilter<"VwOnibus"> | string
    Situacao?: StringFilter<"VwOnibus"> | string
  }

  export type VwOnibusOrderByWithRelationInput = {
    EqpItmId?: SortOrder
    Onibus?: SortOrder
    Situacao?: SortOrder
    _relevance?: VwOnibusOrderByRelevanceInput
  }

  export type VwOnibusWhereUniqueInput = Prisma.AtLeast<{
    EqpItmId?: number
    AND?: VwOnibusWhereInput | VwOnibusWhereInput[]
    OR?: VwOnibusWhereInput[]
    NOT?: VwOnibusWhereInput | VwOnibusWhereInput[]
    Onibus?: StringFilter<"VwOnibus"> | string
    Situacao?: StringFilter<"VwOnibus"> | string
  }, "EqpItmId">

  export type VwOnibusOrderByWithAggregationInput = {
    EqpItmId?: SortOrder
    Onibus?: SortOrder
    Situacao?: SortOrder
    _count?: VwOnibusCountOrderByAggregateInput
    _avg?: VwOnibusAvgOrderByAggregateInput
    _max?: VwOnibusMaxOrderByAggregateInput
    _min?: VwOnibusMinOrderByAggregateInput
    _sum?: VwOnibusSumOrderByAggregateInput
  }

  export type VwOnibusScalarWhereWithAggregatesInput = {
    AND?: VwOnibusScalarWhereWithAggregatesInput | VwOnibusScalarWhereWithAggregatesInput[]
    OR?: VwOnibusScalarWhereWithAggregatesInput[]
    NOT?: VwOnibusScalarWhereWithAggregatesInput | VwOnibusScalarWhereWithAggregatesInput[]
    EqpItmId?: IntWithAggregatesFilter<"VwOnibus"> | number
    Onibus?: StringWithAggregatesFilter<"VwOnibus"> | string
    Situacao?: StringWithAggregatesFilter<"VwOnibus"> | string
  }

  export type VwPostoRecargaWhereInput = {
    AND?: VwPostoRecargaWhereInput | VwPostoRecargaWhereInput[]
    OR?: VwPostoRecargaWhereInput[]
    NOT?: VwPostoRecargaWhereInput | VwPostoRecargaWhereInput[]
    UndId?: IntFilter<"VwPostoRecarga"> | number
    PostoRecarga?: StringFilter<"VwPostoRecarga"> | string
    Latitude?: StringNullableFilter<"VwPostoRecarga"> | string | null
    Longitude?: StringNullableFilter<"VwPostoRecarga"> | string | null
    EqpItmId?: IntNullableFilter<"VwPostoRecarga"> | number | null
    Carregador?: StringNullableFilter<"VwPostoRecarga"> | string | null
  }

  export type VwPostoRecargaOrderByWithRelationInput = {
    UndId?: SortOrder
    PostoRecarga?: SortOrder
    Latitude?: SortOrderInput | SortOrder
    Longitude?: SortOrderInput | SortOrder
    EqpItmId?: SortOrderInput | SortOrder
    Carregador?: SortOrderInput | SortOrder
    _relevance?: VwPostoRecargaOrderByRelevanceInput
  }

  export type VwPostoRecargaWhereUniqueInput = Prisma.AtLeast<{
    UndId?: number
    AND?: VwPostoRecargaWhereInput | VwPostoRecargaWhereInput[]
    OR?: VwPostoRecargaWhereInput[]
    NOT?: VwPostoRecargaWhereInput | VwPostoRecargaWhereInput[]
    PostoRecarga?: StringFilter<"VwPostoRecarga"> | string
    Latitude?: StringNullableFilter<"VwPostoRecarga"> | string | null
    Longitude?: StringNullableFilter<"VwPostoRecarga"> | string | null
    EqpItmId?: IntNullableFilter<"VwPostoRecarga"> | number | null
    Carregador?: StringNullableFilter<"VwPostoRecarga"> | string | null
  }, "UndId">

  export type VwPostoRecargaOrderByWithAggregationInput = {
    UndId?: SortOrder
    PostoRecarga?: SortOrder
    Latitude?: SortOrderInput | SortOrder
    Longitude?: SortOrderInput | SortOrder
    EqpItmId?: SortOrderInput | SortOrder
    Carregador?: SortOrderInput | SortOrder
    _count?: VwPostoRecargaCountOrderByAggregateInput
    _avg?: VwPostoRecargaAvgOrderByAggregateInput
    _max?: VwPostoRecargaMaxOrderByAggregateInput
    _min?: VwPostoRecargaMinOrderByAggregateInput
    _sum?: VwPostoRecargaSumOrderByAggregateInput
  }

  export type VwPostoRecargaScalarWhereWithAggregatesInput = {
    AND?: VwPostoRecargaScalarWhereWithAggregatesInput | VwPostoRecargaScalarWhereWithAggregatesInput[]
    OR?: VwPostoRecargaScalarWhereWithAggregatesInput[]
    NOT?: VwPostoRecargaScalarWhereWithAggregatesInput | VwPostoRecargaScalarWhereWithAggregatesInput[]
    UndId?: IntWithAggregatesFilter<"VwPostoRecarga"> | number
    PostoRecarga?: StringWithAggregatesFilter<"VwPostoRecarga"> | string
    Latitude?: StringNullableWithAggregatesFilter<"VwPostoRecarga"> | string | null
    Longitude?: StringNullableWithAggregatesFilter<"VwPostoRecarga"> | string | null
    EqpItmId?: IntNullableWithAggregatesFilter<"VwPostoRecarga"> | number | null
    Carregador?: StringNullableWithAggregatesFilter<"VwPostoRecarga"> | string | null
  }

  export type cbtCreateInput = {
    CbtNme: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type cbtUncheckedCreateInput = {
    CbtId?: number
    CbtNme: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type cbtUpdateInput = {
    CbtNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type cbtUncheckedUpdateInput = {
    CbtId?: IntFieldUpdateOperationsInput | number
    CbtNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type cbtCreateManyInput = {
    CbtId?: number
    CbtNme: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type cbtUpdateManyMutationInput = {
    CbtNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type cbtUncheckedUpdateManyInput = {
    CbtId?: IntFieldUpdateOperationsInput | number
    CbtNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type empCreateInput = {
    EmpNme: string
    EmpRaz?: string | null
    EmpRdz?: string | null
    EmpAtv?: string | null
    EmpCnpj?: string | null
    Enduf?: string | null
    EndCdd?: string | null
    EndLtt?: string | null
    EndLgt?: string | null
    EndCep?: string | null
    EndEmp?: string | null
    EndCpl?: string | null
    EmpLgo?: string | null
    EmpUrl?: string | null
    EmlCtt?: string | null
    EmlFrm?: string | null
    EmlFrmPwd?: string | null
    FneCtt?: string | null
    FneWha?: string | null
    RssIns?: string | null
    RssFac?: string | null
    RssTwi?: string | null
    RssYou?: string | null
    TpoPix?: string | null
    ChvPix?: string | null
    QRPixImg?: string | null
    QRPixCpy?: string | null
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type empUncheckedCreateInput = {
    EmpId?: number
    EmpNme: string
    EmpRaz?: string | null
    EmpRdz?: string | null
    EmpAtv?: string | null
    EmpCnpj?: string | null
    Enduf?: string | null
    EndCdd?: string | null
    EndLtt?: string | null
    EndLgt?: string | null
    EndCep?: string | null
    EndEmp?: string | null
    EndCpl?: string | null
    EmpLgo?: string | null
    EmpUrl?: string | null
    EmlCtt?: string | null
    EmlFrm?: string | null
    EmlFrmPwd?: string | null
    FneCtt?: string | null
    FneWha?: string | null
    RssIns?: string | null
    RssFac?: string | null
    RssTwi?: string | null
    RssYou?: string | null
    TpoPix?: string | null
    ChvPix?: string | null
    QRPixImg?: string | null
    QRPixCpy?: string | null
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type empUpdateInput = {
    EmpNme?: StringFieldUpdateOperationsInput | string
    EmpRaz?: NullableStringFieldUpdateOperationsInput | string | null
    EmpRdz?: NullableStringFieldUpdateOperationsInput | string | null
    EmpAtv?: NullableStringFieldUpdateOperationsInput | string | null
    EmpCnpj?: NullableStringFieldUpdateOperationsInput | string | null
    Enduf?: NullableStringFieldUpdateOperationsInput | string | null
    EndCdd?: NullableStringFieldUpdateOperationsInput | string | null
    EndLtt?: NullableStringFieldUpdateOperationsInput | string | null
    EndLgt?: NullableStringFieldUpdateOperationsInput | string | null
    EndCep?: NullableStringFieldUpdateOperationsInput | string | null
    EndEmp?: NullableStringFieldUpdateOperationsInput | string | null
    EndCpl?: NullableStringFieldUpdateOperationsInput | string | null
    EmpLgo?: NullableStringFieldUpdateOperationsInput | string | null
    EmpUrl?: NullableStringFieldUpdateOperationsInput | string | null
    EmlCtt?: NullableStringFieldUpdateOperationsInput | string | null
    EmlFrm?: NullableStringFieldUpdateOperationsInput | string | null
    EmlFrmPwd?: NullableStringFieldUpdateOperationsInput | string | null
    FneCtt?: NullableStringFieldUpdateOperationsInput | string | null
    FneWha?: NullableStringFieldUpdateOperationsInput | string | null
    RssIns?: NullableStringFieldUpdateOperationsInput | string | null
    RssFac?: NullableStringFieldUpdateOperationsInput | string | null
    RssTwi?: NullableStringFieldUpdateOperationsInput | string | null
    RssYou?: NullableStringFieldUpdateOperationsInput | string | null
    TpoPix?: NullableStringFieldUpdateOperationsInput | string | null
    ChvPix?: NullableStringFieldUpdateOperationsInput | string | null
    QRPixImg?: NullableStringFieldUpdateOperationsInput | string | null
    QRPixCpy?: NullableStringFieldUpdateOperationsInput | string | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type empUncheckedUpdateInput = {
    EmpId?: IntFieldUpdateOperationsInput | number
    EmpNme?: StringFieldUpdateOperationsInput | string
    EmpRaz?: NullableStringFieldUpdateOperationsInput | string | null
    EmpRdz?: NullableStringFieldUpdateOperationsInput | string | null
    EmpAtv?: NullableStringFieldUpdateOperationsInput | string | null
    EmpCnpj?: NullableStringFieldUpdateOperationsInput | string | null
    Enduf?: NullableStringFieldUpdateOperationsInput | string | null
    EndCdd?: NullableStringFieldUpdateOperationsInput | string | null
    EndLtt?: NullableStringFieldUpdateOperationsInput | string | null
    EndLgt?: NullableStringFieldUpdateOperationsInput | string | null
    EndCep?: NullableStringFieldUpdateOperationsInput | string | null
    EndEmp?: NullableStringFieldUpdateOperationsInput | string | null
    EndCpl?: NullableStringFieldUpdateOperationsInput | string | null
    EmpLgo?: NullableStringFieldUpdateOperationsInput | string | null
    EmpUrl?: NullableStringFieldUpdateOperationsInput | string | null
    EmlCtt?: NullableStringFieldUpdateOperationsInput | string | null
    EmlFrm?: NullableStringFieldUpdateOperationsInput | string | null
    EmlFrmPwd?: NullableStringFieldUpdateOperationsInput | string | null
    FneCtt?: NullableStringFieldUpdateOperationsInput | string | null
    FneWha?: NullableStringFieldUpdateOperationsInput | string | null
    RssIns?: NullableStringFieldUpdateOperationsInput | string | null
    RssFac?: NullableStringFieldUpdateOperationsInput | string | null
    RssTwi?: NullableStringFieldUpdateOperationsInput | string | null
    RssYou?: NullableStringFieldUpdateOperationsInput | string | null
    TpoPix?: NullableStringFieldUpdateOperationsInput | string | null
    ChvPix?: NullableStringFieldUpdateOperationsInput | string | null
    QRPixImg?: NullableStringFieldUpdateOperationsInput | string | null
    QRPixCpy?: NullableStringFieldUpdateOperationsInput | string | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type empCreateManyInput = {
    EmpId?: number
    EmpNme: string
    EmpRaz?: string | null
    EmpRdz?: string | null
    EmpAtv?: string | null
    EmpCnpj?: string | null
    Enduf?: string | null
    EndCdd?: string | null
    EndLtt?: string | null
    EndLgt?: string | null
    EndCep?: string | null
    EndEmp?: string | null
    EndCpl?: string | null
    EmpLgo?: string | null
    EmpUrl?: string | null
    EmlCtt?: string | null
    EmlFrm?: string | null
    EmlFrmPwd?: string | null
    FneCtt?: string | null
    FneWha?: string | null
    RssIns?: string | null
    RssFac?: string | null
    RssTwi?: string | null
    RssYou?: string | null
    TpoPix?: string | null
    ChvPix?: string | null
    QRPixImg?: string | null
    QRPixCpy?: string | null
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type empUpdateManyMutationInput = {
    EmpNme?: StringFieldUpdateOperationsInput | string
    EmpRaz?: NullableStringFieldUpdateOperationsInput | string | null
    EmpRdz?: NullableStringFieldUpdateOperationsInput | string | null
    EmpAtv?: NullableStringFieldUpdateOperationsInput | string | null
    EmpCnpj?: NullableStringFieldUpdateOperationsInput | string | null
    Enduf?: NullableStringFieldUpdateOperationsInput | string | null
    EndCdd?: NullableStringFieldUpdateOperationsInput | string | null
    EndLtt?: NullableStringFieldUpdateOperationsInput | string | null
    EndLgt?: NullableStringFieldUpdateOperationsInput | string | null
    EndCep?: NullableStringFieldUpdateOperationsInput | string | null
    EndEmp?: NullableStringFieldUpdateOperationsInput | string | null
    EndCpl?: NullableStringFieldUpdateOperationsInput | string | null
    EmpLgo?: NullableStringFieldUpdateOperationsInput | string | null
    EmpUrl?: NullableStringFieldUpdateOperationsInput | string | null
    EmlCtt?: NullableStringFieldUpdateOperationsInput | string | null
    EmlFrm?: NullableStringFieldUpdateOperationsInput | string | null
    EmlFrmPwd?: NullableStringFieldUpdateOperationsInput | string | null
    FneCtt?: NullableStringFieldUpdateOperationsInput | string | null
    FneWha?: NullableStringFieldUpdateOperationsInput | string | null
    RssIns?: NullableStringFieldUpdateOperationsInput | string | null
    RssFac?: NullableStringFieldUpdateOperationsInput | string | null
    RssTwi?: NullableStringFieldUpdateOperationsInput | string | null
    RssYou?: NullableStringFieldUpdateOperationsInput | string | null
    TpoPix?: NullableStringFieldUpdateOperationsInput | string | null
    ChvPix?: NullableStringFieldUpdateOperationsInput | string | null
    QRPixImg?: NullableStringFieldUpdateOperationsInput | string | null
    QRPixCpy?: NullableStringFieldUpdateOperationsInput | string | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type empUncheckedUpdateManyInput = {
    EmpId?: IntFieldUpdateOperationsInput | number
    EmpNme?: StringFieldUpdateOperationsInput | string
    EmpRaz?: NullableStringFieldUpdateOperationsInput | string | null
    EmpRdz?: NullableStringFieldUpdateOperationsInput | string | null
    EmpAtv?: NullableStringFieldUpdateOperationsInput | string | null
    EmpCnpj?: NullableStringFieldUpdateOperationsInput | string | null
    Enduf?: NullableStringFieldUpdateOperationsInput | string | null
    EndCdd?: NullableStringFieldUpdateOperationsInput | string | null
    EndLtt?: NullableStringFieldUpdateOperationsInput | string | null
    EndLgt?: NullableStringFieldUpdateOperationsInput | string | null
    EndCep?: NullableStringFieldUpdateOperationsInput | string | null
    EndEmp?: NullableStringFieldUpdateOperationsInput | string | null
    EndCpl?: NullableStringFieldUpdateOperationsInput | string | null
    EmpLgo?: NullableStringFieldUpdateOperationsInput | string | null
    EmpUrl?: NullableStringFieldUpdateOperationsInput | string | null
    EmlCtt?: NullableStringFieldUpdateOperationsInput | string | null
    EmlFrm?: NullableStringFieldUpdateOperationsInput | string | null
    EmlFrmPwd?: NullableStringFieldUpdateOperationsInput | string | null
    FneCtt?: NullableStringFieldUpdateOperationsInput | string | null
    FneWha?: NullableStringFieldUpdateOperationsInput | string | null
    RssIns?: NullableStringFieldUpdateOperationsInput | string | null
    RssFac?: NullableStringFieldUpdateOperationsInput | string | null
    RssTwi?: NullableStringFieldUpdateOperationsInput | string | null
    RssYou?: NullableStringFieldUpdateOperationsInput | string | null
    TpoPix?: NullableStringFieldUpdateOperationsInput | string | null
    ChvPix?: NullableStringFieldUpdateOperationsInput | string | null
    QRPixImg?: NullableStringFieldUpdateOperationsInput | string | null
    QRPixCpy?: NullableStringFieldUpdateOperationsInput | string | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type emp_undCreateInput = {
    EmpId: number
    UndNme: string
    UndRdz?: string | null
    UndReg?: string | null
    GpsLtd?: string | null
    GpsLgt?: string | null
    PstRcg?: number | null
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type emp_undUncheckedCreateInput = {
    EmpId: number
    UndId?: number
    UndNme: string
    UndRdz?: string | null
    UndReg?: string | null
    GpsLtd?: string | null
    GpsLgt?: string | null
    PstRcg?: number | null
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type emp_undUpdateInput = {
    EmpId?: IntFieldUpdateOperationsInput | number
    UndNme?: StringFieldUpdateOperationsInput | string
    UndRdz?: NullableStringFieldUpdateOperationsInput | string | null
    UndReg?: NullableStringFieldUpdateOperationsInput | string | null
    GpsLtd?: NullableStringFieldUpdateOperationsInput | string | null
    GpsLgt?: NullableStringFieldUpdateOperationsInput | string | null
    PstRcg?: NullableIntFieldUpdateOperationsInput | number | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type emp_undUncheckedUpdateInput = {
    EmpId?: IntFieldUpdateOperationsInput | number
    UndId?: IntFieldUpdateOperationsInput | number
    UndNme?: StringFieldUpdateOperationsInput | string
    UndRdz?: NullableStringFieldUpdateOperationsInput | string | null
    UndReg?: NullableStringFieldUpdateOperationsInput | string | null
    GpsLtd?: NullableStringFieldUpdateOperationsInput | string | null
    GpsLgt?: NullableStringFieldUpdateOperationsInput | string | null
    PstRcg?: NullableIntFieldUpdateOperationsInput | number | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type emp_undCreateManyInput = {
    EmpId: number
    UndId?: number
    UndNme: string
    UndRdz?: string | null
    UndReg?: string | null
    GpsLtd?: string | null
    GpsLgt?: string | null
    PstRcg?: number | null
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type emp_undUpdateManyMutationInput = {
    EmpId?: IntFieldUpdateOperationsInput | number
    UndNme?: StringFieldUpdateOperationsInput | string
    UndRdz?: NullableStringFieldUpdateOperationsInput | string | null
    UndReg?: NullableStringFieldUpdateOperationsInput | string | null
    GpsLtd?: NullableStringFieldUpdateOperationsInput | string | null
    GpsLgt?: NullableStringFieldUpdateOperationsInput | string | null
    PstRcg?: NullableIntFieldUpdateOperationsInput | number | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type emp_undUncheckedUpdateManyInput = {
    EmpId?: IntFieldUpdateOperationsInput | number
    UndId?: IntFieldUpdateOperationsInput | number
    UndNme?: StringFieldUpdateOperationsInput | string
    UndRdz?: NullableStringFieldUpdateOperationsInput | string | null
    UndReg?: NullableStringFieldUpdateOperationsInput | string | null
    GpsLtd?: NullableStringFieldUpdateOperationsInput | string | null
    GpsLgt?: NullableStringFieldUpdateOperationsInput | string | null
    PstRcg?: NullableIntFieldUpdateOperationsInput | number | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_fbrCreateInput = {
    EqpFbrNme: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type eqp_fbrUncheckedCreateInput = {
    EqpFbrId?: number
    EqpFbrNme: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type eqp_fbrUpdateInput = {
    EqpFbrNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_fbrUncheckedUpdateInput = {
    EqpFbrId?: IntFieldUpdateOperationsInput | number
    EqpFbrNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_fbrCreateManyInput = {
    EqpFbrId?: number
    EqpFbrNme: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type eqp_fbrUpdateManyMutationInput = {
    EqpFbrNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_fbrUncheckedUpdateManyInput = {
    EqpFbrId?: IntFieldUpdateOperationsInput | number
    EqpFbrNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_itmCreateInput = {
    FrnId: number
    EqpTpoId: number
    EqpFbrId: number
    EqpMdlId: number
    EqpItmCdg: string
    EqpItmPlc?: string | null
    EqpItmAnoMdl?: string | null
    CbtId: number
    EqpItmTmh: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type eqp_itmUncheckedCreateInput = {
    FrnId: number
    EqpTpoId: number
    EqpFbrId: number
    EqpMdlId: number
    EqpItmId?: number
    EqpItmCdg: string
    EqpItmPlc?: string | null
    EqpItmAnoMdl?: string | null
    CbtId: number
    EqpItmTmh: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type eqp_itmUpdateInput = {
    FrnId?: IntFieldUpdateOperationsInput | number
    EqpTpoId?: IntFieldUpdateOperationsInput | number
    EqpFbrId?: IntFieldUpdateOperationsInput | number
    EqpMdlId?: IntFieldUpdateOperationsInput | number
    EqpItmCdg?: StringFieldUpdateOperationsInput | string
    EqpItmPlc?: NullableStringFieldUpdateOperationsInput | string | null
    EqpItmAnoMdl?: NullableStringFieldUpdateOperationsInput | string | null
    CbtId?: IntFieldUpdateOperationsInput | number
    EqpItmTmh?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_itmUncheckedUpdateInput = {
    FrnId?: IntFieldUpdateOperationsInput | number
    EqpTpoId?: IntFieldUpdateOperationsInput | number
    EqpFbrId?: IntFieldUpdateOperationsInput | number
    EqpMdlId?: IntFieldUpdateOperationsInput | number
    EqpItmId?: IntFieldUpdateOperationsInput | number
    EqpItmCdg?: StringFieldUpdateOperationsInput | string
    EqpItmPlc?: NullableStringFieldUpdateOperationsInput | string | null
    EqpItmAnoMdl?: NullableStringFieldUpdateOperationsInput | string | null
    CbtId?: IntFieldUpdateOperationsInput | number
    EqpItmTmh?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_itmCreateManyInput = {
    FrnId: number
    EqpTpoId: number
    EqpFbrId: number
    EqpMdlId: number
    EqpItmId?: number
    EqpItmCdg: string
    EqpItmPlc?: string | null
    EqpItmAnoMdl?: string | null
    CbtId: number
    EqpItmTmh: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type eqp_itmUpdateManyMutationInput = {
    FrnId?: IntFieldUpdateOperationsInput | number
    EqpTpoId?: IntFieldUpdateOperationsInput | number
    EqpFbrId?: IntFieldUpdateOperationsInput | number
    EqpMdlId?: IntFieldUpdateOperationsInput | number
    EqpItmCdg?: StringFieldUpdateOperationsInput | string
    EqpItmPlc?: NullableStringFieldUpdateOperationsInput | string | null
    EqpItmAnoMdl?: NullableStringFieldUpdateOperationsInput | string | null
    CbtId?: IntFieldUpdateOperationsInput | number
    EqpItmTmh?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_itmUncheckedUpdateManyInput = {
    FrnId?: IntFieldUpdateOperationsInput | number
    EqpTpoId?: IntFieldUpdateOperationsInput | number
    EqpFbrId?: IntFieldUpdateOperationsInput | number
    EqpMdlId?: IntFieldUpdateOperationsInput | number
    EqpItmId?: IntFieldUpdateOperationsInput | number
    EqpItmCdg?: StringFieldUpdateOperationsInput | string
    EqpItmPlc?: NullableStringFieldUpdateOperationsInput | string | null
    EqpItmAnoMdl?: NullableStringFieldUpdateOperationsInput | string | null
    CbtId?: IntFieldUpdateOperationsInput | number
    EqpItmTmh?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_locCreateInput = {
    EqpTpoId: number
    EqpItmId: number
    UndId: number
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type eqp_locUncheckedCreateInput = {
    EqpTpoId: number
    EqpItmId: number
    UndId: number
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type eqp_locUpdateInput = {
    EqpTpoId?: IntFieldUpdateOperationsInput | number
    EqpItmId?: IntFieldUpdateOperationsInput | number
    UndId?: IntFieldUpdateOperationsInput | number
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_locUncheckedUpdateInput = {
    EqpTpoId?: IntFieldUpdateOperationsInput | number
    EqpItmId?: IntFieldUpdateOperationsInput | number
    UndId?: IntFieldUpdateOperationsInput | number
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_locCreateManyInput = {
    EqpTpoId: number
    EqpItmId: number
    UndId: number
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type eqp_locUpdateManyMutationInput = {
    EqpTpoId?: IntFieldUpdateOperationsInput | number
    EqpItmId?: IntFieldUpdateOperationsInput | number
    UndId?: IntFieldUpdateOperationsInput | number
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_locUncheckedUpdateManyInput = {
    EqpTpoId?: IntFieldUpdateOperationsInput | number
    EqpItmId?: IntFieldUpdateOperationsInput | number
    UndId?: IntFieldUpdateOperationsInput | number
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_mdlCreateInput = {
    EqpTpoId: number
    EqpFbrId: number
    EqpMdlNme: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type eqp_mdlUncheckedCreateInput = {
    EqpTpoId: number
    EqpFbrId: number
    EqpMdlId?: number
    EqpMdlNme: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type eqp_mdlUpdateInput = {
    EqpTpoId?: IntFieldUpdateOperationsInput | number
    EqpFbrId?: IntFieldUpdateOperationsInput | number
    EqpMdlNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_mdlUncheckedUpdateInput = {
    EqpTpoId?: IntFieldUpdateOperationsInput | number
    EqpFbrId?: IntFieldUpdateOperationsInput | number
    EqpMdlId?: IntFieldUpdateOperationsInput | number
    EqpMdlNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_mdlCreateManyInput = {
    EqpTpoId: number
    EqpFbrId: number
    EqpMdlId?: number
    EqpMdlNme: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type eqp_mdlUpdateManyMutationInput = {
    EqpTpoId?: IntFieldUpdateOperationsInput | number
    EqpFbrId?: IntFieldUpdateOperationsInput | number
    EqpMdlNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_mdlUncheckedUpdateManyInput = {
    EqpTpoId?: IntFieldUpdateOperationsInput | number
    EqpFbrId?: IntFieldUpdateOperationsInput | number
    EqpMdlId?: IntFieldUpdateOperationsInput | number
    EqpMdlNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_tpoCreateInput = {
    EqpTpoNme: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type eqp_tpoUncheckedCreateInput = {
    EqpTpoId?: number
    EqpTpoNme: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type eqp_tpoUpdateInput = {
    EqpTpoNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_tpoUncheckedUpdateInput = {
    EqpTpoId?: IntFieldUpdateOperationsInput | number
    EqpTpoNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_tpoCreateManyInput = {
    EqpTpoId?: number
    EqpTpoNme: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type eqp_tpoUpdateManyMutationInput = {
    EqpTpoNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type eqp_tpoUncheckedUpdateManyInput = {
    EqpTpoId?: IntFieldUpdateOperationsInput | number
    EqpTpoNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type frnCreateInput = {
    FrnNme: string
    FrnRdz: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type frnUncheckedCreateInput = {
    FrnId?: number
    FrnNme: string
    FrnRdz: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type frnUpdateInput = {
    FrnNme?: StringFieldUpdateOperationsInput | string
    FrnRdz?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type frnUncheckedUpdateInput = {
    FrnId?: IntFieldUpdateOperationsInput | number
    FrnNme?: StringFieldUpdateOperationsInput | string
    FrnRdz?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type frnCreateManyInput = {
    FrnId?: number
    FrnNme: string
    FrnRdz: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type frnUpdateManyMutationInput = {
    FrnNme?: StringFieldUpdateOperationsInput | string
    FrnRdz?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type frnUncheckedUpdateManyInput = {
    FrnId?: IntFieldUpdateOperationsInput | number
    FrnNme?: StringFieldUpdateOperationsInput | string
    FrnRdz?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type rcgCreateInput = {
    RcgIdOrg?: number | null
    EmpId: number
    DtaOpe: Date | string
    UndId: number
    VclId: number
    CrrId?: number | null
    CrrCnc?: number | null
    DtaIni: Date | string
    DtaFin?: Date | string | null
    SocIni?: number | null
    SocFin?: number | null
    RcgKwh?: number | null
    OdoIni?: number | null
    OdoFin?: number | null
    SttRcgId?: number
    FlhId?: number
    FlhDsc?: string | null
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type rcgUncheckedCreateInput = {
    RcgId?: number
    RcgIdOrg?: number | null
    EmpId: number
    DtaOpe: Date | string
    UndId: number
    VclId: number
    CrrId?: number | null
    CrrCnc?: number | null
    DtaIni: Date | string
    DtaFin?: Date | string | null
    SocIni?: number | null
    SocFin?: number | null
    RcgKwh?: number | null
    OdoIni?: number | null
    OdoFin?: number | null
    SttRcgId?: number
    FlhId?: number
    FlhDsc?: string | null
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type rcgUpdateInput = {
    RcgIdOrg?: NullableIntFieldUpdateOperationsInput | number | null
    EmpId?: IntFieldUpdateOperationsInput | number
    DtaOpe?: DateTimeFieldUpdateOperationsInput | Date | string
    UndId?: IntFieldUpdateOperationsInput | number
    VclId?: IntFieldUpdateOperationsInput | number
    CrrId?: NullableIntFieldUpdateOperationsInput | number | null
    CrrCnc?: NullableIntFieldUpdateOperationsInput | number | null
    DtaIni?: DateTimeFieldUpdateOperationsInput | Date | string
    DtaFin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    SocIni?: NullableIntFieldUpdateOperationsInput | number | null
    SocFin?: NullableIntFieldUpdateOperationsInput | number | null
    RcgKwh?: NullableFloatFieldUpdateOperationsInput | number | null
    OdoIni?: NullableFloatFieldUpdateOperationsInput | number | null
    OdoFin?: NullableFloatFieldUpdateOperationsInput | number | null
    SttRcgId?: IntFieldUpdateOperationsInput | number
    FlhId?: IntFieldUpdateOperationsInput | number
    FlhDsc?: NullableStringFieldUpdateOperationsInput | string | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type rcgUncheckedUpdateInput = {
    RcgId?: IntFieldUpdateOperationsInput | number
    RcgIdOrg?: NullableIntFieldUpdateOperationsInput | number | null
    EmpId?: IntFieldUpdateOperationsInput | number
    DtaOpe?: DateTimeFieldUpdateOperationsInput | Date | string
    UndId?: IntFieldUpdateOperationsInput | number
    VclId?: IntFieldUpdateOperationsInput | number
    CrrId?: NullableIntFieldUpdateOperationsInput | number | null
    CrrCnc?: NullableIntFieldUpdateOperationsInput | number | null
    DtaIni?: DateTimeFieldUpdateOperationsInput | Date | string
    DtaFin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    SocIni?: NullableIntFieldUpdateOperationsInput | number | null
    SocFin?: NullableIntFieldUpdateOperationsInput | number | null
    RcgKwh?: NullableFloatFieldUpdateOperationsInput | number | null
    OdoIni?: NullableFloatFieldUpdateOperationsInput | number | null
    OdoFin?: NullableFloatFieldUpdateOperationsInput | number | null
    SttRcgId?: IntFieldUpdateOperationsInput | number
    FlhId?: IntFieldUpdateOperationsInput | number
    FlhDsc?: NullableStringFieldUpdateOperationsInput | string | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type rcgCreateManyInput = {
    RcgId?: number
    RcgIdOrg?: number | null
    EmpId: number
    DtaOpe: Date | string
    UndId: number
    VclId: number
    CrrId?: number | null
    CrrCnc?: number | null
    DtaIni: Date | string
    DtaFin?: Date | string | null
    SocIni?: number | null
    SocFin?: number | null
    RcgKwh?: number | null
    OdoIni?: number | null
    OdoFin?: number | null
    SttRcgId?: number
    FlhId?: number
    FlhDsc?: string | null
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type rcgUpdateManyMutationInput = {
    RcgIdOrg?: NullableIntFieldUpdateOperationsInput | number | null
    EmpId?: IntFieldUpdateOperationsInput | number
    DtaOpe?: DateTimeFieldUpdateOperationsInput | Date | string
    UndId?: IntFieldUpdateOperationsInput | number
    VclId?: IntFieldUpdateOperationsInput | number
    CrrId?: NullableIntFieldUpdateOperationsInput | number | null
    CrrCnc?: NullableIntFieldUpdateOperationsInput | number | null
    DtaIni?: DateTimeFieldUpdateOperationsInput | Date | string
    DtaFin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    SocIni?: NullableIntFieldUpdateOperationsInput | number | null
    SocFin?: NullableIntFieldUpdateOperationsInput | number | null
    RcgKwh?: NullableFloatFieldUpdateOperationsInput | number | null
    OdoIni?: NullableFloatFieldUpdateOperationsInput | number | null
    OdoFin?: NullableFloatFieldUpdateOperationsInput | number | null
    SttRcgId?: IntFieldUpdateOperationsInput | number
    FlhId?: IntFieldUpdateOperationsInput | number
    FlhDsc?: NullableStringFieldUpdateOperationsInput | string | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type rcgUncheckedUpdateManyInput = {
    RcgId?: IntFieldUpdateOperationsInput | number
    RcgIdOrg?: NullableIntFieldUpdateOperationsInput | number | null
    EmpId?: IntFieldUpdateOperationsInput | number
    DtaOpe?: DateTimeFieldUpdateOperationsInput | Date | string
    UndId?: IntFieldUpdateOperationsInput | number
    VclId?: IntFieldUpdateOperationsInput | number
    CrrId?: NullableIntFieldUpdateOperationsInput | number | null
    CrrCnc?: NullableIntFieldUpdateOperationsInput | number | null
    DtaIni?: DateTimeFieldUpdateOperationsInput | Date | string
    DtaFin?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    SocIni?: NullableIntFieldUpdateOperationsInput | number | null
    SocFin?: NullableIntFieldUpdateOperationsInput | number | null
    RcgKwh?: NullableFloatFieldUpdateOperationsInput | number | null
    OdoIni?: NullableFloatFieldUpdateOperationsInput | number | null
    OdoFin?: NullableFloatFieldUpdateOperationsInput | number | null
    SttRcgId?: IntFieldUpdateOperationsInput | number
    FlhId?: IntFieldUpdateOperationsInput | number
    FlhDsc?: NullableStringFieldUpdateOperationsInput | string | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type sttCreateInput = {
    SttNme: string
    SttIdAtu?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type sttUncheckedCreateInput = {
    SttId?: number
    SttNme: string
    SttIdAtu?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type sttUpdateInput = {
    SttNme?: StringFieldUpdateOperationsInput | string
    SttIdAtu?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type sttUncheckedUpdateInput = {
    SttId?: IntFieldUpdateOperationsInput | number
    SttNme?: StringFieldUpdateOperationsInput | string
    SttIdAtu?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type sttCreateManyInput = {
    SttId?: number
    SttNme: string
    SttIdAtu?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type sttUpdateManyMutationInput = {
    SttNme?: StringFieldUpdateOperationsInput | string
    SttIdAtu?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type sttUncheckedUpdateManyInput = {
    SttId?: IntFieldUpdateOperationsInput | number
    SttNme?: StringFieldUpdateOperationsInput | string
    SttIdAtu?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type usrCreateInput = {
    EmpId: number
    UsrTpoId: number
    UsrNme: string
    UsrLgn?: string | null
    UsrCpf?: string | null
    UsrEml: string
    UsrPwd: string
    UsrFto?: string | null
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type usrUncheckedCreateInput = {
    EmpId: number
    UsrTpoId: number
    UsrId?: number
    UsrNme: string
    UsrLgn?: string | null
    UsrCpf?: string | null
    UsrEml: string
    UsrPwd: string
    UsrFto?: string | null
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type usrUpdateInput = {
    EmpId?: IntFieldUpdateOperationsInput | number
    UsrTpoId?: IntFieldUpdateOperationsInput | number
    UsrNme?: StringFieldUpdateOperationsInput | string
    UsrLgn?: NullableStringFieldUpdateOperationsInput | string | null
    UsrCpf?: NullableStringFieldUpdateOperationsInput | string | null
    UsrEml?: StringFieldUpdateOperationsInput | string
    UsrPwd?: StringFieldUpdateOperationsInput | string
    UsrFto?: NullableStringFieldUpdateOperationsInput | string | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type usrUncheckedUpdateInput = {
    EmpId?: IntFieldUpdateOperationsInput | number
    UsrTpoId?: IntFieldUpdateOperationsInput | number
    UsrId?: IntFieldUpdateOperationsInput | number
    UsrNme?: StringFieldUpdateOperationsInput | string
    UsrLgn?: NullableStringFieldUpdateOperationsInput | string | null
    UsrCpf?: NullableStringFieldUpdateOperationsInput | string | null
    UsrEml?: StringFieldUpdateOperationsInput | string
    UsrPwd?: StringFieldUpdateOperationsInput | string
    UsrFto?: NullableStringFieldUpdateOperationsInput | string | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type usrCreateManyInput = {
    EmpId: number
    UsrTpoId: number
    UsrId?: number
    UsrNme: string
    UsrLgn?: string | null
    UsrCpf?: string | null
    UsrEml: string
    UsrPwd: string
    UsrFto?: string | null
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type usrUpdateManyMutationInput = {
    EmpId?: IntFieldUpdateOperationsInput | number
    UsrTpoId?: IntFieldUpdateOperationsInput | number
    UsrNme?: StringFieldUpdateOperationsInput | string
    UsrLgn?: NullableStringFieldUpdateOperationsInput | string | null
    UsrCpf?: NullableStringFieldUpdateOperationsInput | string | null
    UsrEml?: StringFieldUpdateOperationsInput | string
    UsrPwd?: StringFieldUpdateOperationsInput | string
    UsrFto?: NullableStringFieldUpdateOperationsInput | string | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type usrUncheckedUpdateManyInput = {
    EmpId?: IntFieldUpdateOperationsInput | number
    UsrTpoId?: IntFieldUpdateOperationsInput | number
    UsrId?: IntFieldUpdateOperationsInput | number
    UsrNme?: StringFieldUpdateOperationsInput | string
    UsrLgn?: NullableStringFieldUpdateOperationsInput | string | null
    UsrCpf?: NullableStringFieldUpdateOperationsInput | string | null
    UsrEml?: StringFieldUpdateOperationsInput | string
    UsrPwd?: StringFieldUpdateOperationsInput | string
    UsrFto?: NullableStringFieldUpdateOperationsInput | string | null
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type usr_tpoCreateInput = {
    UsrTpoNme: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type usr_tpoUncheckedCreateInput = {
    UsrTpoId?: number
    UsrTpoNme: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type usr_tpoUpdateInput = {
    UsrTpoNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type usr_tpoUncheckedUpdateInput = {
    UsrTpoId?: IntFieldUpdateOperationsInput | number
    UsrTpoNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type usr_tpoCreateManyInput = {
    UsrTpoId?: number
    UsrTpoNme: string
    SttId?: number
    UsrIdAlt: number
    DtaAlt?: Date | string
    MtvDel?: string | null
  }

  export type usr_tpoUpdateManyMutationInput = {
    UsrTpoNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type usr_tpoUncheckedUpdateManyInput = {
    UsrTpoId?: IntFieldUpdateOperationsInput | number
    UsrTpoNme?: StringFieldUpdateOperationsInput | string
    SttId?: IntFieldUpdateOperationsInput | number
    UsrIdAlt?: IntFieldUpdateOperationsInput | number
    DtaAlt?: DateTimeFieldUpdateOperationsInput | Date | string
    MtvDel?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type VwCarregadorCreateInput = {
    UndId: number
    EqpItmId: number
    Carregador?: string | null
  }

  export type VwCarregadorUncheckedCreateInput = {
    UndId: number
    EqpItmId: number
    Carregador?: string | null
  }

  export type VwCarregadorUpdateInput = {
    UndId?: IntFieldUpdateOperationsInput | number
    EqpItmId?: IntFieldUpdateOperationsInput | number
    Carregador?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type VwCarregadorUncheckedUpdateInput = {
    UndId?: IntFieldUpdateOperationsInput | number
    EqpItmId?: IntFieldUpdateOperationsInput | number
    Carregador?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type VwCarregadorCreateManyInput = {
    UndId: number
    EqpItmId: number
    Carregador?: string | null
  }

  export type VwCarregadorUpdateManyMutationInput = {
    UndId?: IntFieldUpdateOperationsInput | number
    EqpItmId?: IntFieldUpdateOperationsInput | number
    Carregador?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type VwCarregadorUncheckedUpdateManyInput = {
    UndId?: IntFieldUpdateOperationsInput | number
    EqpItmId?: IntFieldUpdateOperationsInput | number
    Carregador?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type VwOnibusCreateInput = {
    EqpItmId: number
    Onibus: string
    Situacao: string
  }

  export type VwOnibusUncheckedCreateInput = {
    EqpItmId: number
    Onibus: string
    Situacao: string
  }

  export type VwOnibusUpdateInput = {
    EqpItmId?: IntFieldUpdateOperationsInput | number
    Onibus?: StringFieldUpdateOperationsInput | string
    Situacao?: StringFieldUpdateOperationsInput | string
  }

  export type VwOnibusUncheckedUpdateInput = {
    EqpItmId?: IntFieldUpdateOperationsInput | number
    Onibus?: StringFieldUpdateOperationsInput | string
    Situacao?: StringFieldUpdateOperationsInput | string
  }

  export type VwOnibusCreateManyInput = {
    EqpItmId: number
    Onibus: string
    Situacao: string
  }

  export type VwOnibusUpdateManyMutationInput = {
    EqpItmId?: IntFieldUpdateOperationsInput | number
    Onibus?: StringFieldUpdateOperationsInput | string
    Situacao?: StringFieldUpdateOperationsInput | string
  }

  export type VwOnibusUncheckedUpdateManyInput = {
    EqpItmId?: IntFieldUpdateOperationsInput | number
    Onibus?: StringFieldUpdateOperationsInput | string
    Situacao?: StringFieldUpdateOperationsInput | string
  }

  export type VwPostoRecargaCreateInput = {
    UndId: number
    PostoRecarga: string
    Latitude?: string | null
    Longitude?: string | null
    EqpItmId?: number | null
    Carregador?: string | null
  }

  export type VwPostoRecargaUncheckedCreateInput = {
    UndId: number
    PostoRecarga: string
    Latitude?: string | null
    Longitude?: string | null
    EqpItmId?: number | null
    Carregador?: string | null
  }

  export type VwPostoRecargaUpdateInput = {
    UndId?: IntFieldUpdateOperationsInput | number
    PostoRecarga?: StringFieldUpdateOperationsInput | string
    Latitude?: NullableStringFieldUpdateOperationsInput | string | null
    Longitude?: NullableStringFieldUpdateOperationsInput | string | null
    EqpItmId?: NullableIntFieldUpdateOperationsInput | number | null
    Carregador?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type VwPostoRecargaUncheckedUpdateInput = {
    UndId?: IntFieldUpdateOperationsInput | number
    PostoRecarga?: StringFieldUpdateOperationsInput | string
    Latitude?: NullableStringFieldUpdateOperationsInput | string | null
    Longitude?: NullableStringFieldUpdateOperationsInput | string | null
    EqpItmId?: NullableIntFieldUpdateOperationsInput | number | null
    Carregador?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type VwPostoRecargaCreateManyInput = {
    UndId: number
    PostoRecarga: string
    Latitude?: string | null
    Longitude?: string | null
    EqpItmId?: number | null
    Carregador?: string | null
  }

  export type VwPostoRecargaUpdateManyMutationInput = {
    UndId?: IntFieldUpdateOperationsInput | number
    PostoRecarga?: StringFieldUpdateOperationsInput | string
    Latitude?: NullableStringFieldUpdateOperationsInput | string | null
    Longitude?: NullableStringFieldUpdateOperationsInput | string | null
    EqpItmId?: NullableIntFieldUpdateOperationsInput | number | null
    Carregador?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type VwPostoRecargaUncheckedUpdateManyInput = {
    UndId?: IntFieldUpdateOperationsInput | number
    PostoRecarga?: StringFieldUpdateOperationsInput | string
    Latitude?: NullableStringFieldUpdateOperationsInput | string | null
    Longitude?: NullableStringFieldUpdateOperationsInput | string | null
    EqpItmId?: NullableIntFieldUpdateOperationsInput | number | null
    Carregador?: NullableStringFieldUpdateOperationsInput | string | null
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type cbtOrderByRelevanceInput = {
    fields: cbtOrderByRelevanceFieldEnum | cbtOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type cbtCountOrderByAggregateInput = {
    CbtId?: SortOrder
    CbtNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type cbtAvgOrderByAggregateInput = {
    CbtId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type cbtMaxOrderByAggregateInput = {
    CbtId?: SortOrder
    CbtNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type cbtMinOrderByAggregateInput = {
    CbtId?: SortOrder
    CbtNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type cbtSumOrderByAggregateInput = {
    CbtId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type empOrderByRelevanceInput = {
    fields: empOrderByRelevanceFieldEnum | empOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type empCountOrderByAggregateInput = {
    EmpId?: SortOrder
    EmpNme?: SortOrder
    EmpRaz?: SortOrder
    EmpRdz?: SortOrder
    EmpAtv?: SortOrder
    EmpCnpj?: SortOrder
    Enduf?: SortOrder
    EndCdd?: SortOrder
    EndLtt?: SortOrder
    EndLgt?: SortOrder
    EndCep?: SortOrder
    EndEmp?: SortOrder
    EndCpl?: SortOrder
    EmpLgo?: SortOrder
    EmpUrl?: SortOrder
    EmlCtt?: SortOrder
    EmlFrm?: SortOrder
    EmlFrmPwd?: SortOrder
    FneCtt?: SortOrder
    FneWha?: SortOrder
    RssIns?: SortOrder
    RssFac?: SortOrder
    RssTwi?: SortOrder
    RssYou?: SortOrder
    TpoPix?: SortOrder
    ChvPix?: SortOrder
    QRPixImg?: SortOrder
    QRPixCpy?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type empAvgOrderByAggregateInput = {
    EmpId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type empMaxOrderByAggregateInput = {
    EmpId?: SortOrder
    EmpNme?: SortOrder
    EmpRaz?: SortOrder
    EmpRdz?: SortOrder
    EmpAtv?: SortOrder
    EmpCnpj?: SortOrder
    Enduf?: SortOrder
    EndCdd?: SortOrder
    EndLtt?: SortOrder
    EndLgt?: SortOrder
    EndCep?: SortOrder
    EndEmp?: SortOrder
    EndCpl?: SortOrder
    EmpLgo?: SortOrder
    EmpUrl?: SortOrder
    EmlCtt?: SortOrder
    EmlFrm?: SortOrder
    EmlFrmPwd?: SortOrder
    FneCtt?: SortOrder
    FneWha?: SortOrder
    RssIns?: SortOrder
    RssFac?: SortOrder
    RssTwi?: SortOrder
    RssYou?: SortOrder
    TpoPix?: SortOrder
    ChvPix?: SortOrder
    QRPixImg?: SortOrder
    QRPixCpy?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type empMinOrderByAggregateInput = {
    EmpId?: SortOrder
    EmpNme?: SortOrder
    EmpRaz?: SortOrder
    EmpRdz?: SortOrder
    EmpAtv?: SortOrder
    EmpCnpj?: SortOrder
    Enduf?: SortOrder
    EndCdd?: SortOrder
    EndLtt?: SortOrder
    EndLgt?: SortOrder
    EndCep?: SortOrder
    EndEmp?: SortOrder
    EndCpl?: SortOrder
    EmpLgo?: SortOrder
    EmpUrl?: SortOrder
    EmlCtt?: SortOrder
    EmlFrm?: SortOrder
    EmlFrmPwd?: SortOrder
    FneCtt?: SortOrder
    FneWha?: SortOrder
    RssIns?: SortOrder
    RssFac?: SortOrder
    RssTwi?: SortOrder
    RssYou?: SortOrder
    TpoPix?: SortOrder
    ChvPix?: SortOrder
    QRPixImg?: SortOrder
    QRPixCpy?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type empSumOrderByAggregateInput = {
    EmpId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type emp_undOrderByRelevanceInput = {
    fields: emp_undOrderByRelevanceFieldEnum | emp_undOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type emp_undCountOrderByAggregateInput = {
    EmpId?: SortOrder
    UndId?: SortOrder
    UndNme?: SortOrder
    UndRdz?: SortOrder
    UndReg?: SortOrder
    GpsLtd?: SortOrder
    GpsLgt?: SortOrder
    PstRcg?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type emp_undAvgOrderByAggregateInput = {
    EmpId?: SortOrder
    UndId?: SortOrder
    PstRcg?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type emp_undMaxOrderByAggregateInput = {
    EmpId?: SortOrder
    UndId?: SortOrder
    UndNme?: SortOrder
    UndRdz?: SortOrder
    UndReg?: SortOrder
    GpsLtd?: SortOrder
    GpsLgt?: SortOrder
    PstRcg?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type emp_undMinOrderByAggregateInput = {
    EmpId?: SortOrder
    UndId?: SortOrder
    UndNme?: SortOrder
    UndRdz?: SortOrder
    UndReg?: SortOrder
    GpsLtd?: SortOrder
    GpsLgt?: SortOrder
    PstRcg?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type emp_undSumOrderByAggregateInput = {
    EmpId?: SortOrder
    UndId?: SortOrder
    PstRcg?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type eqp_fbrOrderByRelevanceInput = {
    fields: eqp_fbrOrderByRelevanceFieldEnum | eqp_fbrOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type eqp_fbrCountOrderByAggregateInput = {
    EqpFbrId?: SortOrder
    EqpFbrNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type eqp_fbrAvgOrderByAggregateInput = {
    EqpFbrId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type eqp_fbrMaxOrderByAggregateInput = {
    EqpFbrId?: SortOrder
    EqpFbrNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type eqp_fbrMinOrderByAggregateInput = {
    EqpFbrId?: SortOrder
    EqpFbrNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type eqp_fbrSumOrderByAggregateInput = {
    EqpFbrId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type eqp_itmOrderByRelevanceInput = {
    fields: eqp_itmOrderByRelevanceFieldEnum | eqp_itmOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type eqp_itmCountOrderByAggregateInput = {
    FrnId?: SortOrder
    EqpTpoId?: SortOrder
    EqpFbrId?: SortOrder
    EqpMdlId?: SortOrder
    EqpItmId?: SortOrder
    EqpItmCdg?: SortOrder
    EqpItmPlc?: SortOrder
    EqpItmAnoMdl?: SortOrder
    CbtId?: SortOrder
    EqpItmTmh?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type eqp_itmAvgOrderByAggregateInput = {
    FrnId?: SortOrder
    EqpTpoId?: SortOrder
    EqpFbrId?: SortOrder
    EqpMdlId?: SortOrder
    EqpItmId?: SortOrder
    CbtId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type eqp_itmMaxOrderByAggregateInput = {
    FrnId?: SortOrder
    EqpTpoId?: SortOrder
    EqpFbrId?: SortOrder
    EqpMdlId?: SortOrder
    EqpItmId?: SortOrder
    EqpItmCdg?: SortOrder
    EqpItmPlc?: SortOrder
    EqpItmAnoMdl?: SortOrder
    CbtId?: SortOrder
    EqpItmTmh?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type eqp_itmMinOrderByAggregateInput = {
    FrnId?: SortOrder
    EqpTpoId?: SortOrder
    EqpFbrId?: SortOrder
    EqpMdlId?: SortOrder
    EqpItmId?: SortOrder
    EqpItmCdg?: SortOrder
    EqpItmPlc?: SortOrder
    EqpItmAnoMdl?: SortOrder
    CbtId?: SortOrder
    EqpItmTmh?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type eqp_itmSumOrderByAggregateInput = {
    FrnId?: SortOrder
    EqpTpoId?: SortOrder
    EqpFbrId?: SortOrder
    EqpMdlId?: SortOrder
    EqpItmId?: SortOrder
    CbtId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type eqp_locOrderByRelevanceInput = {
    fields: eqp_locOrderByRelevanceFieldEnum | eqp_locOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type eqp_locEqpItmIdUndIdCompoundUniqueInput = {
    EqpItmId: number
    UndId: number
  }

  export type eqp_locCountOrderByAggregateInput = {
    EqpTpoId?: SortOrder
    EqpItmId?: SortOrder
    UndId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type eqp_locAvgOrderByAggregateInput = {
    EqpTpoId?: SortOrder
    EqpItmId?: SortOrder
    UndId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type eqp_locMaxOrderByAggregateInput = {
    EqpTpoId?: SortOrder
    EqpItmId?: SortOrder
    UndId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type eqp_locMinOrderByAggregateInput = {
    EqpTpoId?: SortOrder
    EqpItmId?: SortOrder
    UndId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type eqp_locSumOrderByAggregateInput = {
    EqpTpoId?: SortOrder
    EqpItmId?: SortOrder
    UndId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type eqp_mdlOrderByRelevanceInput = {
    fields: eqp_mdlOrderByRelevanceFieldEnum | eqp_mdlOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type eqp_mdlCountOrderByAggregateInput = {
    EqpTpoId?: SortOrder
    EqpFbrId?: SortOrder
    EqpMdlId?: SortOrder
    EqpMdlNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type eqp_mdlAvgOrderByAggregateInput = {
    EqpTpoId?: SortOrder
    EqpFbrId?: SortOrder
    EqpMdlId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type eqp_mdlMaxOrderByAggregateInput = {
    EqpTpoId?: SortOrder
    EqpFbrId?: SortOrder
    EqpMdlId?: SortOrder
    EqpMdlNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type eqp_mdlMinOrderByAggregateInput = {
    EqpTpoId?: SortOrder
    EqpFbrId?: SortOrder
    EqpMdlId?: SortOrder
    EqpMdlNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type eqp_mdlSumOrderByAggregateInput = {
    EqpTpoId?: SortOrder
    EqpFbrId?: SortOrder
    EqpMdlId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type eqp_tpoOrderByRelevanceInput = {
    fields: eqp_tpoOrderByRelevanceFieldEnum | eqp_tpoOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type eqp_tpoCountOrderByAggregateInput = {
    EqpTpoId?: SortOrder
    EqpTpoNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type eqp_tpoAvgOrderByAggregateInput = {
    EqpTpoId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type eqp_tpoMaxOrderByAggregateInput = {
    EqpTpoId?: SortOrder
    EqpTpoNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type eqp_tpoMinOrderByAggregateInput = {
    EqpTpoId?: SortOrder
    EqpTpoNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type eqp_tpoSumOrderByAggregateInput = {
    EqpTpoId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type frnOrderByRelevanceInput = {
    fields: frnOrderByRelevanceFieldEnum | frnOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type frnCountOrderByAggregateInput = {
    FrnId?: SortOrder
    FrnNme?: SortOrder
    FrnRdz?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type frnAvgOrderByAggregateInput = {
    FrnId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type frnMaxOrderByAggregateInput = {
    FrnId?: SortOrder
    FrnNme?: SortOrder
    FrnRdz?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type frnMinOrderByAggregateInput = {
    FrnId?: SortOrder
    FrnNme?: SortOrder
    FrnRdz?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type frnSumOrderByAggregateInput = {
    FrnId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type FloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type rcgOrderByRelevanceInput = {
    fields: rcgOrderByRelevanceFieldEnum | rcgOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type rcgCountOrderByAggregateInput = {
    RcgId?: SortOrder
    RcgIdOrg?: SortOrder
    EmpId?: SortOrder
    DtaOpe?: SortOrder
    UndId?: SortOrder
    VclId?: SortOrder
    CrrId?: SortOrder
    CrrCnc?: SortOrder
    DtaIni?: SortOrder
    DtaFin?: SortOrder
    SocIni?: SortOrder
    SocFin?: SortOrder
    RcgKwh?: SortOrder
    OdoIni?: SortOrder
    OdoFin?: SortOrder
    SttRcgId?: SortOrder
    FlhId?: SortOrder
    FlhDsc?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type rcgAvgOrderByAggregateInput = {
    RcgId?: SortOrder
    RcgIdOrg?: SortOrder
    EmpId?: SortOrder
    UndId?: SortOrder
    VclId?: SortOrder
    CrrId?: SortOrder
    CrrCnc?: SortOrder
    SocIni?: SortOrder
    SocFin?: SortOrder
    RcgKwh?: SortOrder
    OdoIni?: SortOrder
    OdoFin?: SortOrder
    SttRcgId?: SortOrder
    FlhId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type rcgMaxOrderByAggregateInput = {
    RcgId?: SortOrder
    RcgIdOrg?: SortOrder
    EmpId?: SortOrder
    DtaOpe?: SortOrder
    UndId?: SortOrder
    VclId?: SortOrder
    CrrId?: SortOrder
    CrrCnc?: SortOrder
    DtaIni?: SortOrder
    DtaFin?: SortOrder
    SocIni?: SortOrder
    SocFin?: SortOrder
    RcgKwh?: SortOrder
    OdoIni?: SortOrder
    OdoFin?: SortOrder
    SttRcgId?: SortOrder
    FlhId?: SortOrder
    FlhDsc?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type rcgMinOrderByAggregateInput = {
    RcgId?: SortOrder
    RcgIdOrg?: SortOrder
    EmpId?: SortOrder
    DtaOpe?: SortOrder
    UndId?: SortOrder
    VclId?: SortOrder
    CrrId?: SortOrder
    CrrCnc?: SortOrder
    DtaIni?: SortOrder
    DtaFin?: SortOrder
    SocIni?: SortOrder
    SocFin?: SortOrder
    RcgKwh?: SortOrder
    OdoIni?: SortOrder
    OdoFin?: SortOrder
    SttRcgId?: SortOrder
    FlhId?: SortOrder
    FlhDsc?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type rcgSumOrderByAggregateInput = {
    RcgId?: SortOrder
    RcgIdOrg?: SortOrder
    EmpId?: SortOrder
    UndId?: SortOrder
    VclId?: SortOrder
    CrrId?: SortOrder
    CrrCnc?: SortOrder
    SocIni?: SortOrder
    SocFin?: SortOrder
    RcgKwh?: SortOrder
    OdoIni?: SortOrder
    OdoFin?: SortOrder
    SttRcgId?: SortOrder
    FlhId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type FloatNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedFloatNullableFilter<$PrismaModel>
    _min?: NestedFloatNullableFilter<$PrismaModel>
    _max?: NestedFloatNullableFilter<$PrismaModel>
  }

  export type sttOrderByRelevanceInput = {
    fields: sttOrderByRelevanceFieldEnum | sttOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type sttCountOrderByAggregateInput = {
    SttId?: SortOrder
    SttNme?: SortOrder
    SttIdAtu?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type sttAvgOrderByAggregateInput = {
    SttId?: SortOrder
    SttIdAtu?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type sttMaxOrderByAggregateInput = {
    SttId?: SortOrder
    SttNme?: SortOrder
    SttIdAtu?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type sttMinOrderByAggregateInput = {
    SttId?: SortOrder
    SttNme?: SortOrder
    SttIdAtu?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type sttSumOrderByAggregateInput = {
    SttId?: SortOrder
    SttIdAtu?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type usrOrderByRelevanceInput = {
    fields: usrOrderByRelevanceFieldEnum | usrOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type usrCountOrderByAggregateInput = {
    EmpId?: SortOrder
    UsrTpoId?: SortOrder
    UsrId?: SortOrder
    UsrNme?: SortOrder
    UsrLgn?: SortOrder
    UsrCpf?: SortOrder
    UsrEml?: SortOrder
    UsrPwd?: SortOrder
    UsrFto?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type usrAvgOrderByAggregateInput = {
    EmpId?: SortOrder
    UsrTpoId?: SortOrder
    UsrId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type usrMaxOrderByAggregateInput = {
    EmpId?: SortOrder
    UsrTpoId?: SortOrder
    UsrId?: SortOrder
    UsrNme?: SortOrder
    UsrLgn?: SortOrder
    UsrCpf?: SortOrder
    UsrEml?: SortOrder
    UsrPwd?: SortOrder
    UsrFto?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type usrMinOrderByAggregateInput = {
    EmpId?: SortOrder
    UsrTpoId?: SortOrder
    UsrId?: SortOrder
    UsrNme?: SortOrder
    UsrLgn?: SortOrder
    UsrCpf?: SortOrder
    UsrEml?: SortOrder
    UsrPwd?: SortOrder
    UsrFto?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type usrSumOrderByAggregateInput = {
    EmpId?: SortOrder
    UsrTpoId?: SortOrder
    UsrId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type usr_tpoOrderByRelevanceInput = {
    fields: usr_tpoOrderByRelevanceFieldEnum | usr_tpoOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type usr_tpoCountOrderByAggregateInput = {
    UsrTpoId?: SortOrder
    UsrTpoNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type usr_tpoAvgOrderByAggregateInput = {
    UsrTpoId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type usr_tpoMaxOrderByAggregateInput = {
    UsrTpoId?: SortOrder
    UsrTpoNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type usr_tpoMinOrderByAggregateInput = {
    UsrTpoId?: SortOrder
    UsrTpoNme?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
    DtaAlt?: SortOrder
    MtvDel?: SortOrder
  }

  export type usr_tpoSumOrderByAggregateInput = {
    UsrTpoId?: SortOrder
    SttId?: SortOrder
    UsrIdAlt?: SortOrder
  }

  export type VwCarregadorOrderByRelevanceInput = {
    fields: VwCarregadorOrderByRelevanceFieldEnum | VwCarregadorOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type VwCarregadorUndIdEqpItmIdCompoundUniqueInput = {
    UndId: number
    EqpItmId: number
  }

  export type VwCarregadorCountOrderByAggregateInput = {
    UndId?: SortOrder
    EqpItmId?: SortOrder
    Carregador?: SortOrder
  }

  export type VwCarregadorAvgOrderByAggregateInput = {
    UndId?: SortOrder
    EqpItmId?: SortOrder
  }

  export type VwCarregadorMaxOrderByAggregateInput = {
    UndId?: SortOrder
    EqpItmId?: SortOrder
    Carregador?: SortOrder
  }

  export type VwCarregadorMinOrderByAggregateInput = {
    UndId?: SortOrder
    EqpItmId?: SortOrder
    Carregador?: SortOrder
  }

  export type VwCarregadorSumOrderByAggregateInput = {
    UndId?: SortOrder
    EqpItmId?: SortOrder
  }

  export type VwOnibusOrderByRelevanceInput = {
    fields: VwOnibusOrderByRelevanceFieldEnum | VwOnibusOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type VwOnibusCountOrderByAggregateInput = {
    EqpItmId?: SortOrder
    Onibus?: SortOrder
    Situacao?: SortOrder
  }

  export type VwOnibusAvgOrderByAggregateInput = {
    EqpItmId?: SortOrder
  }

  export type VwOnibusMaxOrderByAggregateInput = {
    EqpItmId?: SortOrder
    Onibus?: SortOrder
    Situacao?: SortOrder
  }

  export type VwOnibusMinOrderByAggregateInput = {
    EqpItmId?: SortOrder
    Onibus?: SortOrder
    Situacao?: SortOrder
  }

  export type VwOnibusSumOrderByAggregateInput = {
    EqpItmId?: SortOrder
  }

  export type VwPostoRecargaOrderByRelevanceInput = {
    fields: VwPostoRecargaOrderByRelevanceFieldEnum | VwPostoRecargaOrderByRelevanceFieldEnum[]
    sort: SortOrder
    search: string
  }

  export type VwPostoRecargaCountOrderByAggregateInput = {
    UndId?: SortOrder
    PostoRecarga?: SortOrder
    Latitude?: SortOrder
    Longitude?: SortOrder
    EqpItmId?: SortOrder
    Carregador?: SortOrder
  }

  export type VwPostoRecargaAvgOrderByAggregateInput = {
    UndId?: SortOrder
    EqpItmId?: SortOrder
  }

  export type VwPostoRecargaMaxOrderByAggregateInput = {
    UndId?: SortOrder
    PostoRecarga?: SortOrder
    Latitude?: SortOrder
    Longitude?: SortOrder
    EqpItmId?: SortOrder
    Carregador?: SortOrder
  }

  export type VwPostoRecargaMinOrderByAggregateInput = {
    UndId?: SortOrder
    PostoRecarga?: SortOrder
    Latitude?: SortOrder
    Longitude?: SortOrder
    EqpItmId?: SortOrder
    Carregador?: SortOrder
  }

  export type VwPostoRecargaSumOrderByAggregateInput = {
    UndId?: SortOrder
    EqpItmId?: SortOrder
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type NullableFloatFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[]
    notIn?: number[]
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[]
    notIn?: string[]
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[]
    notIn?: Date[] | string[]
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | null
    notIn?: string[] | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    search?: string
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | null
    notIn?: Date[] | string[] | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | null
    notIn?: number[] | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedFloatNullableFilter<$PrismaModel>
    _min?: NestedFloatNullableFilter<$PrismaModel>
    _max?: NestedFloatNullableFilter<$PrismaModel>
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}