// lib/prisma.ts
import { PrismaClient } from "@/lib/generated/prisma";
const prisma = new PrismaClient();
export default prisma;
