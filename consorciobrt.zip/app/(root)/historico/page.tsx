import Historico from "@/components/Historico";
import React from "react";

const HistoricoPage = () => {
  return (
    <div>
      <Historico />
    </div>
  );
};

export default HistoricoPage;
