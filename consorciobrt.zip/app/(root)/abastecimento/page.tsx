import Abastecimento from '@/components/Abastecimento'
import React from 'react'

const AbastecimentoPage = () => {
  return (
    <div>
      <Abastecimento />
    </div>
  )
}

export default AbastecimentoPage
